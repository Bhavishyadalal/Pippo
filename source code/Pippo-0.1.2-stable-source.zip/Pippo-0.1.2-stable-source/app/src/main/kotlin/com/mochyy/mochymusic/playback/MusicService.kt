// MusicService.kt

@file:Suppress("DEPRECATION")

package com.mochyy.mochymusic.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.database.SQLException
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.LoudnessEnhancer
import android.net.ConnectivityManager
import android.os.Binder
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import androidx.core.net.toUri
import androidx.datastore.preferences.core.edit
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Player.EVENT_POSITION_DISCONTINUITY
import androidx.media3.common.Player.EVENT_TIMELINE_CHANGED
import androidx.media3.common.Player.REPEAT_MODE_ALL
import androidx.media3.common.Player.REPEAT_MODE_OFF
import androidx.media3.common.Player.REPEAT_MODE_ONE
import androidx.media3.common.Player.STATE_IDLE
import androidx.media3.common.Timeline
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.ContentMetadata
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.decoder.ffmpeg.FfmpegFallbackRenderer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.analytics.PlaybackStats
import androidx.media3.exoplayer.analytics.PlaybackStatsListener
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.FormatHolder
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ShuffleOrder.DefaultShuffleOrder
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.extractor.mkv.MatroskaExtractor
import androidx.media3.extractor.mp4.FragmentedMp4Extractor
import androidx.media3.session.CacheBitmapLoader
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaController
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.mochyy.mochymusic.utils.followAppProxy
import com.music.innertube.YouTube
import com.music.innertube.models.SongItem
import com.music.innertube.models.WatchEndpoint
import com.mochyy.mochymusic.MainActivity
import com.mochyy.mochymusic.R
import com.mochyy.mochymusic.car.CarLyrics
import com.mochyy.mochymusic.car.CarLyricsPlayer
import com.mochyy.mochymusic.car.CarLyricsSource
import com.mochyy.mochymusic.constants.AudioNormalizationKey
import com.mochyy.mochymusic.constants.AudioOffload
import com.mochyy.mochymusic.constants.AudioQuality
import com.mochyy.mochymusic.constants.AudioQualityKey
import com.mochyy.mochymusic.constants.AutoDownloadOnLikeKey
import com.mochyy.mochymusic.constants.AutoLoadMoreKey
import com.mochyy.mochymusic.constants.AutoSkipNextOnErrorKey
import com.mochyy.mochymusic.constants.DontSkipOnFailureKey
import com.mochyy.mochymusic.constants.StreamFailureTimeoutKey
import com.mochyy.mochymusic.constants.CrossfadeDurationKey
import com.mochyy.mochymusic.constants.TransportEffect
import com.mochyy.mochymusic.constants.TransportFadeDefaultEnabled
import com.mochyy.mochymusic.constants.TransportFadeDefaultSeconds
import com.mochyy.mochymusic.constants.TransportFadeEnabledKey
import com.mochyy.mochymusic.constants.TransportFadeSecondsKey
import com.mochyy.mochymusic.constants.activeTransportEffect
import com.mochyy.mochymusic.constants.transportFadeSeconds
import com.mochyy.mochymusic.constants.CrossfadeGaplessKey
import com.mochyy.mochymusic.constants.SkipBlendKey
import com.mochyy.mochymusic.constants.SkipBlendAheadKey
import com.mochyy.mochymusic.constants.SkipBlendAheadMax
import com.mochyy.mochymusic.constants.StudioForVideosKey
import com.mochyy.mochymusic.constants.CrossmixMode
import com.mochyy.mochymusic.constants.HiFiResamplerKey
import com.mochyy.mochymusic.constants.HiResOutputKey
import com.mochyy.mochymusic.constants.PreferUsbDacKey
import com.mochyy.mochymusic.constants.UsbPassthroughKey
import com.mochyy.mochymusic.constants.AudioPassMode
import com.mochyy.mochymusic.constants.AudioPassModeKey
import com.mochyy.mochymusic.constants.AudioPassFixedVolumeKey
import com.mochyy.mochymusic.constants.AudioPassRestoreKey
import com.mochyy.mochymusic.constants.CrossmixLength
import com.mochyy.mochymusic.constants.CrossmixLengthKey
import com.mochyy.mochymusic.constants.CrossmixStartLatencyKey
import com.mochyy.mochymusic.constants.CrossmixStuntsKey
import com.mochyy.mochymusic.constants.CrossmixStyleAuto
import com.mochyy.mochymusic.constants.CrossmixStyleKey
import com.mochyy.mochymusic.constants.CrossmixTempoMatch
import com.mochyy.mochymusic.constants.CrossmixTempoMatchKey
import com.mochyy.mochymusic.crossmix.CrossmixAnalysisRepository
import com.mochyy.mochymusic.crossmix.CrossmixRole
import com.mochyy.mochymusic.crossmix.CrossmixSettings
import com.mochyy.mochymusic.crossmix.CrossmixStyle
import com.mochyy.mochymusic.constants.DisableLoadMoreWhenRepeatAllKey
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.mochyy.mochymusic.constants.HideExplicitKey
import com.mochyy.mochymusic.constants.HideVideoSongsKey
import com.mochyy.mochymusic.constants.HistoryDuration
import com.mochyy.mochymusic.constants.MediaSessionConstants.CommandToggleLike
import com.mochyy.mochymusic.constants.MediaSessionConstants.CommandToggleRepeatMode
import com.mochyy.mochymusic.constants.MediaSessionConstants.CommandToggleShuffle
import com.mochyy.mochymusic.constants.MediaSessionConstants.CommandToggleStartRadio
import com.mochyy.mochymusic.constants.OfflineModeKey
import com.mochyy.mochymusic.constants.PauseListenHistoryKey
import com.mochyy.mochymusic.constants.MixWithOtherAppsKey
import com.mochyy.mochymusic.constants.PauseOnMute
import com.mochyy.mochymusic.constants.PersistentQueueKey
import com.mochyy.mochymusic.constants.InfiniteQueueKey
import com.mochyy.mochymusic.constants.PersistentShuffleAcrossQueuesKey
import com.mochyy.mochymusic.constants.PlayerVolumeKey
import com.mochyy.mochymusic.constants.RememberShuffleAndRepeatKey
import com.mochyy.mochymusic.constants.RepeatModeKey
import com.mochyy.mochymusic.constants.ResumeOnBluetoothConnectKey
import com.mochyy.mochymusic.constants.ScrobbleDelayPercentKey
import com.mochyy.mochymusic.constants.ScrobbleDelaySecondsKey
import com.mochyy.mochymusic.constants.ScrobbleMinSongDurationKey
import com.mochyy.mochymusic.constants.ShowLyricsKey
import com.mochyy.mochymusic.constants.ShuffleModeKey
import com.mochyy.mochymusic.constants.ShufflePlaylistFirstKey
import com.mochyy.mochymusic.constants.SimilarContent
import com.mochyy.mochymusic.constants.SkipSilenceInstantKey
import com.mochyy.mochymusic.constants.SkipSilenceKey
import com.mochyy.mochymusic.constants.StopPlaybackOnTaskRemovedKey
import com.mochyy.mochymusic.constants.IpVersionKey
import com.music.innertube.models.IpVersion
import okhttp3.Dns
import java.net.InetAddress
import java.net.Inet4Address
import java.net.Inet6Address
import com.mochyy.mochymusic.db.MusicDatabase
import com.mochyy.mochymusic.db.entities.Event
import com.mochyy.mochymusic.db.entities.FormatEntity
import com.mochyy.mochymusic.db.entities.LyricsEntity
import com.mochyy.mochymusic.db.entities.RelatedSongMap
import com.mochyy.mochymusic.db.entities.Song
import com.mochyy.mochymusic.di.DownloadCache
import com.mochyy.mochymusic.di.PlayerCache
import com.mochyy.mochymusic.eq.AudioFxService
import com.mochyy.mochymusic.eq.AudioLabStore
import com.mochyy.mochymusic.eq.EqualizerService
import com.mochyy.mochymusic.eq.audio.CustomEqualizerAudioProcessor
import com.mochyy.mochymusic.eq.audio.LoudnessAudioProcessor
import com.mochyy.mochymusic.eq.audio.ReverbAudioProcessor
import com.mochyy.mochymusic.eq.audio.SpatialAudioProcessor
import com.mochyy.mochymusic.extensions.SilentHandler
import com.mochyy.mochymusic.extensions.collect
import com.mochyy.mochymusic.extensions.collectLatest
import com.mochyy.mochymusic.extensions.currentMetadata
import com.mochyy.mochymusic.extensions.findNextMediaItemById
import com.mochyy.mochymusic.extensions.isAutoplay
import com.mochyy.mochymusic.extensions.isManualQueued
import com.mochyy.mochymusic.extensions.withAutoplay
import com.mochyy.mochymusic.extensions.withManualQueued
import com.mochyy.mochymusic.extensions.mediaItems
import com.mochyy.mochymusic.extensions.metadata
import com.mochyy.mochymusic.extensions.setOffloadEnabled
import com.mochyy.mochymusic.extensions.toEnum
import com.mochyy.mochymusic.extensions.toMediaItem
import com.mochyy.mochymusic.extensions.toPersistQueue
import com.mochyy.mochymusic.extensions.toQueue
import com.mochyy.mochymusic.lyrics.LyricsHelper
import com.mochyy.mochymusic.models.PersistPlayerState
import com.mochyy.mochymusic.models.PersistQueue
import com.mochyy.mochymusic.models.toMediaMetadata
import com.mochyy.mochymusic.playback.audio.PlatformOutputMonitor
import com.mochyy.mochymusic.playback.audio.SilenceDetectorAudioProcessor
import com.mochyy.mochymusic.playback.audio.HapticAudioProcessor
import com.mochyy.mochymusic.playback.audio.CrossmixClockSink
import com.mochyy.mochymusic.playback.audio.CrossmixTransitionAudioProcessor
import com.mochyy.mochymusic.playback.audio.pass.LabSound
import com.mochyy.mochymusic.playback.audio.pass.AudioPass
import com.mochyy.mochymusic.playback.audio.pass.PassRouterSink
import com.mochyy.mochymusic.playback.audio.pass.PassSink
import com.mochyy.mochymusic.playback.audio.pass.PassBlocker
import com.mochyy.mochymusic.playback.audio.pass.clearPassBlockers
import com.mochyy.mochymusic.playback.audio.pass.PassBlockersBefore
import com.mochyy.mochymusic.playback.audio.pass.restorePassBlockers
import com.mochyy.mochymusic.playback.audio.pass.passBlockersOf
import com.mochyy.mochymusic.constants.MusicHapticsEnabledKey
import com.mochyy.mochymusic.constants.MusicHapticsSensitivityKey
import com.mochyy.mochymusic.constants.HapticSensitivity
import android.os.Vibrator
import android.os.VibratorManager
import android.os.VibrationEffect
import com.mochyy.mochymusic.playback.queues.EmptyQueue
import com.mochyy.mochymusic.playback.queues.ListQueue
import com.mochyy.mochymusic.playback.queues.Queue
import com.mochyy.mochymusic.playback.queues.YouTubeQueue
import com.mochyy.mochymusic.playback.queues.filterExplicit
import com.mochyy.mochymusic.playback.queues.filterVideoSongs
import com.mochyy.mochymusic.utils.NotRecommended
import com.mochyy.mochymusic.utils.CoilBitmapLoader
import com.mochyy.mochymusic.utils.NetworkConnectivityObserver
import com.mochyy.mochymusic.scrobble.ScrobbleTimer
import com.mochyy.mochymusic.scrobble.Scrobbler
import com.mochyy.mochymusic.utils.SyncUtils
import com.mochyy.mochymusic.module.TrackMatcher
import com.mochyy.mochymusic.modules.SourceModules.PlaybackLookup
import com.mochyy.mochymusic.playback.custom.CustomStreamResult
import com.mochyy.mochymusic.utils.YTPlayerUtils
import com.mochyy.mochymusic.constants.ShowStreamSourceToastKey
import com.mochyy.mochymusic.constants.YtReportPlaysKey
import com.mochyy.mochymusic.constants.ForcePlaybackKey
import com.mochyy.mochymusic.constants.transitionModeOf
import com.mochyy.mochymusic.constants.CrossmixAlwaysMixKey
import com.mochyy.mochymusic.utils.dataStore
import com.mochyy.mochymusic.utils.PreferencesCache
import com.mochyy.mochymusic.utils.get
import com.mochyy.mochymusic.utils.reportException
import com.mochyy.mochymusic.widget.MochyWidgetManager
import com.mochyy.mochymusic.widget.MusicWidgetReceiver
import com.mochyy.mochymusic.playback.custom.NoProviderException
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import timber.log.Timber
import java.io.FileNotFoundException
import java.io.ObjectInputStream
import java.io.Serializable
import java.util.concurrent.Executors
import java.io.ObjectOutputStream
import java.time.LocalDateTime
import javax.inject.Inject
import kotlin.coroutines.coroutineContext
import kotlin.time.Duration.Companion.seconds

private const val INSTANT_SILENCE_SKIP_STEP_MS = 15_000L

/** A saved volume below this is taken as one saved while muted or mid-fade, not the user's own. */
private const val MinRestoredVolume = 0.02f
private const val INSTANT_SILENCE_SKIP_SETTLE_MS = 350L

// how often at most a speed or pitch being dragged reaches the player; quick enough to feel live
private const val SpeedApplyGapMs = 60L

// the longest the playback loop may sleep while playing; the position the lyrics, seek bar and video sync read only moves when it wakes
private const val PositionWakeUs = 100_000L

@androidx.annotation.OptIn(UnstableApi::class)
/** A stream that failed at [startedAt] (elapsedRealtime) and skips to the next track [timeoutMs] later. */
data class StreamFailure(val startedAt: Long, val timeoutMs: Long)

@AndroidEntryPoint
@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class MusicService :
    MediaLibraryService(),
    Player.Listener,
    PlaybackStatsListener.Callback {
    @Inject
    lateinit var database: MusicDatabase

    @Inject
    lateinit var lyricsHelper: LyricsHelper

    @Inject
    lateinit var syncUtils: SyncUtils

    @Inject
    lateinit var mediaLibrarySessionCallback: MediaLibrarySessionCallback

    @Inject
    lateinit var equalizerService: EqualizerService

    /** Audio Lab: owns the equalizer and Audio FX settings and pushes them to the processors live */
    @Inject
    lateinit var audioLab: AudioLabStore

    @Inject
    lateinit var audioFx: AudioFxService

    // speed and pitch kept for single songs, over audio lab's for everything else
    @Inject
    lateinit var songTuning: SongTuning

    @Inject
    lateinit var scrobbler: Scrobbler

    /** the Discord status; it does nothing until the user signs in on the Discord page */
    @Inject
    lateinit var discordPresence: com.mochyy.mochymusic.discord.DiscordPresence

    /** source modules (Apple Music): asked for a stream before YouTube */
    @Inject
    lateinit var sourceModules: com.mochyy.mochymusic.modules.SourceModules

    @Inject
    lateinit var widgetManager: MochyWidgetManager

    private lateinit var audioManager: AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var legacyFocusListener: AudioManager.OnAudioFocusChangeListener? = null
    private var lastAudioFocusState = AudioManager.AUDIOFOCUS_NONE
    private var focusResume: InterruptionResume? = null
    private var hasAudioFocus = false
    private var reentrantFocusGain = false
    private var mixWithOtherApps = false
    private var callResume: InterruptionResume? = null
    private val callWatcher by lazy { CallWatcher(this, ::onCallChanged) }
    private var muteResume: InterruptionResume? = null
    var preferredDeviceId: Int? = null
        private set

    /** the outputs, the one picked in the player, the usb dac's mixer, and whether 32-bit float may pass */
    val audioOutputs by lazy { com.mochyy.mochymusic.playback.audio.AudioOutputs(this) }

    /** the exclusive output every player shares: bit-perfect, aaudio exclusive and the direct usb driver */
    val audioPass by lazy { AudioPass(this, audioOutputs) }

    // what keeps songs off the exclusive output right now: audio pass lists them and the router reads them
    private val _passBlockers = MutableStateFlow<Set<PassBlocker>>(emptySet())
    val passBlockers: StateFlow<Set<PassBlocker>> = _passBlockers.asStateFlow()
    // each player's stats for nerds; weak like the spectra, so a released player takes its own along
    private val playerInspectors = java.util.WeakHashMap<Player, StreamInspector>()
    private val platformOutputs = java.util.WeakHashMap<Player, PlatformOutputMonitor>()

    /** what [player]'s song really is on its way out, for stream info */
    fun inspectorOf(player: Player): StreamInspector? = playerInspectors[player]

    private var crossfadeEnabled = false
    private var crossfadeDuration = 5000f
    private var crossfadeGapless = true
    private var crossmixMode = CrossmixMode.OFF
    private var crossmixSettings = CrossmixSettings.Default
    private var crossfadeTriggerJob: Job? = null

    private val secondaryPlayerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            Timber.tag(TAG).e(error, "Secondary player error")
            secondaryPlayer?.stop()
            secondaryPlayer?.clearMediaItems()
            // dropped without this, its decoders and audio track stayed alive with nothing to free them
            secondaryPlayer?.let { failed ->
                failed.removeListener(this)
                playerCrossmixProcessors.remove(failed)
                playerSilenceProcessors.remove(failed)
                unregisterEqualizer(failed)
                failed.release()
            }
            secondaryPlayer = null
        }
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var destroying = false

    private val binder = MusicBinder()

    inner class MusicBinder : Binder() {
        val service: MusicService
            get() = this@MusicService
    }

    private lateinit var connectivityManager: ConnectivityManager
    lateinit var connectivityObserver: NetworkConnectivityObserver
    val waitingForNetworkConnection = MutableStateFlow(false)

    /** A stream that failed and is counting down to a skip; null when nothing has failed. */
    val streamFailure = MutableStateFlow<StreamFailure?>(null)
    private var failureJob: Job? = null
    private val isNetworkConnected = MutableStateFlow(false)

    private lateinit var audioQuality: com.mochyy.mochymusic.constants.AudioQuality
    private lateinit var ipVersion: IpVersion

    private var currentQueue: Queue = EmptyQueue
    var queueTitle: String? = null

    // Bumped whenever the queue is replaced, so in-flight loads for an old queue don't append to the new one.
    private var queueGeneration = 0
    private var initialQueueLoading = false
    private var runwayJob: Job? = null

    // Radio source used to keep the queue going once the current queue runs out (infinite queue).
    private var infiniteSource: Queue? = null
    private val usedInfiniteSeeds = HashSet<String>()
    // Seeds whose radio couldn't be loaded (usually a network error), given another go on a retry.
    private val failedInfiniteSeeds = HashSet<String>()

    // When the runway gives up with the queue running dry, it tries again after a growing delay,
    // rather than leaving a single searched song with nothing after it until the next song change.
    private var runwayRetryJob: Job? = null
    private var runwayRetries = 0

    // The settings cache picks up a write a moment after it lands, so right after the toggle the
    // service goes by what was just set until the cache agrees.
    private var pendingInfiniteQueue: Boolean? = null
    private var infiniteQueueWrite: Job? = null
    private var autoplayGeneration = 0L

    // Lining up Autoplay ahead of time is a nicety, so after an attempt that found nothing (offline,
    // only local songs) it waits a while instead of retrying on every song change.
    private var autoplayPreviewRetryAt = 0L

    val currentMediaMetadata = MutableStateFlow<com.mochyy.mochymusic.models.MediaMetadata?>(null)
    private val currentTrackId = currentMediaMetadata.map { it?.id }.distinctUntilChanged()

    private val currentSong =
        currentTrackId.flatMapLatest { database.song(it) }.stateIn(scope, SharingStarted.Lazily, null)

    private val currentFormat = currentTrackId.flatMapLatest { database.format(it) }

    lateinit var playerVolume: MutableStateFlow<Float>
    val isMuted = MutableStateFlow(false)

    fun toggleMute() {
        val newMutedState = !isMuted.value
        isMuted.value = newMutedState

        player.volume = if (newMutedState) 0f else playerVolume.value
    }

    fun setMuted(muted: Boolean) {
        isMuted.value = muted

        player.volume = if (muted) 0f else playerVolume.value
    }

    /** audio pass's "turn these off": every setting that keeps songs off the exclusive output goes back to neutral, remembering how it was */
    fun clearPassBlockers() {
        // audio lab and the volume are read before anything changes; the preferences inside the same edit that clears them
        val lab = audioLab
        val volume = playerVolume.value
        scope.launch {
            dataStore.edit { prefs ->
                prefs[AudioPassRestoreKey] = passJson.encodeToString(PassBlockersBefore.of(prefs, lab, volume))
                prefs.clearPassBlockers()
            }
        }
        audioLab.clearPassBlockers()
        playerVolume.value = 1f
    }

    /** "turn these back on": everything "turn these off" switched off goes back to how it was */
    fun restorePassBlockers() {
        scope.launch {
            var before: PassBlockersBefore? = null
            dataStore.edit { prefs ->
                before = prefs[AudioPassRestoreKey]?.let { runCatching { passJson.decodeFromString<PassBlockersBefore>(it) }.getOrNull() }
                before?.let(prefs::restorePassBlockers)
                prefs.remove(AudioPassRestoreKey)
            }
            before?.let {
                audioLab.restorePassBlockers(it)
                playerVolume.value = it.playerVolume
            }
        }
    }

    /** whether there's a "turn these back on" waiting */
    val canRestorePassBlockers: Flow<Boolean> by lazy { dataStore.data.map { it[AudioPassRestoreKey] != null }.distinctUntilChanged() }

    fun setPreferredAudioDevice(deviceId: Int?) {
        preferredDeviceId = deviceId
        audioOutputs.select(deviceId)
    }

    private var lastAudioRoute: AudioRouteIdentity? = null
    private var lastPreferredRouteId: Int? = null
    private var externalRouteWasMissing = false
    private var outputRouteGeneration = 0L
    private var audioOutputRecoveryAttempts = 0
    private var routeRefreshJob: Job? = null
    private var outputMonitorJob: Job? = null
    private var outputRebindAttempt: Pair<Long, Long>? = null
    private var outputReopenAttempt: Pair<Long, Long>? = null

    // Overlapping decks open independent AudioTracks and can compete for a Bluetooth route
    // or reconfigure the USB mixer while the outgoing track still uses it.
    private val usesSingleExternalOutput: Boolean
        get() = lastAudioRoute?.external == true

    private fun applyOutputRoute(device: AudioDeviceInfo?, refreshPass: Boolean = false) {
        if (destroying) return
        val preferenceChanged = lastPreferredRouteId != device?.id
        lastPreferredRouteId = device?.id
        if (preferenceChanged) {
            val players = (playerCrossmixProcessors.keys.filterIsInstance<ExoPlayer>() +
                listOfNotNull(if (::player.isInitialized) player else null, secondaryPlayer, fadingPlayer)).distinct()
            players.forEach { it.setPreferredAudioDevice(device) }
        }

        val active = audioOutputs.activeDevice()
        val route = active?.let {
            val kind = com.mochyy.mochymusic.playback.audio.AudioOutputs.kindOf(it.type)
            AudioRouteIdentity(
                it.id,
                bluetooth = kind == com.mochyy.mochymusic.playback.audio.AudioOutputs.Kind.BLUETOOTH,
                usb = kind == com.mochyy.mochymusic.playback.audio.AudioOutputs.Kind.USB,
            )
        }
        val previous = lastAudioRoute
        val changed = preferenceChanged || previous != route || externalRouteWasMissing
        if (changed) audioOutputRecoveryAttempts = 0
        if (refreshPass || (route != null && changed) || (route == null && !externalRouteWasMissing && previous?.external == true)) {
            audioPass.onOutputRouteChanged()
        }
        if (route == null) {
            if (!externalRouteWasMissing && previous?.external == true) {
                externalRouteWasMissing = true
                outputRouteGeneration++
            }
            routeRefreshJob?.cancel()
            outputMonitorJob?.cancel()
            outputMonitorJob = null
            return
        }
        val needsRefresh = needsBluetoothRouteRefresh(previous, route) || needsUsbRouteRefresh(previous, route) ||
            (externalRouteWasMissing && route.external) ||
            (preferenceChanged && (previous?.external == true || route.external))
        externalRouteWasMissing = false
        lastAudioRoute = route
        if (changed) {
            outputRouteGeneration++
            outputMonitorJob?.cancel()
            outputMonitorJob = null
            routeRefreshJob?.cancel()
        }
        if (!::player.isInitialized) return
        val target = player
        if ((previous?.external == true) != route.external) {
            if (route.external) {
                crossmixDirector.onItemChanged()
                crossfadeJob?.cancel()
            }
            scheduleCrossfade()
        }
        if (needsRefresh) {
            val mediaId = target.currentMediaItem?.mediaId ?: return
            val occurrence = providerOccurrence
            val pauseGeneration = transport.pauseGeneration
            val generation = outputRouteGeneration
            routeRefreshJob = scope.launch {
                delay(450)
                withTimeoutOrNull(2_500L) {
                    while (player === target && providerOccurrence == occurrence && outputRouteGeneration == generation &&
                        (target.playbackState == Player.STATE_BUFFERING || handoffFor(mediaId) != null)
                    ) delay(100)
                }
                if (player !== target || providerOccurrence != occurrence || outputRouteGeneration != generation ||
                    transport.pauseGeneration != pauseGeneration || !target.playWhenReady ||
                    !canRefreshPlatformOutput(target, mediaId)
                ) return@launch
                target.seekTo(target.currentMediaItemIndex, target.contentPosition.coerceAtLeast(0L))
            }
        }
        watchPlatformOutput(target)
    }

    private fun canRefreshPlatformOutput(target: Player, mediaId: String): Boolean =
        target.playbackState == Player.STATE_READY && target.currentMediaItem?.mediaId == mediaId &&
            target.currentMediaItemIndex != C.INDEX_UNSET &&
            target.playbackSuppressionReason == Player.PLAYBACK_SUPPRESSION_REASON_NONE &&
            castConnectionHandler?.isCasting?.value != true && handoffFor(mediaId) == null &&
            audioPass.status.value !is AudioPass.Status.Playing &&
            !transport.isFading && !isCrossfading && !crossmixDirector.isTransitioning

    private fun watchPlatformOutput(target: Player) {
        if (target !== player) return
        val deck = player
        if (!target.isPlaying) {
            outputMonitorJob?.cancel()
            outputMonitorJob = null
            return
        }
        val route = lastAudioRoute?.takeIf { it.external && !externalRouteWasMissing } ?: return
        val mediaId = target.currentMediaItem?.mediaId ?: return
        val monitor = platformOutputs[target] ?: return
        val occurrence = providerOccurrence
        val generation = outputRouteGeneration
        val attempt = occurrence to generation
        val pauseGeneration = transport.pauseGeneration
        if (outputReopenAttempt == attempt || outputMonitorJob?.isActive == true) return
        val hasPreferredRoute = lastPreferredRouteId != null
        val compareRoute = hasPreferredRoute || Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

        outputMonitorJob = scope.launch {
            var previous: PlatformOutputMonitor.Sample? = null
            var stalled = 0
            var wrongRoute = 0
            var missingOutput = 0
            while (player === target && providerOccurrence == occurrence && outputRouteGeneration == generation &&
                target.isPlaying && transport.pauseGeneration == pauseGeneration
            ) {
                delay(1_000)
                if (player !== target || providerOccurrence != occurrence || outputRouteGeneration != generation ||
                    !target.isPlaying || transport.pauseGeneration != pauseGeneration
                ) return@launch
                if (!target.currentTracks.isTypeSelected(C.TRACK_TYPE_AUDIO) ||
                    !canRefreshPlatformOutput(target, mediaId) || routeRefreshJob?.isActive == true
                ) {
                    previous = null
                    stalled = 0
                    wrongRoute = 0
                    missingOutput = 0
                    continue
                }
                val sample = monitor.sample()
                missingOutput = if (sample == null || (hasPreferredRoute && sample.deviceId == null)) missingOutput + 1 else 0
                val prior = previous
                val sameTrack = sample != null && prior?.track === sample.track
                val framesAdvanced = prior?.frames != sample?.frames
                stalled = if (sameTrack && !framesAdvanced) stalled + 1 else 0
                val actualRouteId = sample?.deviceId
                wrongRoute = if (compareRoute && actualRouteId != null && actualRouteId != route.id) {
                    if (sameTrack) wrongRoute + 1 else 1
                } else 0
                previous = sample
                if (stalled < 3 && wrongRoute < 3 && missingOutput < 4) continue

                val preferred = audioOutputs.preferredDevice()
                // A device change may be queued on Android's routing callback. Let it take
                // precedence over a recovery scheduled for the previous output.
                if (lastPreferredRouteId != preferred?.id || audioOutputs.activeDevice()?.id != route.id) {
                    applyOutputRoute(preferred)
                    return@launch
                }
                val index = target.currentMediaItemIndex
                val position = target.contentPosition.coerceAtLeast(0L)
                deck.setPreferredAudioDevice(preferred)
                if (outputRebindAttempt != attempt) {
                    outputRebindAttempt = attempt
                    Timber.tag(TAG).w("Reapplying the selected audio output after missing or stalled playback")
                    target.seekTo(index, position)
                    previous = null
                    stalled = 0
                    wrongRoute = 0
                    missingOutput = 0
                    continue
                }

                outputReopenAttempt = attempt
                Timber.tag(TAG).w("Reopening audio output after a stalled or mismatched route")
                target.stop()
                target.seekTo(index, position)
                target.prepare()
                return@launch
            }
        }
    }

    lateinit var sleepTimer: SleepTimer

    @Inject
    @PlayerCache
    lateinit var playerCache: SimpleCache

    @Inject
    @DownloadCache
    lateinit var downloadCache: SimpleCache
    private val resolvedStreamSources = java.util.concurrent.ConcurrentHashMap<String, String>()
    // Force playback: for each song, the providers that already failed on it, passed over next time
    private val failedSources = java.util.concurrent.ConcurrentHashMap<String, MutableSet<String>>()
    // when each song's first failure above was, so they're forgotten after FailedSourceMemoryMs
    private val failedSourcesAt = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** the request headers each source module stream needs, by its cache key */
    private val moduleStreamHeaders = java.util.concurrent.ConcurrentHashMap<String, Map<String, String>>()
    // which provider each song was last handed to (a module id, or "youtube")
    private val resolvedSourceIds = java.util.concurrent.ConcurrentHashMap<String, String>()
    // the providers picked by hand in stream info, by song; they win over the order until they stop having it
    private val forcedRoutes = java.util.concurrent.ConcurrentHashMap<String, ForcedRoute>()
    private class ProviderHandoff(val target: ProviderSwitch.Target, val route: ForcedRoute) {
        val ready = CompletableDeferred<ProviderSwitch.HandoffResult>()
        @Volatile var resolvedFrom: PlayingFrom? = null
        @Volatile var facts: StreamFacts? = null
        @Volatile var youtube: YTPlayerUtils.PlaybackData? = null
        @Volatile var stream: com.mochyy.mochymusic.playback.custom.CustomStreamResult? = null
    }
    @Volatile private var providerOccurrence = 0L
    @Volatile private var providerHandoff: ProviderHandoff? = null

    private fun handoffFor(mediaId: String): ProviderHandoff? =
        providerHandoff?.takeIf { it.target.mediaId == mediaId && it.target.occurrence == providerOccurrence }

    private val providerHandoffHost = ProviderSwitchHost()
    private val _playingFrom = MutableStateFlow<Map<String, PlayingFrom>>(emptyMap())
    /** where each song played from, for stream info's provider row */
    val playingFrom = _playingFrom.asStateFlow()
    fun setPlaybackProviderEnabled(providerId: String, enabled: Boolean) {
        sourceModules.setEnabled(providerId, enabled)
        if (!enabled) providerSwitch.cancelIfSelecting(providerId)
    }

    /** Resolves the replacement while the current provider plays. */
    val providerSwitch by lazy { ProviderSwitch({ scope }, providerHandoffHost) }
    /** what each song is playing as, by media id, for the player's format badge */
    val streamFacts = MutableStateFlow<Map<String, StreamFacts>>(emptyMap())
    /**
     * What this phone had no decoder for, by song ("No FLAC decoder available on this phone"),
     * and the provider whose stream it was: told with what plays instead once its format is
     * known, or as the reason when nothing does.
     */
    private data class DecoderNotice(val text: String, val from: String?)
    private val decoderNotices = java.util.concurrent.ConcurrentHashMap<String, DecoderNotice>()
    private var lastAnnouncedSourceMediaId: String? = null
    lateinit var player: ExoPlayer
        private set
    private var secondaryPlayer: ExoPlayer? = null
    private var fadingPlayer: ExoPlayer? = null
    private var isCrossfading = false
    private var crossfadeJob: Job? = null

    // "blend skips": skips and backs cross over on two players, the neighbours' first seconds fetched ahead
    @Volatile private var skipBlend = false
    // how many songs coming up get their start fetched, so a few skips in a row still blend
    @Volatile private var blendAhead = 1
    private var prefetchJob: Job? = null

    // "studio version for music videos": a music video plays its song's studio upload when there is one
    @Volatile private var studioForVideos = false
    // the outgoing song keeps its own normalisation on its own audio session until it's let go;
    // one shared enhancer used to be handed the next song's gain mid-fade
    private var fadingLoudnessEnhancer: LoudnessEnhancer? = null
    private var loudnessEnhancerSessionId = C.AUDIO_SESSION_ID_UNSET
    // set while Crossmix replays the song-change hooks for the song it just handed over to
    private var promotingCrossmix = false
    private val crossmixAnalysisRepository by lazy {
        CrossmixAnalysisRepository(applicationContext) { createDataSourceFactory() }
    }
    private val crossmixDirector by lazy { CrossmixDirector(scope, CrossmixHost(), crossmixAnalysisRepository) }
    // fades and layered effects for pause, play and skips; the app's buttons and the media session both go through it
    val transport by lazy { TransportTransitions({ scope }, TransportHost()) }
    /** Crossmix is playing two songs together right now, for the player's "Mixing…" note */
    val crossmixMixing = MutableStateFlow(false)
    /** what Crossmix last decided, in a line, for its test tools in Experimental */
    val crossmixStatus = MutableStateFlow("")

    /** plans this song's Crossmix hand-over, then jumps to just before it: for trying mixes out */
    fun testCrossmix() = crossmixDirector.testMix()

    /** the stream each song was handed to the player as, when it wasn't the plain YouTube one */
    private val playingStreams = java.util.concurrent.ConcurrentHashMap<String, com.mochyy.mochymusic.playback.custom.CustomStreamResult>()

    // matches a song's recording against its music video's, for the video background and for a music video's lyrics
    private val videoAudioSync by lazy {
        com.mochyy.mochymusic.lyrics.VideoAudioSync { createDataSourceFactory() }
    }

    // where songId's recording sits inside videoId's, found by listening to both; null when they don't share it
    suspend fun matchSongToVideo(songId: String, videoId: String): com.mochyy.mochymusic.lyrics.SongVideoMap? {
        val current = withContext(Dispatchers.Main) { player.currentMediaItem }
        fun sourceOf(id: String): com.mochyy.mochymusic.lyrics.VideoAudioSync.Source {
            if (current != null && current.mediaId == id) {
                val (uri, key) = lyricsAudioSource(current)
                return com.mochyy.mochymusic.lyrics.VideoAudioSync.Source(uri, key)
            }
            return com.mochyy.mochymusic.lyrics.VideoAudioSync.Source(id.toUri(), id)
        }
        return videoAudioSync.match(sourceOf(songId), sourceOf(videoId))
    }

    /** Lyrics auto offset; the lyrics offset sheet starts it and shows how it's going. */
    val lyricsAutoSync by lazy {
        com.mochyy.mochymusic.lyrics.LyricsAutoSync(
            dataSourceFactory = { createDataSourceFactory() },
            saveOffset = { songId, offsetMs -> database.query { updateLyricsOffset(songId, offsetMs) } },
            onUnwatchedResult = ::announceLyricsSync,
        )
    }

    /** Lines the playing song's lyrics up with its singing: see [com.mochyy.mochymusic.lyrics.LyricsAutoSync]. */
    fun autoSyncLyrics(lines: List<com.mochyy.mochymusic.lyrics.LyricsEntry>, currentOffsetMs: Int) {
        val item = player.currentMediaItem ?: return
        val (uri, key) = lyricsAudioSource(item)
        val durationMs = player.duration.takeIf { it != C.TIME_UNSET && it > 0 }
            ?: player.currentMetadata?.duration?.times(1_000L) ?: 0L
        lyricsAutoSync.start(item.mediaId, uri, key, durationMs, lines, currentOffsetMs)
    }

    /**
     * What auto offset listens to: the very stream the player is playing, so the timing it finds
     * is the timing heard. A source module's stream that's a playlist of segments or locked (HLS,
     * DASH, DRM) can't be read as one file; then it's the song's YouTube stream, which nearly
     * always has the same timing.
     */
    private fun lyricsAudioSource(item: androidx.media3.common.MediaItem): Pair<android.net.Uri, String> {
        val stream = playingStreams[item.mediaId]
        if (stream != null && !stream.isHls && !stream.isDash && stream.widevineLicense == null && stream.decryptionKey == null) {
            return stream.streamUrl.toUri() to (stream.cacheKey ?: item.mediaId)
        }
        return (item.localConfiguration?.uri ?: item.mediaId.toUri()) to item.mediaId
    }

    /** A sync that finished with its sheet closed says how it went in the banner. */
    private fun announceLyricsSync(state: com.mochyy.mochymusic.lyrics.LyricsAutoSync.State) {
        val text = when (state) {
            is com.mochyy.mochymusic.lyrics.LyricsAutoSync.State.Synced -> "Lyrics synced to the singing"
            is com.mochyy.mochymusic.lyrics.LyricsAutoSync.State.Failed -> state.message
            else -> return
        }
        Handler(Looper.getMainLooper()).post { showBanner(text) }
    }

    private data class CrossfadeConfig(
        val mode: CrossmixMode,
        val enabled: Boolean,
        val durationSeconds: Float,
        val disableForGaplessAlbums: Boolean,
    )

    private lateinit var mediaSession: MediaLibrarySession

    // the line being sung on android auto's own player while a car is connected
    private var carLyrics: CarLyrics? = null

    // the line being sung floating over other apps, when it's turned on
    private var floatingLyrics: com.mochyy.mochymusic.floating.FloatingLyrics? = null

    // what android auto's templated player reads, handed over by the car app
    val platformSessionToken: android.media.session.MediaSession.Token
        get() = mediaSession.platformToken

    private val playerInitialized = MutableStateFlow(false)
    val isPlayerReady: kotlinx.coroutines.flow.StateFlow<Boolean> = playerInitialized.asStateFlow()

    private val _playerFlow = MutableStateFlow<ExoPlayer?>(null)
    val playerFlow = _playerFlow.asStateFlow()

    private val playerSilenceProcessors = HashMap<Player, SilenceDetectorAudioProcessor>()
    private val playerReplayGain = HashMap<Player, com.mochyy.mochymusic.eq.audio.ReplayGainTags>()
    // each player's equaliser, so it's unregistered when that player goes (crossfades make many)
    private val playerEqProcessors = HashMap<Player, CustomEqualizerAudioProcessor>()
    private val playerCrossmixProcessors = HashMap<Player, CrossmixTransitionAudioProcessor>()
    // each player's ear for the visualizer; weak, so a player let go takes its own with it
    private val playerSpectra = java.util.WeakHashMap<Player, com.mochyy.mochymusic.playback.audio.AudioSpectrum>()

    /** what [player] is playing, as bands for the visualizer (the main thread's) */
    fun spectrumOf(player: Player): com.mochyy.mochymusic.playback.audio.AudioSpectrum? = playerSpectra[player]


    private val instantSilenceSkipEnabled = MutableStateFlow(false)

    private var isAudioEffectSessionOpened = false
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private lateinit var hapticAudioProcessor: HapticAudioProcessor

    /** When a play counts for Last.fm and Libre.fm; the scrobbler skips services that aren't signed in. */
    private val scrobbleTimer by lazy { ScrobbleTimer({ scope }, scrobbler) }

    // counts each youtube song people really listen to as a play on youtube, unless app behaviour turns it off
    private val playReporter by lazy { YouTubePlayReporter({ scope }, { player.currentPosition }) }

    val automixItems = MutableStateFlow<List<MediaItem>>(emptyList())

    private var originalQueueSize: Int = 0

    private var consecutivePlaybackErr = 0
    private var retryJob: Job? = null
    private var retryCount = 0
    private var providerLookupRetries = 0
    private var silenceSkipJob: Job? = null

    private val songUrlCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String, Long>>()

    /**
     * Headers that must accompany the stream request for each track, keyed by media id.
     * googlevideo checks Origin/Referer against the client that issued the url, so a cached
     * url replayed without them is rejected.
     */
    private val songStreamHeaders = java.util.concurrent.ConcurrentHashMap<String, Map<String, String>>()

    // songs youtube refused that play their music video's sound instead, said once each time one starts
    private val musicVideoAudioSongs = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private var lastMusicVideoNoticeId: String? = null

    private val bypassCacheForQualityChange = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    private var currentMediaIdRetryCount = mutableMapOf<String, Int>()
    private val MAX_RETRY_PER_SONG = 3
    private val RETRY_DELAY_MS = 1000L
    private val STREAM_RETRY_INTERVAL_MS = 5000L

    private val recentlyFailedSongs = mutableSetOf<String>()
    private var failedSongsClearJob: Job? = null

    var castConnectionHandler: CastConnectionHandler? = null
        private set

    private val audioDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            super.onAudioDevicesAdded(addedDevices)
            if (destroying || !::player.isInitialized || castConnectionHandler?.isCasting?.value == true) return
            val hasBluetooth = addedDevices?.any {
                com.mochyy.mochymusic.playback.audio.AudioOutputs.kindOf(it.type) ==
                    com.mochyy.mochymusic.playback.audio.AudioOutputs.Kind.BLUETOOTH
            } == true

            if (hasBluetooth) {
                if (dataStore.get(ResumeOnBluetoothConnectKey, false)) {
                    if (player.playbackState == Player.STATE_READY && !player.isPlaying) {
                        player.play()
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true

        playerInitialized.value = false

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = getSystemService(NotificationManager::class.java)
                nm?.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        getString(R.string.music_player),
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
            }
            val pending = PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )
            val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.music_player))
                .setContentText("")
                .setSmallIcon(R.drawable.mochy_notification)
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
            startForeground(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to create foreground notification")
            reportException(e)
        }

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(
                this,
                { NOTIFICATION_ID },
                CHANNEL_ID,
                R.string.music_player
            )
                .apply {
                    setSmallIcon(R.drawable.mochy_notification)
                },
        )
        audioOutputs.onRouteChanged = { applyOutputRoute(it, refreshPass = true) }
        audioOutputs.preferUsb = dataStore.get(PreferUsbDacKey, false)
        audioOutputs.passthrough = dataStore.get(UsbPassthroughKey, false)
        audioOutputs.resampler = dataStore.get(HiFiResamplerKey, false)
        audioOutputs.start()
        audioPass.start()
        player = createExoPlayer()
        player.addListener(this@MusicService)
        observeOutputSettings()
        sleepTimer = SleepTimer(scope, player)
        player.addListener(sleepTimer)

        scope.launch {
            dataStore.data.map { it[MusicHapticsEnabledKey] ?: false }
                .distinctUntilChanged()
                .collect { enabled ->
                    hapticAudioProcessor.enabled = enabled
                }
        }

        scope.launch {
            dataStore.data.map { it[MusicHapticsSensitivityKey]?.toEnum(HapticSensitivity.MEDIUM) ?: HapticSensitivity.MEDIUM }
                .distinctUntilChanged()
                .collect { sensitivity ->
                    hapticAudioProcessor.sensitivity = sensitivity
                }
        }

        scope.launch {
            dataStore.data.map { it[com.mochyy.mochymusic.constants.HapticFocusKey]?.toEnum(com.mochyy.mochymusic.constants.HapticFocus.VIBE) ?: com.mochyy.mochymusic.constants.HapticFocus.VIBE }
                .distinctUntilChanged()
                .collect { focus ->
                    hapticAudioProcessor.focus = focus
                }
        }

        playerInitialized.value = true
        Timber.tag(TAG).d("Player successfully initialized")

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        setupAudioFocusRequest()

        mediaLibrarySessionCallback.apply {
            service = this@MusicService
            toggleLike = ::toggleLike
            setLiked = ::setLiked
            toggleStartRadio = ::toggleStartRadio
            toggleLibrary = ::toggleLibrary
        }
        val sessionPlayer = sessionPlayer(player)
        // vivo's music card reads the heart and its loop button off the metadata (OriginCard.kt)
        val cardPlayer = OriginCardPlayer(sessionPlayer) { id -> currentSong.value?.takeIf { it.id == id }?.song?.liked == true }
        scope.launch {
            currentSong.map { it?.id to (it?.song?.liked == true) }.distinctUntilChanged().collect { cardPlayer.refresh() }
        }
        mediaSession =
            MediaLibrarySession
                .Builder(this, cardPlayer, mediaLibrarySessionCallback)
                .setSessionActivity(
                    PendingIntent.getActivity(
                        this,
                        0,
                        Intent(this, MainActivity::class.java),
                        PendingIntent.FLAG_IMMUTABLE,
                    ),
                // the same cover comes back done at once, so a new car lyric line doesn't blank the picture while it loads again
                ).setBitmapLoader(CacheBitmapLoader(CoilBitmapLoader(this, scope)))
                .build()
        carLyrics = CarLyrics(this, CarLyricsSource(database, lyricsHelper), currentMediaMetadata, { player }, sessionPlayer, scope)
            .also { it.start() }
        floatingLyrics = com.mochyy.mochymusic.floating.FloatingLyrics(
            this, database, CarLyricsSource(database, lyricsHelper), currentMediaMetadata, playerFlow, scope,
        ).also { it.start() }
        player.repeatMode = dataStore.get(RepeatModeKey, REPEAT_MODE_OFF)

        if (dataStore.get(RememberShuffleAndRepeatKey, true)) {
            player.shuffleModeEnabled = dataStore.get(ShuffleModeKey, false)
        }

        val sessionToken = SessionToken(this, ComponentName(this, MusicService::class.java))
        val controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture.addListener({ controllerFuture.get() }, MoreExecutors.directExecutor())

        connectivityManager = getSystemService()!!
        connectivityObserver = NetworkConnectivityObserver(this)

        audioManager.registerAudioDeviceCallback(audioDeviceCallback, null)

        audioQuality = dataStore.get(AudioQualityKey).toEnum(com.mochyy.mochymusic.constants.AudioQuality.AUTO)
        ipVersion = dataStore.get(IpVersionKey).toEnum(IpVersion.AUTO)
        // a saved volume of (next to) nothing is almost always left over from the old saving bug
        // (the live volume saved while muted or mid-fade, and copied back into this setting): it
        // started the app silent, so it starts at the default instead
        playerVolume = MutableStateFlow(
            dataStore.get(PlayerVolumeKey, 1f).coerceIn(0f, 1f).let { if (it < MinRestoredVolume) 1f else it },
        )

        initializeCast()

        // Audio FX's speed and pitch, on whichever player is playing. The equalizer and effects need
        // nothing here: the store hands them to the processors live, with no seek or reload.
        scope.launch {
            // a song with its own speed and pitch plays at those, every other song at audio lab's
            combine(audioLab.playback, songTuning.all, currentMediaMetadata) { settings, tunings, metadata ->
                tunings[metadata?.id]?.let { PlaybackParameters(it.speed, it.pitch) }
                    ?: PlaybackParameters(settings.speed, settings.pitch)
            }
                .distinctUntilChanged()
                // a dragged slider sends dozens of steps a second; the player takes the latest one at most every SpeedApplyGapMs
                .conflate()
                .collect { params ->
                    if (player.playbackParameters != params) player.playbackParameters = params
                    delay(SpeedApplyGapMs)
                }
        }

        // a song given its own eq preset in its edit sheet plays through it, every other song through audio lab's curve
        scope.launch {
            combine(songTuning.eqPresets, audioLab.presets, currentMediaMetadata) { picks, _, metadata ->
                picks[metadata?.id]?.let(audioLab::presetById)
            }
                .distinctUntilChanged()
                .collect { audioLab.useSongPreset(it) }
        }

        // the hand edits from the song edit sheet, kept in memory for building queue items and the player
        com.mochyy.mochymusic.songedit.SongEdits.follow(database, scope)

        scope.launch {
            connectivityObserver.networkStatus.collect { isConnected ->
                isNetworkConnected.value = isConnected
                if (isConnected && waitingForNetworkConnection.value) {
                    triggerRetry()
                }

                if (isConnected) {
                    if (playerInitialized.value && player.playWhenReady) {
                        // Time spent offline should not use up a playlist's pagination attempts.
                        runwayRetries = 0
                        ensureQueueRunway()
                    }
                    discordPresence.nudge()
                }
            }
        }

        var isFirstQualityEmit = true
        scope.launch {
            dataStore.data
                .map { it[AudioQualityKey]?.let { value ->
                    com.mochyy.mochymusic.constants.AudioQuality.entries.find { it.name == value }
                } ?: com.mochyy.mochymusic.constants.AudioQuality.AUTO }
                .distinctUntilChanged()
                .collect { newQuality ->
                    val oldQuality = audioQuality
                    audioQuality = newQuality

                    if (isFirstQualityEmit) {
                        isFirstQualityEmit = false
                        Timber.tag("MusicService").i("QUALITY INIT: $newQuality")
                        return@collect
                    }

                    Timber.tag("MusicService").i("QUALITY CHANGED: $oldQuality -> $newQuality")

                    val target = player
                    val entry = providerHandoffHost.currentTarget() ?: return@collect
                    val mediaId = entry.mediaId
                    val youtubeId = com.mochyy.mochymusic.modules.SourceModules.YouTubeId
                    songUrlCache.remove(mediaId)
                    // This setting only changes YouTube streaming. Keep downloads, a module
                    // stream, or an explicit per-song quality choice playing on its own route.
                    if (isFullyDownloaded(mediaId) || handoffFor(mediaId) != null ||
                        forcedRoutes[mediaId]?.youtubeQuality != null ||
                        resolvedSourceIds[mediaId]?.let { it != youtubeId } == true
                    ) return@collect
                    val position = target.currentPosition
                    bypassCacheForQualityChange.add(mediaId)
                    target.stop()
                    withContext(Dispatchers.IO) {
                        runCatching { playerCache.removeResource(mediaId) }
                            .onFailure { Timber.tag("MusicService").e(it, "Failed to clear cache for $mediaId") }
                    }
                    // The I/O above can outlast a skip, queue replacement or a provider switch.
                    if (player !== target || providerHandoffHost.currentTarget() != entry ||
                        handoffFor(mediaId) != null || target.playbackState != Player.STATE_IDLE
                    ) return@collect
                    // The same queue entry may have moved while the cache was cleared.
                    val index = target.currentMediaItemIndex
                    if (index !in 0 until target.mediaItemCount) return@collect
                    target.seekTo(index, position)
                    target.prepare()
                }
        }

        scope.launch {
            dataStore.data
                .map { it[IpVersionKey]?.toEnum(IpVersion.AUTO) ?: IpVersion.AUTO }
                .distinctUntilChanged()
                .collect { newIpVersion ->
                    val oldIpVersion = ipVersion
                    ipVersion = newIpVersion

                    if (isFirstQualityEmit) return@collect

                    Timber.tag("MusicService").i("IP VERSION CHANGED: $oldIpVersion -> $newIpVersion")

                    val mediaId = player.currentMediaItem?.mediaId ?: return@collect
                    val currentPosition = player.currentPosition
                    val currentIndex = player.currentMediaItemIndex
                    val wasPlaying = player.isPlaying

                    songUrlCache.remove(mediaId)

                    player.stop()
                    player.seekTo(currentIndex, currentPosition)
                    player.prepare()
                    if (wasPlaying) {
                        player.play()
                    }
                }
        }

        combine(playerVolume, isMuted) { volume, muted ->
            if (muted) 0f else volume
        }.collectLatest(scope) {
            // a running pause or skip fade sets the volume itself each frame, scaled by this; so does a
            // crossfade, and setting it here mid-blend jumped the new song straight to full
            if (!transport.isFading && !isCrossfading) player.volume = it
            if (crossmixDirector.isTransitioning) fadingPlayer?.volume = it
        }

        playerVolume.debounce(1000).collect(scope) { volume ->
            dataStore.edit { settings ->
                settings[PlayerVolumeKey] = volume
            }
        }

        val labSound = combine(
            combine(audioLab.eq, audioLab.reverb, audioLab.loudness, ::Triple),
            audioLab.spatial,
            audioLab.playback,
            audioLab.volume,
        ) { (eq, reverb, loudness), spatial, playback, volume -> LabSound(eq, reverb, loudness, spatial, playback, volume) }
        combine(dataStore.data, labSound, playerVolume) { prefs, lab, volume -> passBlockersOf(prefs, lab, volume) }
            .distinctUntilChanged()
            .collect(scope) { _passBlockers.value = it }

        combine(dataStore.data, passBlockers) { prefs, blockers ->
            PassSettings(
                enabled = prefs[UsbPassthroughKey] ?: false,
                mode = prefs[AudioPassModeKey].toEnum(AudioPassMode.Default),
                blocked = blockers.isNotEmpty(),
                fixedVolume = prefs[AudioPassFixedVolumeKey] ?: false,
            )
        }.distinctUntilChanged().collect(scope) { audioPass.update(it.enabled, it.mode, it.blocked, it.fixedVolume) }

        currentSong.debounce(1000).collect(scope) { song ->
            updateNotification()
            updateWidgetUI()
        }

        combine(
            currentMediaMetadata.distinctUntilChangedBy { it?.id },
            dataStore.data.map { it[ShowLyricsKey] ?: false }.distinctUntilChanged(),
        ) { mediaMetadata, showLyrics ->
            mediaMetadata to showLyrics
        }.collectLatest(scope) { (mediaMetadata, showLyrics) ->
            if (showLyrics && mediaMetadata != null && database.lyrics(mediaMetadata.id)
                    .first() == null
            ) {
                val lyricsWithProvider = lyricsHelper.getLyrics(mediaMetadata)
                // offline: nothing was found because nothing was asked; try again when online
                if (lyricsWithProvider.provider != com.mochyy.mochymusic.lyrics.LyricsHelper.NoConnectionProvider) {
                    database.query {
                        upsert(
                            LyricsEntity(
                                id = mediaMetadata.id,
                                lyrics = lyricsWithProvider.lyrics,
                                provider = lyricsWithProvider.provider,
                            ),
                        )
                    }
                }
            }
        }

        dataStore.data
            .map { prefs ->
                Triple(
                    prefs[TransportFadeEnabledKey] ?: TransportFadeDefaultEnabled,
                    transportFadeSeconds(prefs[TransportFadeSecondsKey] ?: TransportFadeDefaultSeconds),
                    activeTransportEffect(prefs),
                )
            }
            .distinctUntilChanged()
            .collect(scope) { (enabled, seconds, effect) ->
                transport.enabled = enabled
                transport.lengthMs = seconds * 1_000f
                transport.effect = effect
            }

        dataStore.data
            .map { (it[SkipSilenceKey] ?: false) to (it[SkipSilenceInstantKey] ?: false) }
            .distinctUntilChanged()
            .collectLatest(scope) { (skipSilence, instantSkip) ->
                player.skipSilenceEnabled = skipSilence
                secondaryPlayer?.skipSilenceEnabled = skipSilence

                val enableInstant = skipSilence && instantSkip
                instantSilenceSkipEnabled.value = enableInstant

                playerSilenceProcessors.values.forEach { processor ->
                    processor.instantModeEnabled = enableInstant
                    if (!enableInstant) {
                        processor.resetTracking()
                    }
                }

                if (!enableInstant) {
                    silenceSkipJob?.cancel()
                }
            }

        dataStore.data
            .map { it[MixWithOtherAppsKey] ?: false }
            .distinctUntilChanged()
            .collect(scope) { mix ->
                mixWithOtherApps = mix
                if (mix) startMixingWithOtherApps() else stopMixingWithOtherApps()
            }

        combine(
            currentFormat,
            dataStore.data
                .map { it[AudioNormalizationKey] ?: true }
                .distinctUntilChanged(),
        ) { format, normalizeAudio ->
            format to normalizeAudio
        }.collectLatest(scope) { (format, normalizeAudio) ->
            audioFx.normalize = normalizeAudio
            setupLoudnessEnhancer()
        }

        // offload skips the app's own audio processing, so the equalizer and effects would go silent
        combine(
            dataStore.data.map { it[AudioOffload] ?: false },
            dataStore.data.map { transitionModeOf(it) != CrossmixMode.OFF },
            audioLab.shapesSound,
        ) { offloadPref, transitions, shapesSound ->
             offloadPref && !transitions && !shapesSound
        }.distinctUntilChanged()
        .collectLatest(scope) { useOffload ->
             player.setOffloadEnabled(useOffload)
             secondaryPlayer?.setOffloadEnabled(useOffload)
        }

        // Discord needs the artist's picture (from the library) and the codec (from the decoder),
        // which both turn up a moment after the song starts
        currentSong.collect(scope) { publishPresence() }
        streamFacts.map { facts -> player.currentMediaItem?.mediaId?.let { facts[it] } }
            .distinctUntilChanged()
            .collect(scope) { publishPresence() }

        dataStore.data
            .map { prefs ->
                Triple(
                    prefs[ScrobbleDelayPercentKey] ?: ScrobbleTimer.DEFAULT_PLAYED_FRACTION,
                    prefs[ScrobbleMinSongDurationKey] ?: ScrobbleTimer.DEFAULT_MIN_SONG_SECONDS,
                    prefs[ScrobbleDelaySecondsKey] ?: ScrobbleTimer.DEFAULT_MAX_WAIT_SECONDS,
                )
            }
            .distinctUntilChanged()
            .collect(scope) { (playedFraction, minSongSeconds, maxWaitSeconds) ->
                scrobbleTimer.playedFraction = playedFraction
                scrobbleTimer.minSongSeconds = minSongSeconds
                scrobbleTimer.maxWaitSeconds = maxWaitSeconds
            }

        dataStore.data
            .map { prefs ->
                // offline mode keeps every play on the phone too
                val enabled = (prefs[YtReportPlaysKey] ?: true) && prefs[OfflineModeKey] != true
                enabled to ((prefs[HistoryDuration] ?: 30f) * 1000).toLong()
            }
            .distinctUntilChanged()
            .collect(scope) { (enabled, countAfterMs) ->
                playReporter.isEnabled = enabled
                playReporter.countAfterMs = countAfterMs
            }

        dataStore.data.map { prefs ->
            val mode = transitionModeOf(prefs)
            val enabled = mode != CrossmixMode.OFF
            val duration = when (mode) {
                CrossmixMode.AUTO_CROSSFADE -> 5f
                CrossmixMode.MANUAL_CROSSFADE -> (prefs[CrossfadeDurationKey] ?: 5f).coerceIn(1f, 30f)
                CrossmixMode.CROSSMIX -> (prefs[CrossfadeDurationKey] ?: 12f).coerceIn(8f, 20f)
                CrossmixMode.OFF -> prefs[CrossfadeDurationKey] ?: 5f
            }
            CrossfadeConfig(mode, enabled, duration, prefs[CrossfadeGaplessKey] ?: true)
        }
            .distinctUntilChanged()
            .collect(scope) { config ->
                crossmixMode = config.mode
                crossfadeEnabled = config.enabled
                crossfadeDuration = config.durationSeconds * 1000f
                crossfadeGapless = config.disableForGaplessAlbums
            }

        // how crossmix mixes; a change re-plans the mix coming up the new way
        dataStore.data.map { prefs ->
            CrossmixSettings(
                length = prefs[CrossmixLengthKey].toEnum(CrossmixLength.MEDIUM),
                tempoMatch = prefs[CrossmixTempoMatchKey].toEnum(CrossmixTempoMatch.FULL),
                style = prefs[CrossmixStyleKey]?.takeIf { it != CrossmixStyleAuto }?.let { name -> CrossmixStyle.entries.firstOrNull { it.name == name } },
                stunts = prefs[CrossmixStuntsKey] ?: true,
                alwaysMix = prefs[CrossmixAlwaysMixKey] ?: true,
            )
        }
            .distinctUntilChanged()
            .collect(scope) { settings ->
                val changed = crossmixSettings != settings
                crossmixSettings = settings
                if (changed) crossmixDirector.onSettingsChanged()
            }

        dataStore.data
            .map { Triple(it[SkipBlendKey] ?: false, it[StudioForVideosKey] ?: false, it[SkipBlendAheadKey] ?: 1) }
            .distinctUntilChanged()
            .collect(scope) { (blend, studio, ahead) ->
                skipBlend = blend
                studioForVideos = studio
                blendAhead = ahead.coerceIn(1, SkipBlendAheadMax)
                if (blend) prefetchNeighbours() else prefetchJob?.cancel()
            }

        if (dataStore.get(PersistentQueueKey, true)) {
            val restoreGeneration = queueGeneration
            val initialVolume = playerVolume.value
            scope.launch {
                val (restoredQueue, restoredAutomix, restoredVolume) = withContext(Dispatchers.IO) {
                    synchronized(queueFileLock) {
                        val state = readQueueFile<PersistPlayerState>(PERSISTENT_PLAYER_STATE_FILE)
                        val queue = readQueueFile<PersistQueue>(PERSISTENT_QUEUE_FILE)
                            ?.takeIf { it.items.isNotEmpty() }?.let { saved ->
                                val index = saved.mediaItemIndex.coerceIn(saved.items.indices)
                                val resume = state?.takeIf { it.currentMediaItemIndex == index && it.currentPosition >= 0L }
                                runCatching {
                                    saved.copy(mediaItemIndex = index, position = resume?.currentPosition ?: saved.position)
                                        .toQueue().withRestoredManualSongs()
                                }.onFailure { Timber.tag(TAG).w(it, "Failed to restore persisted queue") }.getOrNull()
                            }
                        val automix = readQueueFile<PersistQueue>(PERSISTENT_AUTOMIX_FILE)?.let { saved ->
                            runCatching { saved.items.map { it.toMediaItem() } }
                                .onFailure { Timber.tag(TAG).w(it, "Failed to restore automix queue") }.getOrNull()
                        }
                        Triple(queue, automix, state?.volume)
                    }
                }
                if (destroying || restoreGeneration != queueGeneration || player.mediaItemCount != 0 ||
                    !dataStore.get(PersistentQueueKey, true)
                ) return@launch
                if (restoredAutomix != null && automixItems.value.isEmpty()) automixItems.value = restoredAutomix
                if (restoredVolume != null && restoredVolume in MinRestoredVolume..1f && playerVolume.value == initialVolume) {
                    playerVolume.value = restoredVolume
                }
                restoredQueue?.let { playQueue(it, playWhenReady = player.playWhenReady) }
            }
        }

        // Paused playback has no timer. Queue edits and the final position are saved by events.
        scope.launch {
            combine(
                dataStore.data.map { it[PersistentQueueKey] ?: true },
                queueSavePlaying,
            ) { persistent, playing -> persistent && playing }
                .distinctUntilChanged()
                .collectLatest { saving ->
                    if (!saving) return@collectLatest
                    while (isActive) {
                        delay(10.seconds)
                        if (player.isPlaying) saveQueueToDisk(onlyChanges = true)
                    }
                }
        }

        automixItems.debounce(1000).collect(scope) {
            if (!destroying && dataStore.get(PersistentQueueKey, true)) saveQueueToDisk(onlyChanges = true)
        }
    }

    private fun createExoPlayer(publish: Boolean = true): ExoPlayer {
        val eqProcessor = CustomEqualizerAudioProcessor()
        equalizerService.addAudioProcessor(eqProcessor)
        // this player's song's ReplayGain, read from its file's tags when its tracks change
        val replayGain = com.mochyy.mochymusic.eq.audio.ReplayGainTags()
        val fxProcessors = arrayOf<androidx.media3.common.audio.AudioProcessor>(
            SpatialAudioProcessor(audioFx),
            ReverbAudioProcessor(audioFx),
            LoudnessAudioProcessor(audioFx),
        )

        val silenceProcessor = SilenceDetectorAudioProcessor { handleLongSilenceDetected() }
        val crossmixProcessor = CrossmixTransitionAudioProcessor()
        val spectrum = com.mochyy.mochymusic.playback.audio.AudioSpectrum()
        val inspector = StreamInspector()
        val platformOutput = PlatformOutputMonitor { output ->
            if (::player.isInitialized && platformOutputs[player] === output) {
                applyOutputRoute(audioOutputs.preferredDevice())
            }
        }

        val hapticVibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        hapticAudioProcessor = HapticAudioProcessor { amplitude, isBassKick ->
            scope.launch(Dispatchers.Default) {
                delay(150)
                try {
                    if (hapticVibrator.hasVibrator()) {
                        val scale = (amplitude / 255f).coerceIn(0.01f, 1f)

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            if (isBassKick && hapticVibrator.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_CLICK)) {

                                val effect = VibrationEffect.startComposition()
                                    .addPrimitive(VibrationEffect.Composition.PRIMITIVE_CLICK, scale)
                                    .compose()
                                hapticVibrator.vibrate(effect)
                            } else if (hapticVibrator.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_LOW_TICK)) {

                                val effect = VibrationEffect.startComposition()
                                    .addPrimitive(VibrationEffect.Composition.PRIMITIVE_LOW_TICK, scale)
                                    .compose()
                                hapticVibrator.vibrate(effect)
                            } else if (hapticVibrator.areAllPrimitivesSupported(VibrationEffect.Composition.PRIMITIVE_TICK)) {
                                val effect = VibrationEffect.startComposition()
                                    .addPrimitive(VibrationEffect.Composition.PRIMITIVE_TICK, scale)
                                    .compose()
                                hapticVibrator.vibrate(effect)
                            } else if (hapticVibrator.hasAmplitudeControl()) {
                                hapticVibrator.vibrate(VibrationEffect.createOneShot(20, amplitude))
                            }
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hapticVibrator.hasAmplitudeControl()) {
                            hapticVibrator.vibrate(VibrationEffect.createOneShot(20, amplitude))
                        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O && isBassKick) {
                            // Android 7 has no VibrationEffect, so it gets a plain buzz on the kick only.
                            // Newer phones without amplitude control stay silent, as they always have.
                            @Suppress("DEPRECATION")
                            hapticVibrator.vibrate(20)
                        }
                    }
                } catch (e: Exception) {
                    Timber.e(e, "Error processing haptics")
                }
            }
        }

        val prefs = PreferencesCache.current(dataStore)
        val skipSilence = prefs[SkipSilenceKey] ?: false
        silenceProcessor.instantModeEnabled = skipSilence && prefs[SkipSilenceInstantKey] == true

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(createMediaSourceFactory())
            .setRenderersFactory(createRenderersFactory(eqProcessor, fxProcessors, silenceProcessor, hapticAudioProcessor, crossmixProcessor, replayGain, spectrum, inspector, platformOutput))
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                false,
            )
            .setSeekBackIncrementMs(5000)
            .setSeekForwardIncrementMs(5000)
            .setDeviceVolumeControlEnabled(true)
            // wake the playback loop when the audio buffer needs more, not every 10 ms: it was a third of a core in the background
            .experimentalSetDynamicSchedulingEnabled(true)
            .build()

        player.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                replayGain.update(tracks)
                val mediaId = player.currentMediaItem?.mediaId
                val format = StreamFacts.selectedAudio(tracks)
                val handoff = mediaId?.let(::handoffFor)
                if (handoff != null) {
                    if (player === this@MusicService.player && handoff.resolvedFrom != null) {
                        if (format != null && tracks.isTypeSupported(C.TRACK_TYPE_AUDIO, true)) {
                            handoff.facts = playbackFacts(handoff.facts, format)
                        } else if (tracks.containsType(C.TRACK_TYPE_AUDIO) && !tracks.isTypeSupported(C.TRACK_TYPE_AUDIO, true)) {
                            handoff.ready.complete(ProviderSwitch.HandoffResult.Failed(getString(R.string.pc_force_unsupported_audio)))
                        }
                    }
                    return
                }
                if (mediaId != null && format != null) recordDecodedFormat(mediaId, format)
                // audio that no decoder on this phone takes isn't an error to the player: the song
                // "plays" on in silence. Only the main player's song: a Crossmix's next one waits
                if (mediaId != null && player === this@MusicService.player &&
                    tracks.containsType(C.TRACK_TYPE_AUDIO) &&
                    !tracks.isTypeSupported(C.TRACK_TYPE_AUDIO, true)
                ) {
                    onUndecodableAudio(mediaId, tracks)
                } else if (mediaId != null && format != null && tracks.isTypeSupported(C.TRACK_TYPE_AUDIO, true)) {
                    announceDecoderNotice(mediaId)
                }
            }
        })
        playerReplayGain[player] = replayGain
        playerSilenceProcessors[player] = silenceProcessor
        playerCrossmixProcessors[player] = crossmixProcessor
        playerSpectra[player] = spectrum
        playerEqProcessors[player] = eqProcessor
        playerInspectors[player] = inspector
        platformOutputs[player] = platformOutput
        player.addAnalyticsListener(inspector)
        player.setPreferredAudioDevice(audioOutputs.preferredDevice())

        val transitions = transitionModeOf(prefs) != CrossmixMode.OFF
        player.setOffloadEnabled(!transitions && prefs[AudioOffload] == true)
        player.skipSilenceEnabled = skipSilence
        player.addAnalyticsListener(PlaybackStatsListener(false, this))
        if (publish) _playerFlow.value = player
        return player
    }

    // the usb dac switches, and when 32-bit float may pass: media3's float path skips every audio processor
    private fun observeOutputSettings() {
        dataStore.data
            .map { Triple(it[PreferUsbDacKey] ?: false, it[UsbPassthroughKey] ?: false, it[HiFiResamplerKey] ?: false) }
            .distinctUntilChanged()
            .collect(scope) { (preferUsb, passthrough, resampler) ->
                audioOutputs.preferUsb = preferUsb
                audioOutputs.passthrough = passthrough
                audioOutputs.resampler = resampler
            }
        val wantsFloat = dataStore.data.map { prefs ->
            (prefs[HiResOutputKey] ?: false) &&
                !(prefs[SkipSilenceKey] ?: false) &&
                !(prefs[MusicHapticsEnabledKey] ?: false) &&
                activeTransportEffect(prefs) == TransportEffect.OFF &&
                transitionModeOf(prefs) != CrossmixMode.CROSSMIX
        }
        combine(wantsFloat, audioLab.shapesSound, audioLab.playback) { wants, shapesSound, playback ->
            wants && !shapesSound && playback.speed == 1f && playback.pitch == 1f
        }.distinctUntilChanged().collect(scope) { audioOutputs.floatAllowed = it }
    }

    private fun setupAudioFocusRequest() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setOnAudioFocusChangeListener { focusChange ->
                    handleAudioFocusChange(focusChange)
                }
                .setAcceptsDelayedFocusGain(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            legacyFocusListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
                handleAudioFocusChange(focusChange)
            }
        }
    }

    private fun handleAudioFocusChange(focusChange: Int) {
        // a callback still on its way after mixing let go of focus, it would pause us for the other app
        if (destroying || !::player.isInitialized || mixWithOtherApps) return
        when (focusChange) {

            AudioManager.AUDIOFOCUS_GAIN,
            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT -> {
                hasAudioFocus = true

                if (focusResume != null && !reentrantFocusGain) {
                    reentrantFocusGain = true
                    scope.launch {
                        delay(300)
                        reentrantFocusGain = false
                        if (hasAudioFocus) {
                            val pending = focusResume
                            focusResume = null
                            if (pending?.canResume() == true) transport.play()
                        }
                    }
                }

                player.volume = if (isMuted.value) 0f else playerVolume.value
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS -> {
                focusResume = null
                if (player.playWhenReady) player.pause()
                abandonAudioFocus()
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                hasAudioFocus = false
                pauseForInterruption()?.let { focusResume = it }
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                hasAudioFocus = false
                if (player.playWhenReady) {
                    player.volume = if (isMuted.value) 0f else (playerVolume.value * 0.2f)
                }
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK -> {
                hasAudioFocus = true
                player.volume = if (isMuted.value) 0f else playerVolume.value
                lastAudioFocusState = focusChange
            }
        }
    }

    /** the volume the playing song should be at now: the user's, nothing while muted, a fifth while ducked */
    private fun targetVolume(): Float = when {
        isMuted.value -> 0f
        !hasAudioFocus && lastAudioFocusState == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> playerVolume.value * 0.2f
        else -> playerVolume.value
    }

    private fun requestAudioFocus(): Boolean {
        // mixing never asks, holding focus is exactly what lets android pause or fade us for another app
        if (mixWithOtherApps) return true
        if (hasAudioFocus) return true

        val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = audioFocusRequest ?: return false
            audioManager.requestAudioFocus(request)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                legacyFocusListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
        hasAudioFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        // granted straight back after a duck: no GAIN callback follows, and the player stayed
        // at a fifth of its volume for good
        if (hasAudioFocus && lastAudioFocusState == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            player.volume = if (isMuted.value) 0f else playerVolume.value
            lastAudioFocusState = AudioManager.AUDIOFOCUS_GAIN
        }
        return hasAudioFocus
    }

    private fun abandonAudioFocus() {
        // let go even after a short loss, or the request stays queued and android hands focus back later
        if (!::audioManager.isInitialized) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            legacyFocusListener?.let { audioManager.abandonAudioFocus(it) }
        }
        hasAudioFocus = false
    }

    // holding focus while mixing would get us faded out on android 12+ the moment another app starts
    private fun startMixingWithOtherApps() {
        abandonAudioFocus()
        focusResume = null
        if (lastAudioFocusState == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            player.volume = if (isMuted.value) 0f else playerVolume.value
        }
        lastAudioFocusState = AudioManager.AUDIOFOCUS_NONE
        callWatcher.start()
    }

    private fun stopMixingWithOtherApps() {
        callWatcher.stop()
        callResume = null
        if (player.playWhenReady) requestAudioFocus()
    }

    private inner class InterruptionResume(val target: Player) {
        private val occurrence = providerOccurrence
        private val pauseGeneration = transport.pauseGeneration

        fun canResume(): Boolean = stillCurrent() && !target.playWhenReady

        fun stillCurrent(): Boolean = !destroying && player === target &&
            providerOccurrence == occurrence && transport.pauseGeneration == pauseGeneration &&
            castConnectionHandler?.isCasting?.value != true
    }

    private fun pauseForInterruption(): InterruptionResume? {
        if (destroying || !player.playWhenReady || player.playbackState == Player.STATE_ENDED ||
            castConnectionHandler?.isCasting?.value == true
        ) return null
        val resume = InterruptionResume(player)
        player.pause()
        return resume
    }

    // While mixing, Android audio focus does not pause us for a call.
    private fun onCallChanged(inCall: Boolean) {
        if (destroying || !mixWithOtherApps) return
        if (inCall) {
            pauseForInterruption()?.let { callResume = it }
        } else {
            val pending = callResume
            callResume = null
            if (pending?.canResume() == true) transport.play()
        }
    }

    /** Marks the songs the user had queued by hand when the queue was saved, so a restart doesn't turn them into ordinary ones. */
    private fun Queue.withRestoredManualSongs(): Queue {
        if (this !is ListQueue) return this
        val manual = readQueueFile<IntArray>(PERSISTENT_MANUAL_QUEUE_FILE)?.toSet().orEmpty()
        if (manual.isEmpty()) return this
        return ListQueue(
            title = title,
            items = items.mapIndexed { i, item -> if (i in manual) item.withManualQueued(true) else item },
            startIndex = startIndex,
            position = position,
        )
    }

    private inline fun <reified T> readQueueFile(name: String): T? = try {
        androidx.core.util.AtomicFile(filesDir.resolve(name)).openRead().use { input ->
            ObjectInputStream(input).use { it.readObject() as T }
        }
    } catch (_: FileNotFoundException) {
        null
    } catch (e: Exception) {
        Timber.tag(TAG).w(e, "Failed to read %s", name)
        null
    }

    private fun writeQueueFile(name: String, value: Serializable) {
        val file = androidx.core.util.AtomicFile(filesDir.resolve(name))
        runCatching {
            val stream = file.startWrite()
            try {
                ObjectOutputStream(stream).apply {
                    writeObject(value)
                    flush()
                }
                file.finishWrite(stream)
            } catch (e: Exception) {
                file.failWrite(stream)
                throw e
            }
        }.onFailure { Timber.tag(TAG).e(it, "Failed to save %s", name) }
    }

    fun hasAudioFocusForPlayback(): Boolean {
        return hasAudioFocus
    }

    private fun waitOnNetworkError() {
        if (!player.playWhenReady || castConnectionHandler?.isCasting?.value == true ||
            waitingForNetworkConnection.value
        ) return

        if (retryCount >= MAX_RETRY_COUNT) {
            Timber.tag(TAG).w("Max retry count ($MAX_RETRY_COUNT) reached, stopping playback")
            stopOnError()
            retryCount = 0
            return
        }

        waitingForNetworkConnection.value = true
        if (!isNetworkConnected.value || retryCount >= 2) {
            com.mochyy.mochymusic.ui.component.TopToaster.error(getString(
                if (isNetworkConnected.value) R.string.stream_retry_connected else R.string.stream_retry_offline,
            ))
        }

        retryJob?.cancel()
        val target = player
        val occurrence = providerOccurrence
        retryJob = scope.launch {

            val delayMs = minOf(3000L * (1 shl retryCount), 30000L)
            Timber.tag(TAG).d("Waiting ${delayMs}ms before retry attempt ${retryCount + 1}/$MAX_RETRY_COUNT")
            delay(delayMs)

            if (player !== target || providerOccurrence != occurrence) return@launch
            if (isNetworkConnected.value && waitingForNetworkConnection.value) {
                triggerRetry()
            }
        }
    }

    private fun clearNetworkWait() {
        if (!waitingForNetworkConnection.value) return
        waitingForNetworkConnection.value = false
        retryJob?.cancel()
        retryJob = null
    }

    private fun triggerRetry() {
        if (!waitingForNetworkConnection.value) return
        val target = player
        val mediaId = target.currentMediaItem?.mediaId ?: return
        if (target.playbackState != Player.STATE_IDLE || handoffFor(mediaId) != null) return

        clearNetworkWait()
        if (!target.playWhenReady || castConnectionHandler?.isCasting?.value == true) return
        retryCount++
        if (retryCount > 3) {
            Timber.tag(TAG).d("Retry count > 3, attempting to refresh stream URL")
            songUrlCache.remove(mediaId)
            target.seekTo(target.currentMediaItemIndex, target.currentPosition)
        }
        target.prepare()
    }

    // Retry a temporary lookup on the same queue occurrence without changing play intent.
    private fun retryProviderLookup(): Boolean {
        val target = player
        val mediaId = target.currentMediaItem?.mediaId ?: return false
        if (!target.playWhenReady || providerLookupRetries >= MaxProviderLookupRetries ||
            com.mochyy.mochymusic.utils.OfflineMode.isOn || castConnectionHandler?.isCasting?.value == true
        ) return false

        val occurrence = providerOccurrence
        val pauseGeneration = transport.pauseGeneration
        val wait = 400L shl providerLookupRetries
        providerLookupRetries++
        retryJob?.cancel()
        retryJob = scope.launch {
            delay(wait)
            if (player !== target || providerOccurrence != occurrence || !target.playWhenReady ||
                target.playbackState != Player.STATE_IDLE || transport.pauseGeneration != pauseGeneration ||
                handoffFor(mediaId) != null || castConnectionHandler?.isCasting?.value == true
            ) return@launch
            if (com.mochyy.mochymusic.utils.OfflineMode.isOn) {
                val next = nextOfflineIndex()
                if (next != C.INDEX_UNSET) playOfflineSong(next) else failStream(allowAutoRecovery = false)
                return@launch
            }
            if (!connectivityObserver.isCurrentlyConnected()) {
                waitOnNetworkError()
                return@launch
            }
            songUrlCache.remove(mediaId)
            // Reconsider sources that were passed over after a transient failure.
            failedSources.remove(mediaId)
            failedSourcesAt.remove(mediaId)
            target.prepare()
        }
        return true
    }

    /** Moves past a stream that never came back, unless it has failed too many times in a row. */
    private fun skipAfterFailure() {
        consecutivePlaybackErr += 2
        val nextWindowIndex = player.nextMediaItemIndex

        if (consecutivePlaybackErr <= MAX_CONSECUTIVE_ERR && nextWindowIndex != C.INDEX_UNSET) {
            player.seekTo(nextWindowIndex, C.TIME_UNSET)
            player.prepare()

            if (castConnectionHandler?.isCasting?.value != true) {
                player.play()
            }
            return
        }

        player.pause()
        consecutivePlaybackErr = 0
    }

    /**
     * The song's audio is in a format no decoder on this phone takes (a FLAC on a phone without a
     * FLAC decoder, a rate or channel count beyond the phone's decoders). The player doesn't count
     * that as an error - the song plays on, in silence - so it's made one: a module's stream gives
     * way to the next provider (YouTube at the latest), and anything else fails like a song that
     * can't be played, saying why, and moves on.
     */
    private fun onUndecodableAudio(mediaId: String, tracks: androidx.media3.common.Tracks) {
        val audio = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO }?.takeIf { it.length > 0 }?.getTrackFormat(0)
        val what = listOfNotNull(
            audio?.sampleMimeType?.substringAfter('/'),
            audio?.sampleRate?.takeIf { it > 0 }?.let { "$it Hz" },
            audio?.channelCount?.takeIf { it > 0 }?.let { "$it ch" },
        ).joinToString(" ").ifBlank { "unknown format" }
        Timber.tag(TAG).w("No decoder on this phone for $mediaId's audio ($what)")
        // Leave the callback before re-preparing the player, and only act on the same queue entry.
        val target = player
        val occurrence = providerOccurrence
        scope.launch {
            if (player !== target || providerOccurrence != occurrence || target.currentMediaItem?.mediaId != mediaId) return@launch
            noteMissingDecoder(mediaId, StreamFacts.codecOf(audio?.sampleMimeType, audio?.codecs), audio?.sampleRate)
            if (forceFallBack(mediaId, announce = !decoderNotices.containsKey(mediaId))) return@launch
            lastPlaybackError = PlaybackException(
                "This phone can't decode this song's audio ($what)",
                null,
                PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            )
            failStream()
        }
    }

    /** a player error that's this phone's decoders turning the song's format down */
    private fun isDecoderError(e: PlaybackException) = e.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
        e.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ||
        e.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
        e.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED

    /**
     * Remembers that [mediaId]'s stream from the provider it was handed to is [codec] this phone
     * can't decode, so the next stream's toast says why it's playing instead.
     */
    private fun noteMissingDecoder(mediaId: String, codec: String?, sampleRate: Int?, from: String? = resolvedSourceIds[mediaId]) {
        codec ?: return
        val rate = sampleRate?.takeIf { it > 0 }
        val text = when {
            !com.mochyy.mochymusic.modules.DeviceDecoders.canPlay(codec) -> "No $codec decoder available on this phone"
            rate != null && !com.mochyy.mochymusic.modules.DeviceDecoders.canPlay(codec, rate) ->
                "No $codec decoder for ${if (rate % 1000 == 0) "${rate / 1000}" else "%.1f".format(rate / 1000f)} kHz on this phone"
            else -> "This phone can't decode this $codec"
        }
        decoderNotices[mediaId] = DecoderNotice(text, from)
    }

    /**
     * "No FLAC decoder available on this phone · playing in OPUS on YouTube Music", once
     * [mediaId] plays from somewhere other than the stream this phone couldn't decode.
     */
    private fun announceDecoderNotice(mediaId: String) {
        val notice = decoderNotices.remove(mediaId) ?: return
        val source = resolvedSourceIds[mediaId] ?: return
        if (source == notice.from) return
        val codec = streamFacts.value[mediaId]?.codec?.let { " in $it" }.orEmpty()
        showBanner("${notice.text} · playing$codec on ${sourceModules.nameOf(source)}")
    }

    /** A failed stream the player has given up on: says so, and skips after the timeout unless that's turned off. */
    private fun failStream(allowAutoRecovery: Boolean = true) {
        val target = player
        val occurrence = providerOccurrence
        val pauseGeneration = transport.pauseGeneration
        val wasPlaying = target.playWhenReady
        target.pause()
        announceStreamFailure()
        clearStreamFailure()
        if (!wasPlaying || !allowAutoRecovery) return
        fun canRecover(): Boolean = player === target && providerOccurrence == occurrence &&
            transport.pauseGeneration == pauseGeneration && !target.playWhenReady &&
            target.currentMediaItem?.mediaId?.let(::handoffFor) == null &&
            castConnectionHandler?.isCasting?.value != true
        if (dataStore.get(DontSkipOnFailureKey, false)) {
            // staying on it means trying it again every few seconds until it plays: loading it
            // again ends this job, and a failure starts the next wait
            failureJob = scope.launch {
                delay(STREAM_RETRY_INTERVAL_MS)
                if (!canRecover()) return@launch
                Timber.tag(TAG).d("Retrying the failed stream")
                player.prepare()
                player.play()
            }
            return
        }
        if (player.nextMediaItemIndex == C.INDEX_UNSET) return

        val timeoutMs = dataStore.get(StreamFailureTimeoutKey, 6).coerceIn(5, 20) * 1000L
        streamFailure.value = StreamFailure(android.os.SystemClock.elapsedRealtime(), timeoutMs)
        failureJob = scope.launch {
            delay(timeoutMs)
            streamFailure.value = null
            if (!canRecover()) return@launch
            Timber.tag(TAG).d("Stream failure timed out, skipping to next track")
            skipAfterFailure()
        }
    }

    private fun clearStreamFailure() {
        failureJob?.cancel()
        failureJob = null
        streamFailure.value = null
    }

    private fun stopOnError() = failStream()

    private var lastPlaybackError: PlaybackException? = null

    /** The top toast for a stream that couldn't be played, with a plain reason. */
    private fun announceStreamFailure() {
        val e = lastPlaybackError
        // no decoder for it here, and nowhere else had it: that's the whole reason
        val notice = player.currentMediaItem?.mediaId?.let { decoderNotices.remove(it) }
        if (notice != null && e != null && isDecoderError(e)) {
            com.mochyy.mochymusic.ui.component.TopToaster.error(notice.text)
            return
        }
        val reason = when {
            // a file on the phone failing has nothing to do with the connection
            (!isNetworkConnected.value && player.currentMediaItem?.let(::playsOffline) != true) ||
                (e != null && isNetworkRelatedError(e)) -> "no internet connection"
            e != null && getHttpResponseCode(e) != null -> "server error ${getHttpResponseCode(e)}"
            e != null -> plainReason(e)
            else -> "unknown error"
        }
        com.mochyy.mochymusic.ui.component.TopToaster.error("Stream failed: $reason")
    }

    /** A readable reason from the root cause, since IO_UNSPECIFIED alone says nothing. */
    private fun plainReason(e: PlaybackException): String {
        val causes = generateSequence<Throwable>(e) { it.cause }.toList()
        val noProvider = causes.filterIsInstance<NoProviderException>().firstOrNull()
        return when {
            noProvider != null -> noProvider.message.orEmpty()
            causes.any { it is java.net.SocketTimeoutException } -> "connection timed out"
            causes.any { it is java.net.SocketException || it is java.io.EOFException } -> "connection interrupted"
            causes.any { it is javax.net.ssl.SSLException } -> "secure connection failed"
            causes.any { it is java.io.FileNotFoundException } -> "stream not found"
            causes.any { it is androidx.media3.datasource.cache.Cache.CacheException } -> "cache error"
            e.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED -> "stream interrupted"
            isContainerParseError(e) -> "the audio file came back broken"
            else -> e.errorCodeName.removePrefix("ERROR_CODE_").lowercase().replace('_', ' ')
        }
    }

    private fun updateNotification() {
        mediaSession.setCustomLayout(
            listOf(
                CommandButton
                    .Builder()
                    .setDisplayName(
                        getString(
                            if (currentSong.value?.song?.liked ==
                                true
                            ) {
                                R.string.action_remove_like
                            } else {
                                R.string.action_like
                            },
                        ),
                    )
                    .setIconResId(if (currentSong.value?.song?.liked == true) R.drawable.ic_heart else R.drawable.ic_heart_outline)
                    .setSessionCommand(CommandToggleLike)
                    .setEnabled(currentSong.value != null)
                    .build(),
                CommandButton
                    .Builder()
                    .setDisplayName(
                        getString(
                            when (player.repeatMode) {
                                REPEAT_MODE_OFF -> R.string.repeat_mode_off
                                REPEAT_MODE_ONE -> R.string.repeat_mode_one
                                REPEAT_MODE_ALL -> R.string.repeat_mode_all
                                else -> throw IllegalStateException()
                            },
                        ),
                    ).setIconResId(
                        when (player.repeatMode) {
                            // The player artwork is 95 x 77 dp; notifications need a 24 dp icon.
                            REPEAT_MODE_OFF -> R.drawable.notification_repeat
                            REPEAT_MODE_ONE -> R.drawable.repeat_one_on
                            REPEAT_MODE_ALL -> R.drawable.repeat_on
                            else -> throw IllegalStateException()
                        },
                    ).setSessionCommand(CommandToggleRepeatMode)
                    .build(),
                CommandButton
                    .Builder()
                    .setDisplayName(getString(if (player.shuffleModeEnabled) R.string.action_shuffle_off else R.string.action_shuffle_on))
                    .setIconResId(if (player.shuffleModeEnabled) R.drawable.shuffle_on else R.drawable.shuffle)
                    .setSessionCommand(CommandToggleShuffle)
                    .build(),
                CommandButton.Builder()
                    .setDisplayName(getString(R.string.start_radio))
                    .setIconResId(R.drawable.radio)
                    .setSessionCommand(CommandToggleStartRadio)
                    .setEnabled(currentSong.value != null)
                    .build(),
            ),
        )
    }

    private suspend fun recoverSong(
        mediaId: String,
        playbackData: YTPlayerUtils.PlaybackData? = null
    ) {
        val song = database.song(mediaId).first()
        val mediaMetadata = withContext(Dispatchers.Main) {
            player.findNextMediaItemById(mediaId)?.metadata
        } ?: return
        val duration = song?.song?.duration?.takeIf { it != -1 }
            ?: mediaMetadata.duration.takeIf { it != -1 }
            ?: (playbackData?.videoDetails ?: YTPlayerUtils.playerResponseForMetadata(mediaId)
                .getOrNull()?.videoDetails)?.lengthSeconds?.toInt()
            ?: -1
        database.query {
            if (song == null) insert(mediaMetadata.copy(duration = duration))
            else {
                var updatedSong = song.song
                if (song.song.duration == -1) {
                    updatedSong = updatedSong.copy(duration = duration)
                }

                if (song.song.isVideo != mediaMetadata.isVideoSong) {
                    updatedSong = updatedSong.copy(isVideo = mediaMetadata.isVideoSong)
                }
                if (updatedSong != song.song) {
                    update(updatedSong)
                }
            }
        }
        if (!database.hasRelatedSongs(mediaId)) {
            val relatedEndpoint =
                YouTube.next(WatchEndpoint(videoId = mediaId)).getOrNull()?.relatedEndpoint
                    ?: return
            val relatedPage = YouTube.related(relatedEndpoint).getOrNull() ?: return
            database.query {
                relatedPage.songs
                    .map(SongItem::toMediaMetadata)
                    .onEach(::insert)
                    .map {
                        RelatedSongMap(
                            songId = mediaId,
                            relatedSongId = it.id
                        )
                    }
                    .forEach(::insert)
            }
        }
    }

    fun playQueue(
        queue: Queue,
        playWhenReady: Boolean = true,
    ) {
        if (destroying) return

        if (!playerInitialized.value) {
            Timber.tag(TAG).w("playQueue called before player initialization, queuing request")
            scope.launch {
                playerInitialized.first { it }
                playQueue(queue, playWhenReady)
            }
            return
        }

        // a song picked while another plays crosses over with blend skips on; otherwise the old one dips while the new one is read and fetched, then makes way
        if (playWhenReady) {
            var status: Queue.Status? = null
            transport.startQueue(
                song = queue.firstSongId,
                ready = { status = readyQueue(queue) },
                blend = { blendIntoQueue(queue) },
            ) { startQueue(queue, playWhenReady = true, read = status) }
        } else {
            startQueue(queue, playWhenReady = false)
        }
    }

    // gets a picked queue going while the old song still plays: a queue that only knows its first song once it's read is read now, and that song's start is fetched
    private suspend fun readyQueue(queue: Queue): Queue.Status? {
        val status = if (queue.firstSongId == null) {
            try {
                readQueue(queue)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Timber.tag(TAG).d(e, "Couldn't read the picked queue ahead, it's read again when it starts")
                null
            }
        } else {
            null
        }
        val first = queue.firstSongId ?: status?.items?.getOrNull(status.mediaItemIndex)?.mediaId
        if (first != null) warmPick(first)
        return status
    }

    // a queue's songs, with the ones the listener hides already taken out
    private suspend fun readQueue(queue: Queue): Queue.Status =
        withContext(Dispatchers.IO) {
            queue.getInitialStatus()
                .filterExplicit(dataStore.get(HideExplicitKey, false))
                .filterVideoSongs(dataStore.get(HideVideoSongsKey, false))
        }

    // [blend] means the old song is still playing: a queue with a first song has it crossing over already, one without crosses once it's read; [read] is the queue already read while the old song played
    // [manual] is the user's own queue carried over to the new one; left out, it's read from the player as it is now
    private fun startQueue(
        queue: Queue,
        playWhenReady: Boolean,
        blend: Boolean = false,
        read: Queue.Status? = null,
        manual: List<MediaItem> = upcomingManualItems(),
    ) {
        currentQueue = queue
        queueTitle = null
        resetQueueRunway()
        val generation = queueGeneration
        initialQueueLoading = true
        // on by default, like spotify: a new playlist keeps shuffling until shuffle is turned off
        val persistShuffleAcrossQueues = dataStore.get(PersistentShuffleAcrossQueuesKey, true)
        if (!persistShuffleAcrossQueues) {
            player.shuffleModeEnabled = false
        }

        originalQueueSize = 0
        if (queue.preloadItem != null && !blend) {
            // the songs the user queued stay: they follow the song picked, and the rest of its queue lands behind them
            player.setMediaItems(listOf(queue.preloadItem!!.toMediaItem()) + manual)
            player.prepare()
            player.playWhenReady = playWhenReady
        }
        scope.launch(SilentHandler) {
            try {
                loadInitialQueue(queue, generation, playWhenReady, blend, read, manual)
            } finally {
                if (generation == queueGeneration) {
                    initialQueueLoading = false
                    // Even if the initial load failed or came back short, make sure there's something next.
                    ensureQueueRunway()
                }
            }
        }
    }

    private suspend fun loadInitialQueue(
        queue: Queue,
        generation: Int,
        playWhenReady: Boolean,
        blend: Boolean = false,
        read: Queue.Status? = null,
        manual: List<MediaItem> = emptyList(),
    ) {
        // read once only: a youtube queue moves on to its next page if it's asked twice
        val initialStatus = read ?: readQueue(queue)
        if (generation != queueGeneration) return

        val preloadId = queue.preloadItem?.id
        // Only drop the result if the user has moved on from the preloaded song. Don't bail just because
        // the player is idle: the first stream for a fresh install often errors once and retries, and
        // bailing here used to leave the queue with only that one song.
        if (preloadId != null && player.currentMediaItem?.mediaId != preloadId) return

        if (initialStatus.title != null) {
            queueTitle = initialStatus.title
        }
        if (initialStatus.items.isEmpty()) return

        originalQueueSize = initialStatus.items.size + manual.size
        if (preloadId != null) {
            val items = initialStatus.items
            val preloadIndex = items.indexOfFirst { it.mediaId == preloadId }
            if (preloadIndex >= 0) {
                player.addMediaItems(0, items.subList(0, preloadIndex))
                player.addMediaItems(items.subList(preloadIndex + 1, items.size))
            } else {
                // The result doesn't contain the playing song (e.g. it fell back to a radio mix), so
                // queue all of it after the current song instead of dropping a track.
                player.addMediaItems(items)
            }
        } else {
            val startIndex = initialStatus.mediaItemIndex.coerceIn(initialStatus.items.indices)
            // the songs the user queued play right after the one the queue starts on, ahead of the rest of it
            val items = if (manual.isEmpty()) {
                initialStatus.items
            } else {
                initialStatus.items.toMutableList().apply {
                    addAll((startIndex + 1).coerceAtMost(size), manual)
                }
            }
            // the old song played on while the queue was read; if nothing has stopped it since, the two cross over now
            if (blend && canBlendSkip()) {
                val shuffle = player.shuffleModeEnabled
                crossfadeInto(blendLengthMs(), skipCurve = true) { next ->
                    next.setMediaItems(items, startIndex, initialStatus.position)
                }
                player.shuffleModeEnabled = shuffle
            } else {
                player.setMediaItems(items, startIndex, initialStatus.position)
                player.prepare()
                player.playWhenReady = playWhenReady
            }
        }

        if (player.shuffleModeEnabled) {
            val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
            applyShuffleOrder(player.currentMediaItemIndex, player.mediaItemCount, shufflePlaylistFirst)
        }
    }

    private fun resetQueueRunway() {
        queueGeneration++
        runwayJob?.cancel()
        runwayJob = null
        resetInfiniteSource()
    }

    /** Forgets the infinite queue's radio and seeds, so the next runway seeds afresh from the queue's tail. */
    private fun resetInfiniteSource() {
        runwayRetryJob?.cancel()
        runwayRetryJob = null
        runwayRetries = 0
        infiniteSource = null
        usedInfiniteSeeds.clear()
        failedInfiniteSeeds.clear()
        autoplayPreviewRetryAt = 0L
    }

    private fun isInfiniteQueueEnabled(): Boolean {
        // its songs come from YouTube radios
        if (com.mochyy.mochymusic.utils.OfflineMode.isOn) return false
        val stored = dataStore.get(InfiniteQueueKey, true)
        val pending = pendingInfiniteQueue ?: return stored
        if (pending == stored && infiniteQueueWrite?.isActive != true) pendingInfiniteQueue = null
        return pending
    }

    /**
     * Tries the runway again later after it came back with nothing while the queue is running dry,
     * e.g. the first request on a fresh install failed. Each retry waits twice as long as the last.
     */
    private fun scheduleRunwayRetry(generation: Int) {
        if (runwayRetries >= MAX_RUNWAY_RETRIES || com.mochyy.mochymusic.utils.OfflineMode.isOn) return
        val canGrow = currentQueue.hasOwnNextPage() ||
            (isInfiniteQueueEnabled() && player.repeatMode == REPEAT_MODE_OFF)
        if (!canGrow) return
        val delayMs = RUNWAY_RETRY_BASE_MS shl runwayRetries
        runwayRetries++
        runwayRetryJob?.cancel()
        runwayRetryJob = scope.launch(SilentHandler) {
            delay(delayMs)
            if (generation != queueGeneration) return@launch
            usedInfiniteSeeds -= failedInfiniteSeeds
            failedInfiniteSeeds.clear()
            ensureQueueRunway()
        }
    }

    /**
     * The songs the user queued by hand that are still to come, in the order they will play
     * (shuffle included). These are carried over when another song is started, so playing
     * something else never drops them.
     */
    private fun upcomingManualItems(): List<MediaItem> {
        val timeline = player.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val shuffle = player.shuffleModeEnabled
        val found = ArrayList<MediaItem>()
        var index = player.currentMediaItemIndex
        var steps = 0
        while (steps++ < timeline.windowCount) {
            index = timeline.getNextWindowIndex(index, REPEAT_MODE_OFF, shuffle)
            if (index == C.INDEX_UNSET) break
            val item = player.getMediaItemAt(index)
            if (item.isManualQueued && !item.isAutoplay) found += item
        }
        return found
    }

    /**
     * The index of the last song in the run of user-queued songs right after the current one, or
     * the current song's own index if there are none. A song queued next goes in straight behind
     * it: after what the user queued before, ahead of the queue's own songs and of Autoplay.
     */
    private fun manualQueueAnchor(): Int {
        val timeline = player.currentTimeline
        var anchor = player.currentMediaItemIndex
        if (timeline.isEmpty) return anchor
        val shuffle = player.shuffleModeEnabled
        var index = anchor
        var steps = 0
        while (steps++ < timeline.windowCount) {
            index = timeline.getNextWindowIndex(index, REPEAT_MODE_OFF, shuffle)
            if (index == C.INDEX_UNSET) break
            val item = player.getMediaItemAt(index)
            if (!item.isManualQueued || item.isAutoplay) break
            anchor = index
        }
        return anchor
    }

    /**
     * Where the upcoming Autoplay songs start, or the end of the queue if there are none. Autoplay
     * songs are only ever appended, so they form the tail; anything the user queues goes in front.
     */
    private fun upcomingAutoplayStart(): Int {
        val count = player.mediaItemCount
        for (i in player.currentMediaItemIndex + 1 until count) {
            if (player.getMediaItemAt(i).isAutoplay) return i
        }
        return count
    }

    /**
     * Whether to line up Autoplay songs now, before the queue runs low, so the queue page can show
     * what plays after it. Only once the queue itself is finite: while it still has pages to load,
     * those come first and are what keeps it going.
     */
    private fun wantsAutoplayPreview(): Boolean {
        if (!isInfiniteQueueEnabled() || player.repeatMode != REPEAT_MODE_OFF) return false
        if (android.os.SystemClock.elapsedRealtime() < autoplayPreviewRetryAt) return false
        if (currentQueue.hasOwnNextPage()) return false
        return upcomingAutoplayStart() == player.mediaItemCount
    }

    private fun Queue.hasOwnNextPage(): Boolean =
        !continuesAsRadio && hasNextPage() && dataStore.get(AutoLoadMoreKey, true)

    /** Drops the Autoplay songs still to come, e.g. when infinite queue is switched off. */
    private fun removeUpcomingAutoplay() {
        val current = player.currentMediaItemIndex
        var end = player.mediaItemCount - 1
        // Back to front in runs, one timeline change per run rather than per song.
        while (end > current) {
            if (!player.getMediaItemAt(end).isAutoplay) {
                end--
                continue
            }
            var start = end
            while (start - 1 > current && player.getMediaItemAt(start - 1).isAutoplay) start--
            player.removeMediaItems(start, end + 1)
            end = start - 1
        }
    }

    /** Drops everything still to come except the songs the user queued by hand. */
    private fun removeUpcomingExceptManual() {
        val current = player.currentMediaItemIndex
        var end = player.mediaItemCount - 1
        // Back to front in runs, one timeline change per run rather than per song.
        while (end > current) {
            if (player.getMediaItemAt(end).isManualQueued) {
                end--
                continue
            }
            var start = end
            while (start - 1 > current && !player.getMediaItemAt(start - 1).isManualQueued) start--
            player.removeMediaItems(start, end + 1)
            end = start - 1
        }
    }

    /** How many items the player will play after the current one (respecting shuffle), capped at [limit]. */
    private fun upcomingItemCount(limit: Int): Int {
        val timeline = player.currentTimeline
        if (timeline.isEmpty) return 0
        var index = player.currentMediaItemIndex
        var count = 0
        while (count < limit) {
            index = timeline.getNextWindowIndex(index, REPEAT_MODE_OFF, player.shuffleModeEnabled)
            if (index == C.INDEX_UNSET) break
            count++
        }
        return count
    }

    /**
     * Keeps a few songs queued ahead of the current one: first from the queue's own next pages, then, when
     * the queue has run dry and infinite queue is on, from a radio seeded by the songs at the end of the queue.
     * If playback already ended because nothing was left, it resumes on the newly added songs.
     */
    private fun ensureQueueRunway() {
        if (!playerInitialized.value) return
        if (initialQueueLoading || runwayJob?.isActive == true) return
        if (player.mediaItemCount == 0 || !connectivityObserver.isCurrentlyConnected()) return
        if (dataStore.get(DisableLoadMoreWhenRepeatAllKey, false) && player.repeatMode == REPEAT_MODE_ALL) return
        if (!currentQueue.hasOwnNextPage() && (!isInfiniteQueueEnabled() || player.repeatMode != REPEAT_MODE_OFF)) return
        val lowOnSongs = upcomingItemCount(QUEUE_RUNWAY_SIZE + 1) <= QUEUE_RUNWAY_SIZE
        val previewOnly = !lowOnSongs && wantsAutoplayPreview()
        if (!lowOnSongs && !previewOnly) return

        val generation = queueGeneration
        runwayJob = scope.launch(SilentHandler) {
            repeat(MAX_RUNWAY_ATTEMPTS) {
                val autoplayRequest = autoplayGeneration
                val (candidates, fromInfinite) = loadMoreQueueItems() ?: run {
                    if (generation == queueGeneration && autoplayRequest != autoplayGeneration) {
                        runwayJob = null
                        ensureQueueRunway()
                        return@launch
                    }
                    if (previewOnly) {
                        autoplayPreviewRetryAt = android.os.SystemClock.elapsedRealtime() + AUTOPLAY_PREVIEW_RETRY_MS
                    } else if (generation == queueGeneration) {
                        scheduleRunwayRetry(generation)
                    }
                    return@launch
                }
                if (generation != queueGeneration || player.mediaItemCount == 0) return@launch
                if (fromInfinite && (autoplayRequest != autoplayGeneration ||
                        !isInfiniteQueueEnabled() || player.repeatMode != REPEAT_MODE_OFF)
                ) {
                    runwayJob = null
                    ensureQueueRunway()
                    return@launch
                }

                val newItems = if (fromInfinite) {
                    // Radio mixes repeat songs that are already queued (including their own seed).
                    val queued = HashSet<String>()
                    for (i in 0 until player.mediaItemCount) queued += player.getMediaItemAt(i).mediaId
                    candidates.filter { queued.add(it.mediaId) }.map { it.withAutoplay(true) }
                } else {
                    candidates
                }
                if (newItems.isEmpty()) return@repeat

                val endedWithNothingNext = player.playbackState == Player.STATE_ENDED || waitingAtModuleEnd(player)
                // Autoplay goes on the end; the queue's own pages go in front of it, so the songs
                // the user picked still play before the similar ones.
                val insertAt = if (fromInfinite) player.mediaItemCount else upcomingAutoplayStart()
                player.addMediaItems(insertAt, newItems)
                runwayRetryJob?.cancel()
                runwayRetryJob = null
                runwayRetries = 0
                if (player.shuffleModeEnabled) {
                    // A new page of the queue is shuffled in itself; Autoplay keeps the radio's order.
                    placeAddedInShuffleOrder(insertAt until insertAt + newItems.size, shuffleThem = !fromInfinite)
                }
                if (endedWithNothingNext) advanceQueueAtEnd(player)
                // That may have been the queue's last page, which is when Autoplay lines up.
                if (!fromInfinite) {
                    runwayJob = null
                    ensureQueueRunway()
                }
                return@launch
            }
            if (previewOnly) {
                autoplayPreviewRetryAt = android.os.SystemClock.elapsedRealtime() + AUTOPLAY_PREVIEW_RETRY_MS
            } else if (generation == queueGeneration) {
                scheduleRunwayRetry(generation)
            }
        }
    }

    /** Returns the next batch of songs and whether they came from the infinite queue, or null if there's nothing to add. */
    private suspend fun loadMoreQueueItems(): Pair<List<MediaItem>, Boolean>? {
        // a queue's next page and the infinite queue are both online
        if (com.mochyy.mochymusic.utils.OfflineMode.isOn) return null
        val hideExplicit = dataStore.get(HideExplicitKey, false)
        val hideVideos = dataStore.get(HideVideoSongsKey, false)

        val queue = currentQueue
        if (queue.hasOwnNextPage()) {
            // Try a few pages when entire pages are hidden by filters, keeping their
            // continuation ahead of generated Autoplay entries.
            repeat(MAX_RUNWAY_ATTEMPTS) {
                if (!queue.hasNextPage()) return@repeat
                val page = try {
                    withContext(Dispatchers.IO) { queue.nextPage() }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Timber.tag(TAG).w(e, "Failed to load next queue page")
                    if (queue.hasNextPage()) return null
                    emptyList()
                }.filterExplicit(hideExplicit).filterVideoSongs(hideVideos)
                if (page.isNotEmpty()) return page to false
            }
            if (queue.hasNextPage()) return null
        }

        if (!isInfiniteQueueEnabled() || player.repeatMode != REPEAT_MODE_OFF) return null

        val infiniteItems = loadInfiniteQueueItems()
            .filterExplicit(hideExplicit)
            .filterVideoSongs(hideVideos)
        return infiniteItems.takeIf { it.isNotEmpty() }?.let { it to true }
    }

    private suspend fun loadInfiniteQueueItems(): List<MediaItem> {
        val request = autoplayGeneration
        // Only songs that aren't queued yet count: a radio that repeats the queue (or just its own
        // seed, which is all a signed-out radio sometimes returns) has to fall through to the next source.
        val queued = HashSet<String>()
        for (i in 0 until player.mediaItemCount) queued += player.getMediaItemAt(i).mediaId
        // the songs you said not to recommend again never get lined up
        val hidden = NotRecommended.songs
        fun List<MediaItem>.fresh() = filter { it.mediaId !in queued && it.mediaId !in hidden }

        val continuation = infiniteSource ?: currentQueue.takeIf { it.continuesAsRadio }
        if (continuation?.hasNextPage() == true) {
            val page = try {
                withContext(Dispatchers.IO) { continuation.nextPage() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "Failed to load next infinite queue page")
                emptyList()
            }.fresh()
            if (request != autoplayGeneration) return emptyList()
            if (page.isNotEmpty()) return page
        }

        // Seed a fresh radio from the most recent online song we haven't seeded from yet, so the
        // queue keeps drifting forward instead of looping on the same mix.
        val seedItem = (player.mediaItemCount - 1 downTo 0)
            .asSequence()
            .map { player.getMediaItemAt(it) }
            .firstOrNull { !it.mediaId.startsWith("LOCAL_") && it.mediaId !in usedInfiniteSeeds && it.mediaId !in hidden }
            ?: return emptyList()
        val seed = seedItem.mediaId
        usedInfiniteSeeds += seed

        val radio = YouTubeQueue(WatchEndpoint(videoId = seed, playlistId = "RDAMVM$seed"))
        val radioItems = runCatching { withContext(Dispatchers.IO) { radio.getInitialStatus().items } }
            .onFailure { Timber.tag(TAG).w(it, "Failed to start infinite queue radio for $seed") }
            .getOrDefault(emptyList())
            .fresh()
        currentCoroutineContext().ensureActive()
        if (request != autoplayGeneration) return emptyList()
        infiniteSource = radio
        if (radioItems.isNotEmpty()) return radioItems

        val relatedItems = runCatching {
            withContext(Dispatchers.IO) {
                val relatedEndpoint = YouTube.next(WatchEndpoint(videoId = seed)).getOrNull()?.relatedEndpoint
                    ?: return@withContext emptyList()
                YouTube.related(relatedEndpoint).getOrNull()?.songs.orEmpty().map { it.toMediaItem() }
            }
        }.getOrDefault(emptyList()).fresh()
        currentCoroutineContext().ensureActive()
        if (request != autoplayGeneration) return emptyList()
        if (relatedItems.isNotEmpty()) return relatedItems

        // Last resort, for when YouTube gives a signed-out session neither a radio nor related
        // songs: the seed's artist's own songs.
        val artistItems = runCatching {
            withContext(Dispatchers.IO) {
                val artistId = seedItem.metadata?.artists?.firstNotNullOfOrNull { it.id }
                    ?: return@withContext emptyList()
                YouTube.artist(artistId).getOrNull()?.sections.orEmpty()
                    .flatMap { it.items }
                    .filterIsInstance<SongItem>()
                    .map { it.toMediaItem() }
            }
        }.getOrDefault(emptyList()).fresh().distinctBy { it.mediaId }
        currentCoroutineContext().ensureActive()
        if (request != autoplayGeneration) return emptyList()
        if (artistItems.isNotEmpty()) return artistItems

        // Nothing came back for this seed: keep it out of this round, but let a retry use it again
        // (for a song played from search it's the only seed there is).
        failedInfiniteSeeds += seed
        return emptyList()
    }

    fun setInfiniteQueueEnabled(enabled: Boolean) {
        pendingInfiniteQueue = enabled
        autoplayGeneration++
        infiniteQueueWrite = scope.launch {
            dataStore.edit { settings ->
                settings[InfiniteQueueKey] = enabled
            }
        }
        if (enabled) {
            // Start over from the queue's tail: switching it off dropped the songs the old radio
            // lined up, and its seeds were already spent, so it would otherwise find nothing new.
            resetInfiniteSource()
        } else {
            removeUpcomingAutoplay()
        }
        ensureQueueRunway()
    }

    // "start radio", like spotify's song radio or apple music's station: the song keeps playing where it is, and everything after it becomes an endless run of songs like it
    fun startRadioSeamlessly() {

        if (!playerInitialized.value) {
            Timber.tag(TAG).w("startRadioSeamlessly called before player initialization")
            return
        }

        val currentMediaMetadata = player.currentMetadata ?: return
        val currentMediaId = currentMediaMetadata.id

        resetQueueRunway()
        val generation = queueGeneration
        initialQueueLoading = true

        scope.launch(SilentHandler) {
            try {
                loadSeamlessRadio(currentMediaId, currentMediaMetadata.title, generation)
            } finally {
                if (generation == queueGeneration) {
                    initialQueueLoading = false
                    ensureQueueRunway()
                }
            }
        }
    }

    private suspend fun loadSeamlessRadio(
        currentMediaId: String,
        title: String,
        generation: Int,
    ) {
        // the song's own station, the same one youtube music's "start radio" plays, not whatever "up next" happened to be
        val radioQueue = YouTubeQueue(WatchEndpoint(videoId = currentMediaId, playlistId = "RDAMVM$currentMediaId"))
        val hideExplicit = dataStore.get(HideExplicitKey, false)
        val hideVideoSongs = dataStore.get(HideVideoSongsKey, false)
        var moreFrom: Queue = radioQueue
        val loaded = try {
            withContext(Dispatchers.IO) {
                radioQueue.getInitialStatus()
                    .filterExplicit(hideExplicit)
                    .filterVideoSongs(hideVideoSongs)
                    .items
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "The radio for $currentMediaId didn't load, trying its related songs")
            // the station's pages don't follow related songs, so infinite queue carries these on instead
            moreFrom = EmptyQueue
            relatedSongs(currentMediaId, hideExplicit, hideVideoSongs)
        }
        val radioItems = loaded.filter { it.mediaId != currentMediaId && it.mediaId !in NotRecommended }
        if (generation != queueGeneration) return
        // the song moved on while the station loaded, so this isn't its radio any more
        if (player.currentMediaItem?.mediaId != currentMediaId) return
        if (radioItems.isEmpty()) {
            showBanner(getString(R.string.radio_failed))
            return
        }

        // what came with the queue after the song makes way for the station; what already played stays as
        // history, and the songs the user queued by hand stay where they are, ahead of the station
        removeUpcomingExceptManual()
        player.addMediaItems(player.mediaItemCount, radioItems)
        if (player.shuffleModeEnabled) {
            val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
            applyShuffleOrder(player.currentMediaItemIndex, player.mediaItemCount, shufflePlaylistFirst)
        }
        currentQueue = moreFrom
        queueTitle = getString(R.string.radio_queue_title, title)
        showBanner(getString(R.string.radio_started, title))
        if (dataStore.get(PersistentQueueKey, true)) saveQueueToDisk()
    }

    // the songs youtube lists as related to [songId], for when its station won't load
    private suspend fun relatedSongs(songId: String, hideExplicit: Boolean, hideVideoSongs: Boolean): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val related = YouTube.next(WatchEndpoint(videoId = songId)).getOrNull()?.relatedEndpoint
                ?: return@withContext emptyList()
            YouTube.related(related).getOrNull()?.songs.orEmpty()
                .map { it.toMediaItem() }
                .filterExplicit(hideExplicit)
                .filterVideoSongs(hideVideoSongs)
        }

    fun getAutomixAlbum(albumId: String) {
        scope.launch(SilentHandler) {
            YouTube
                .album(albumId)
                .onSuccess {
                    getAutomix(it.album.playlistId)
                }
        }
    }

    fun getAutomix(playlistId: String) {
        if (dataStore.get(SimilarContent, true) &&
            !(dataStore.get(DisableLoadMoreWhenRepeatAllKey, false) && player.repeatMode == REPEAT_MODE_ALL)) {
            scope.launch(SilentHandler) {
                try {

                    YouTube.next(WatchEndpoint(playlistId = playlistId))
                        .onSuccess { firstResult ->
                            YouTube.next(WatchEndpoint(playlistId = firstResult.endpoint.playlistId))
                                .onSuccess { secondResult ->
                                    automixItems.value = secondResult.items.map { song ->
                                        song.toMediaItem()
                                    }
                                }
                                .onFailure {

                                    if (firstResult.items.isNotEmpty()) {
                                        automixItems.value = firstResult.items.map { song ->
                                            song.toMediaItem()
                                        }
                                    }
                                }
                        }
                        .onFailure {

                            val currentSong = player.currentMetadata
                            if (currentSong != null) {

                                YouTube.next(WatchEndpoint(
                                    videoId = currentSong.id
                                )).onSuccess { radioResult ->
                                    val filteredItems = radioResult.items
                                        .filter { it.id != currentSong.id }
                                        .map { it.toMediaItem() }
                                    if (filteredItems.isNotEmpty()) {
                                        automixItems.value = filteredItems
                                    }
                                }.onFailure {

                                    YouTube.next(WatchEndpoint(videoId = currentSong.id)).getOrNull()?.relatedEndpoint?.let { relatedEndpoint ->
                                        YouTube.related(relatedEndpoint).onSuccess { relatedPage ->
                                            val relatedItems = relatedPage.songs
                                                .filter { it.id != currentSong.id }
                                                .map { it.toMediaItem() }
                                            if (relatedItems.isNotEmpty()) {
                                                automixItems.value = relatedItems

                                            }
                                        }
                                    }
                                }
                            }
                        }
                } catch (_: Exception) {

                }
            }
        }
    }

    fun addToQueueAutomix(
        item: MediaItem,
        position: Int,
    ) {
        automixItems.value =
            automixItems.value.toMutableList().apply {
                removeAt(position)
            }
        addToQueue(listOf(item))
    }

    fun playNextAutomix(
        item: MediaItem,
        position: Int,
    ) {
        automixItems.value =
            automixItems.value.toMutableList().apply {
                removeAt(position)
            }
        playNext(listOf(item))
    }

    fun clearAutomix() {
        automixItems.value = emptyList()
    }

    /**
     * "Play next": straight after the song playing, ahead of everything else, including what was
     * queued by hand before. Like everything queued by hand it's a new entry each time: a song
     * that's already in the queue is never skipped, replaced or moved.
     */
    fun playNext(items: List<MediaItem>) {
        if (items.isEmpty()) return
        val queued = items.asManualQueue()
        // a stopped player starts fresh with these, like before
        if (player.mediaItemCount == 0 || player.playbackState == STATE_IDLE) {
            player.setMediaItems(queued)
            player.prepare()

            if (castConnectionHandler?.isCasting?.value != true) {
                player.play()
            }
            return
        }
        insertManualQueued(queued, afterIndex = player.currentMediaItemIndex)
    }

    /**
     * "Add to Queue": joins the end of the songs the user queued by hand, so the first one added
     * plays next and each later one lines up behind it (first in, first out). They all play ahead
     * of the queue's own songs and of Autoplay, and a song can be queued as many times as wanted:
     * every call is a new entry. Nothing here removes or replaces a song that's already queued.
     */
    fun addToQueue(items: List<MediaItem>) {
        if (items.isEmpty()) return
        val queued = items.asManualQueue()
        if (player.mediaItemCount == 0) {
            player.addMediaItems(queued)
            player.prepare()
            return
        }
        insertManualQueued(queued, afterIndex = manualQueueAnchor())
    }

    private fun List<MediaItem>.asManualQueue() = map { it.withAutoplay(false).withManualQueued(true) }

    private fun insertManualQueued(queued: List<MediaItem>, afterIndex: Int) {
        val insertAt = (afterIndex + 1).coerceIn(0, player.mediaItemCount)
        player.addMediaItems(insertAt, queued)
        if (player.shuffleModeEnabled) {
            placeManualInShuffleOrder(insertAt until insertAt + queued.size, afterIndex)
        }
        player.prepare()
    }

    /**
     * Shuffled, the play order is the shuffle order, not the item order: put songs just queued by
     * hand straight after [afterIndex] in it, leaving History and everything else as it was.
     */
    private fun placeManualInShuffleOrder(added: IntRange, afterIndex: Int) {
        val timeline = player.currentTimeline
        if (timeline.isEmpty || added.isEmpty()) return
        val order = ArrayList<Int>(timeline.windowCount)
        var index = timeline.getFirstWindowIndex(true)
        while (index != C.INDEX_UNSET && order.size < timeline.windowCount) {
            if (index !in added) order += index
            index = timeline.getNextWindowIndex(index, REPEAT_MODE_OFF, true)
        }
        // the songs added come after [afterIndex], so its index is the same as before they went in
        order.addAll(order.indexOf(afterIndex) + 1, added.toList())
        if (order.size != timeline.windowCount) return
        player.setShuffleOrder(DefaultShuffleOrder(order.toIntArray(), System.currentTimeMillis()))
    }

    /**
     * Fits songs just added while shuffled into the shuffle order without reshuffling the rest.
     * Reshuffling everything on each addition (as before) rearranged the whole upcoming queue
     * every time a page loaded or a song was queued, and threw History back into it. Now history
     * and what's lined up keep their order; the new songs go after the user's songs and before
     * Autoplay - or at the very end, if they are Autoplay.
     */
    private fun placeAddedInShuffleOrder(added: IntRange, shuffleThem: Boolean) {
        val timeline = player.currentTimeline
        if (timeline.isEmpty || added.isEmpty()) return
        val order = ArrayList<Int>(timeline.windowCount)
        var index = timeline.getFirstWindowIndex(true)
        while (index != C.INDEX_UNSET && order.size < timeline.windowCount) {
            if (index !in added) order += index
            index = timeline.getNextWindowIndex(index, REPEAT_MODE_OFF, true)
        }
        val block = added.toMutableList()
        if (shuffleThem) block.shuffle()
        val insertAt = if (player.getMediaItemAt(block.first()).isAutoplay) {
            order.size
        } else {
            val currentPos = order.indexOf(player.currentMediaItemIndex)
            (currentPos + 1 until order.size).firstOrNull { player.getMediaItemAt(order[it]).isAutoplay } ?: order.size
        }
        order.addAll(insertAt, block)
        if (order.size != timeline.windowCount) return
        player.setShuffleOrder(DefaultShuffleOrder(order.toIntArray(), System.currentTimeMillis()))
    }

    fun toggleLibrary() {
        scope.launch {
            val songToToggle = currentSong.first()
            songToToggle?.let {
                val isInLibrary = it.song.inLibrary != null
                val token = if (isInLibrary) it.song.libraryRemoveToken else it.song.libraryAddToken

                token?.let { feedbackToken ->
                    YouTube.feedback(listOf(feedbackToken))
                }

                database.query {
                    update(it.song.toggleLibrary())
                }
                currentMediaMetadata.value = player.currentMetadata
            }
        }
    }

    fun toggleLike() {
        scope.launch {
            val songToToggle = currentSong.first()
            songToToggle?.let {
                val song = it.song.toggleLike()
                database.query {
                    update(song)
                    syncUtils.likeSong(song)

                    if (dataStore.get(AutoDownloadOnLikeKey, false) && song.liked) {

                        val downloadRequest =
                            androidx.media3.exoplayer.offline.DownloadRequest
                                .Builder(song.id, song.id.toUri())
                                .setCustomCacheKey(song.id)
                                .setData(song.title.toByteArray())
                                .build()
                        androidx.media3.exoplayer.offline.DownloadService.sendAddDownload(
                            this@MusicService,
                            ExoDownloadService::class.java,
                            downloadRequest,
                            false
                        )
                    }
                }
                currentMediaMetadata.value = player.currentMetadata
            }
        }
    }

    // a heart that says which way it wants the song (vivo's music card) only flips it when it isn't that way yet
    fun setLiked(liked: Boolean) {
        scope.launch {
            if (currentSong.first()?.song?.let { it.liked != liked } == true) toggleLike()
        }
    }

    fun toggleStartRadio() {
        startRadioSeamlessly()
    }

    private fun setupLoudnessEnhancer() {
        val audioSessionId = player.audioSessionId

        if (audioSessionId == C.AUDIO_SESSION_ID_UNSET || audioSessionId <= 0) {
            Timber.tag(TAG).w("setupLoudnessEnhancer: invalid audioSessionId ($audioSessionId), cannot create effect yet")
            return
        }

        if (loudnessEnhancer != null && loudnessEnhancerSessionId != audioSessionId) {
            // the player changed (a crossfade): the old enhancer stays with the outgoing song,
            // at its own gain, until that player is let go
            fadingLoudnessEnhancer?.runCatching { release() }
            fadingLoudnessEnhancer = loudnessEnhancer
            loudnessEnhancer = null
        }
        if (loudnessEnhancer == null) {
            try {
                loudnessEnhancerSessionId = audioSessionId
                loudnessEnhancer = LoudnessEnhancer(audioSessionId)
                Timber.tag(TAG).d("LoudnessEnhancer created for sessionId=$audioSessionId")
            } catch (e: Exception) {
                reportException(e)
                loudnessEnhancer = null
                return
            }
        }

        scope.launch {
            try {
                val currentMediaId = withContext(Dispatchers.Main) {
                    player.currentMediaItem?.mediaId
                }

                val normalizeAudio = withContext(Dispatchers.IO) {
                    dataStore.data.map { it[AudioNormalizationKey] ?: true }.first()
                }

                // YouTube's loudness numbers describe YouTube's stream: a song from a module plays
                // another master, and evens out by its own ReplayGain in the sink instead
                val fromModule = currentMediaId != null &&
                    resolvedSourceIds[currentMediaId].let { it != null && it != com.mochyy.mochymusic.modules.SourceModules.YouTubeId }
                if (normalizeAudio && currentMediaId != null && !fromModule) {
                    val format = playingFrom.value[currentMediaId]?.manualYouTubeFormat ?: withContext(Dispatchers.IO) {
                        database.format(currentMediaId).first()
                    }

                    Timber.tag(TAG).d("Audio normalization enabled: $normalizeAudio")
                    Timber.tag(TAG).d("Format loudnessDb: ${format?.loudnessDb}, perceptualLoudnessDb: ${format?.perceptualLoudnessDb}")

                    val loudness = format?.loudnessDb ?: format?.perceptualLoudnessDb

                    withContext(Dispatchers.Main) {
                        if (loudness != null) {
                            val loudnessDb = loudness.toFloat()
                            val targetGain = (-loudnessDb * 100).toInt()
                            val clampedGain = targetGain.coerceIn(MIN_GAIN_MB, MAX_GAIN_MB)

                            Timber.tag(TAG).d("Calculated raw normalization gain: $targetGain mB (from loudness: $loudnessDb)")

                            try {
                                loudnessEnhancer?.setTargetGain(clampedGain)
                                loudnessEnhancer?.enabled = true
                                Timber.tag(TAG).i("LoudnessEnhancer gain applied: $clampedGain mB")
                            } catch (e: Exception) {
                                Timber.tag(TAG).e(e, "Failed to apply loudness enhancement")
                                reportException(e)
                                releaseLoudnessEnhancer()
                            }
                        } else {
                            loudnessEnhancer?.enabled = false
                            Timber.tag(TAG).w("Normalization enabled but no loudness data available - no normalization applied")
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        loudnessEnhancer?.enabled = false
                        Timber.tag(TAG).d("setupLoudnessEnhancer: normalization disabled or mediaId unavailable")
                    }
                }
            } catch (e: Exception) {
                reportException(e)
                releaseLoudnessEnhancer()
            }
        }
    }

    private fun releaseLoudnessEnhancer() {
        try {
            loudnessEnhancer?.release()
            Timber.tag(TAG).d("LoudnessEnhancer released")
        } catch (e: Exception) {
            reportException(e)
            Timber.tag(TAG).e(e, "Error releasing LoudnessEnhancer: ${e.message}")
        } finally {
            loudnessEnhancer = null
        }
    }

    private fun openAudioEffectSession() {
        if (isAudioEffectSessionOpened) return
        isAudioEffectSessionOpened = true
        setupLoudnessEnhancer()
        sendBroadcast(
            Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, player.audioSessionId)
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            },
        )
    }

    private fun closeAudioEffectSession() {
        if (!isAudioEffectSessionOpened) return
        isAudioEffectSessionOpened = false
        releaseLoudnessEnhancer()
        sendBroadcast(
            Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, player.audioSessionId)
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
            },
        )
    }

    private var previousMediaItemIndex = C.INDEX_UNSET

    override fun onMediaItemTransition(
        mediaItem: MediaItem?,
        reason: Int,
    ) {
        // The same ID can occupy two queue entries or loop back to the start.
        bufferingRecoveryJob?.cancel()
        bufferingRecoveryJob = null
        moduleEndRecoveryJob?.cancel()
        moduleEndRecoveryJob = null
        moduleEndWaiting = null
        audioOutputRecoveryAttempts = 0
        outputMonitorJob?.cancel()
        outputMonitorJob = null
        providerOccurrence++
        providerSwitch.onMediaChanged()
        // A recovery belongs to the old item; it must not prepare or skip a newly selected song.
        retryJob?.cancel()
        retryJob = null
        retryCount = 0
        providerLookupRetries = 0
        waitingForNetworkConnection.value = false
        clearStreamFailure()
        if (!promotingCrossmix) crossmixDirector.onItemChanged()

        val advancedNaturally = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
            reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT
        if (!promotingCrossmix && (!isCrossfading || advancedNaturally)) {
            // Clear a stale deck mute before it can carry over to the next song.
            playerCrossmixProcessors[player]?.clear()
            if (advancedNaturally) {
                crossfadeJob?.cancel()
                transport.cancel()
                player.volume = targetVolume()
            }
        }
        // the songs either side of the new one get their first seconds fetched, for a blended skip
        prefetchNeighbours()

        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
            val repeatMode = dataStore.get(RepeatModeKey, REPEAT_MODE_OFF)
            if (repeatMode == REPEAT_MODE_ONE &&
                previousMediaItemIndex != C.INDEX_UNSET &&
                previousMediaItemIndex != player.currentMediaItemIndex) {

                player.seekTo(previousMediaItemIndex, 0)
            }
        }
        previousMediaItemIndex = player.currentMediaItemIndex

        mediaItem?.mediaId?.let { announceStreamSource(it) }
        mediaItem?.mediaId?.let { announceMusicVideoAudio(it) }

        setupLoudnessEnhancer()

        scrobbleTimer.onSongStop()
        playReporter.onSongStop()
        if (player.playWhenReady && player.playbackState == Player.STATE_READY) {
            scrobbleTimer.onSongStart(player.currentMetadata, player.duration)
            playReporter.onSongStart(player.currentMetadata, player.duration)
        }

        if (castConnectionHandler?.isCasting?.value == true &&
            castConnectionHandler?.isSyncingFromCast != true &&
            mediaItem != null) {
            val metadata = mediaItem.metadata
            if (metadata != null) {

                val navigated = castConnectionHandler?.navigateToMediaIfInQueue(metadata.id) ?: false
                if (!navigated) {

                    castConnectionHandler?.loadMedia(metadata)
                }
            }
        }

        if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) {
            ensureQueueRunway()
        }

        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }
    }

    override fun onPlaybackStateChanged(
        @Player.State playbackState: Int,
    ) {
        // IDLE is where a failed stream sits; anything else means it's loading or playing again
        if (playbackState != Player.STATE_IDLE) {
            clearStreamFailure()
            // A manual Play or provider change can start a new prepare during network backoff.
            // Its own failure must be allowed to create a new wait.
            clearNetworkWait()
        }

        if (playbackState == Player.STATE_ENDED) {
            val target = player
            val occurrence = providerOccurrence
            // Let the other listeners (including the sleep timer) see ENDED before advancing.
            scope.launch {
                if (player !== target || providerOccurrence != occurrence || target.playbackState != Player.STATE_ENDED) return@launch
                if (!advanceQueueAtEnd(target)) ensureQueueRunway()
            }
        }

        if (dataStore.get(PersistentQueueKey, true) && !isSilenceSkipping) {
            saveQueueToDisk()
        }

        if (playbackState == Player.STATE_READY) {
            consecutivePlaybackErr = 0
            retryCount = 0
            providerLookupRetries = 0
            waitingForNetworkConnection.value = false
            retryJob?.cancel()

            player.currentMediaItem?.mediaId?.let { mediaId ->
                resetRetryCount(mediaId)
                Timber.tag(TAG).d("Playback successful for $mediaId, reset retry count")
            }
            scheduleCrossfade()
        }

        if (playbackState == Player.STATE_IDLE || playbackState == Player.STATE_ENDED) {
            scrobbleTimer.onSongStop()
            playReporter.onSongStop()
        }
    }

    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
        if (!playWhenReady) {
            clearNetworkWait()
            moduleEndWaiting = null
        }

        if (playWhenReady && castConnectionHandler?.isCasting?.value == true) {
            player.pause()
            return
        }

        if (playWhenReady) {
            muteResume = null
            setupLoudnessEnhancer()
        }
    }

    private var bufferingRecoveryJob: Job? = null
    private var bufferingRecoveredOccurrence = -1L

    private fun watchForPlaybackStall(target: Player) {
        if (target !== player) return
        if (!target.playWhenReady || target.playbackState != Player.STATE_BUFFERING ||
            target.playbackSuppressionReason != Player.PLAYBACK_SUPPRESSION_REASON_NONE
        ) {
            bufferingRecoveryJob?.cancel()
            bufferingRecoveryJob = null
            if (target.playbackState == Player.STATE_READY) bufferingRecoveredOccurrence = -1L
            return
        }
        val mediaItem = target.currentMediaItem ?: return
        val mediaId = mediaItem.mediaId
        val occurrence = providerOccurrence
        val pauseGeneration = transport.pauseGeneration
        if (bufferingRecoveryJob?.isActive == true) return
        fun isStillStalled() = player === target && providerOccurrence == occurrence &&
            target.playWhenReady && transport.pauseGeneration == pauseGeneration &&
            target.playbackState == Player.STATE_BUFFERING &&
            target.playbackSuppressionReason == Player.PLAYBACK_SUPPRESSION_REASON_NONE &&
            handoffFor(mediaId) == null && castConnectionHandler?.isCasting?.value != true &&
            !waitingForNetworkConnection.value

        bufferingRecoveryJob = scope.launch {
            val deadline = android.os.SystemClock.elapsedRealtime() + 25_000L
            var sampledStream: CustomStreamResult? = null
            var sampledPosition = C.TIME_UNSET
            var lastBufferedMs = C.TIME_UNSET
            var sampleStartedAt = 0L
            var lastProgressAt = 0L
            while (true) {
                val remaining = deadline - android.os.SystemClock.elapsedRealtime()
                if (remaining <= 0L) break
                delay(minOf(remaining, BufferProgressSampleMs))
                if (!isStillStalled()) return@launch

                // A URL can resolve quickly and still deliver audio too slowly. Only measure
                // automatic module streams, after the media source has received their URL.
                val stream = playingStreams[mediaId]?.takeIf {
                    it.cacheKey?.startsWith(ModuleCacheKeyPrefix) == true && forcedRoutes[mediaId] == null
                }
                val now = android.os.SystemClock.elapsedRealtime()
                val position = target.contentPosition
                val bufferedMs = target.totalBufferedDuration
                if (stream !== sampledStream || position != sampledPosition) {
                    sampledStream = stream
                    sampledPosition = position
                    lastBufferedMs = bufferedMs
                    sampleStartedAt = now
                    lastProgressAt = now
                } else if (bufferedMs - lastBufferedMs >= 250L) {
                    lastBufferedMs = bufferedMs
                    lastProgressAt = now
                }
                if (stream != null &&
                    (now - lastProgressAt >= ModuleNoBufferProgressMs || now - sampleStartedAt >= ModuleBufferWaitMs) &&
                    !com.mochyy.mochymusic.utils.OfflineMode.isOn && connectivityObserver.isCurrentlyConnected() &&
                    providerSwitch.state.value !is ProviderSwitchState.Working &&
                    providerSwitch.state.value !is ProviderSwitchState.Starting &&
                    !isCrossfading && !crossmixDirector.isTransitioning &&
                    forceFallBack(mediaId, announce = false, stalledStream = stream)
                ) return@launch
            }
            if (!isStillStalled()) return@launch

            if (bufferingRecoveredOccurrence == occurrence) {
                val onDevice = withContext(Dispatchers.IO) { playsOffline(mediaItem) }
                if (!isStillStalled()) return@launch
                val offlineMode = com.mochyy.mochymusic.utils.OfflineMode.isOn
                if (offlineMode || !connectivityObserver.isCurrentlyConnected()) {
                    val next = nextOfflineIndex()
                    if (next != C.INDEX_UNSET) {
                        playOfflineSong(next)
                        return@launch
                    }
                    if (!onDevice && !offlineMode) {
                        target.stop()
                        waitOnNetworkError()
                        return@launch
                    }
                }
                bufferingRecoveryJob = null
                if (onDevice || offlineMode || !forceFallBack(mediaId, includeYouTube = true, announce = false)) {
                    target.stop()
                    lastPlaybackError = PlaybackException(
                        getString(R.string.pippo_playback_stalled), null, PlaybackException.ERROR_CODE_TIMEOUT,
                    )
                    failStream(allowAutoRecovery = !offlineMode)
                }
                return@launch
            }

            val index = target.currentMediaItemIndex
            if (index == C.INDEX_UNSET) return@launch
            bufferingRecoveredOccurrence = occurrence
            val position = target.contentPosition.coerceAtLeast(0L)
            songUrlCache.remove(mediaId)
            bufferingRecoveryJob = null
            target.stop()
            target.seekTo(index, position)
            target.prepare()
        }
    }

    private var moduleEndRecoveryJob: Job? = null
    private var moduleEndWaiting: Pair<Long, Long>? = null

    private fun waitingAtModuleEnd(target: Player): Boolean =
        moduleEndWaiting == (providerOccurrence to transport.pauseGeneration) &&
            target.duration > 0L && target.contentPosition >= target.duration

    private fun watchForModuleTrackEnd(target: Player) {
        moduleEndRecoveryJob?.cancel()
        moduleEndRecoveryJob = null
        val mediaId = target.currentMediaItem?.mediaId ?: return
        val stream = playingStreams[mediaId] ?: return
        if (stream.cacheKey?.startsWith(ModuleCacheKeyPrefix) != true || stream.isDash || stream.isHls) return

        val occurrence = providerOccurrence
        val pauseGeneration = transport.pauseGeneration
        fun stillPlaying() = player === target && providerOccurrence == occurrence && target.isPlaying &&
            transport.pauseGeneration == pauseGeneration && !target.isCurrentMediaItemDynamic &&
            !target.isCurrentMediaItemLive && !target.isPlayingAd && target.duration > 0L &&
            handoffFor(mediaId) == null && castConnectionHandler?.isCasting?.value != true

        if (!stillPlaying()) return
        moduleEndRecoveryJob = scope.launch {
            val remaining = (target.duration - target.contentPosition).coerceAtLeast(0L)
            delay((remaining / target.playbackParameters.speed.toDouble()).toLong() + ModuleEndGraceMs)
            if (!stillPlaying()) return@launch
            // Use the decoded timeline, never the module's catalog estimate. If the clock has
            // not reached the end, wait for it instead of skipping legitimate audio.
            while (target.contentPosition < target.duration || transport.isFading ||
                isCrossfading || crossmixDirector.isTransitioning
            ) {
                delay(ModuleEndGraceMs)
                if (!stillPlaying()) return@launch
            }
            val duration = target.duration
            var position = target.contentPosition
            // A healthy decoder drains or moves to the next period. On slower playback speeds,
            // the first grace window can end while the clock is still draining near the end.
            while (true) {
                delay(ModuleEndGraceMs)
                if (!stillPlaying() || target.duration != duration || target.contentPosition < duration ||
                    transport.isFading || isCrossfading || crossmixDirector.isTransitioning
                ) return@launch
                if (target.contentBufferedPosition > duration + ModuleEndBufferToleranceMs) return@launch
                val current = target.contentPosition
                if (current == position || current - duration >= ModuleEndGraceMs) break
                position = current
            }

            Timber.tag(TAG).w("Module playback did not finish at the end of %s", mediaId)
            if (sleepTimer.pauseWhenSongEnd) {
                sleepTimer.notifySongTransition()
            } else if (!advanceQueueAtEnd(target)) {
                if (currentQueue.hasOwnNextPage() || isInfiniteQueueEnabled()) {
                    // A decoder stuck in READY never sends ENDED to the pagination callback.
                    moduleEndWaiting = occurrence to pauseGeneration
                    ensureQueueRunway()
                } else {
                    target.pause()
                }
            }
        }
    }

    private fun advanceQueueAtEnd(target: Player): Boolean {
        if (!target.playWhenReady || transport.playIntent.value == false || sleepTimer.pauseWhenSongEnd ||
            castConnectionHandler?.isCasting?.value == true || handoffFor(target.currentMediaItem?.mediaId.orEmpty()) != null
        ) return false
        val timeline = target.currentTimeline
        val index = target.currentMediaItemIndex
        if (index !in 0 until timeline.windowCount) return false
        val next = timeline.getNextWindowIndex(index, target.repeatMode, target.shuffleModeEnabled)
        if (next == C.INDEX_UNSET) return false
        moduleEndWaiting = null
        target.seekToDefaultPosition(next)
        target.prepare()
        return true
    }

    override fun onEvents(
        player: Player,
        events: Player.Events,
    ) {
        if (player === this.player && !destroying && playerInitialized.value) {
            if (events.contains(Player.EVENT_IS_PLAYING_CHANGED)) queueSavePlaying.value = player.isPlaying
            if (!player.isPlaying && events.contains(Player.EVENT_POSITION_DISCONTINUITY)) scheduleQueueEditSave()
        }
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_PLAYBACK_SUPPRESSION_REASON_CHANGED,
                Player.EVENT_MEDIA_ITEM_TRANSITION,
            )
        ) {
            watchForPlaybackStall(player)
        }
        if (player === this.player && events.containsAny(
                Player.EVENT_IS_PLAYING_CHANGED,
                Player.EVENT_MEDIA_ITEM_TRANSITION,
                Player.EVENT_TIMELINE_CHANGED,
                Player.EVENT_POSITION_DISCONTINUITY,
                Player.EVENT_PLAYBACK_PARAMETERS_CHANGED,
            )
        ) watchForModuleTrackEnd(player)
        if (player === this.player && player.playbackState == Player.STATE_READY &&
            events.containsAny(Player.EVENT_PLAYBACK_STATE_CHANGED, Player.EVENT_TRACKS_CHANGED, Player.EVENT_TIMELINE_CHANGED)
        ) {
            providerHandoff?.let { handoff ->
                // READY can also describe the old source while Media3 updates the track groups.
                // Wait for the prepared replacement and its selected decoder before committing.
                val decoded = StreamFacts.selectedAudio(player.currentTracks)
                if (providerHandoffHost.currentTarget() == handoff.target &&
                    handoff.resolvedFrom != null && handoff.stream != null && decoded != null
                ) {
                    if (TrackMatcher.isDurationCompatible(handoff.route.expectedDurationMs, player.duration)) {
                        handoff.facts = playbackFacts(handoff.facts, decoded)
                        handoff.ready.complete(ProviderSwitch.HandoffResult.Ready)
                    } else {
                        handoff.ready.complete(ProviderSwitch.HandoffResult.Failed(getString(R.string.pc_force_wrong_recording)))
                    }
                }
            }
        }
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED
            )
        ) {
            scheduleCrossfade()
            val isBufferingOrReady =
                player.playbackState == Player.STATE_BUFFERING || player.playbackState == Player.STATE_READY
            if (isBufferingOrReady && player.playWhenReady) {
                val focusGranted = requestAudioFocus()
                if (focusGranted) {
                    openAudioEffectSession()
                }
            } else {
                closeAudioEffectSession()
            }
        }
        if (events.containsAny(EVENT_TIMELINE_CHANGED, EVENT_POSITION_DISCONTINUITY)) {
            currentMediaMetadata.value = player.currentMetadata
        }

        if (events.containsAny(Player.EVENT_IS_PLAYING_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION,
                Player.EVENT_POSITION_DISCONTINUITY, Player.EVENT_TRACKS_CHANGED)) {
            watchPlatformOutput(player)
        }

        if (events.containsAny(Player.EVENT_IS_PLAYING_CHANGED)) {
            updateWidgetUI()
            if (player.isPlaying) {
                startWidgetUpdates()
            } else {
                stopWidgetUpdates()
            }
        } else if (events.containsAny(Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_PLAYBACK_STATE_CHANGED) ||
            (!player.isPlaying && events.contains(EVENT_POSITION_DISCONTINUITY))
        ) {
            updateWidgetUI()
        }

        if (events.containsAny(
                Player.EVENT_MEDIA_ITEM_TRANSITION,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_POSITION_DISCONTINUITY,
            )
        ) {
            publishPresence()
        }

        if (events.containsAny(Player.EVENT_IS_PLAYING_CHANGED)) {
            scrobbleTimer.onPlayingChanged(player.isPlaying, player.currentMetadata, player.duration)
            playReporter.onPlayingChanged(player.isPlaying, player.currentMetadata, player.duration)
            // Save the exact position at pause before the periodic saves stop.
            if (!player.isPlaying && player.playbackState == Player.STATE_READY && dataStore.get(PersistentQueueKey, true)) {
                saveQueueToDisk()
            }
        }

    }

    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
        updateNotification()
        if (shuffleModeEnabled) {

            if (player.mediaItemCount == 0) return

            val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
            val currentIndex = player.currentMediaItemIndex
            val totalCount = player.mediaItemCount

            applyShuffleOrder(currentIndex, totalCount, shufflePlaylistFirst, keepHistory = true)
        }

        if (dataStore.get(RememberShuffleAndRepeatKey, true)) {
            scope.launch {
                dataStore.edit { settings ->
                    settings[ShuffleModeKey] = shuffleModeEnabled
                }
            }
        }

        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }
    }

    override fun onRepeatModeChanged(repeatMode: Int) {
        updateNotification()
        // a crossfade or mix planned before repeat one went on would still swap players at the end, and the song came round silent
        scheduleCrossfade()
        scope.launch {
            dataStore.edit { settings ->
                settings[RepeatModeKey] = repeatMode
            }
        }

        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }
    }

    private fun applyShuffleOrder(
        currentIndex: Int,
        totalCount: Int,
        shufflePlaylistFirst: Boolean,
        /**
         * Songs before the current one already played: keep them, in order, as history rather than
         * shuffling them back in. True when shuffle is switched on mid-queue; false when a queue
         * starts shuffled partway in, where those songs haven't played yet.
         */
        keepHistory: Boolean = false,
    ) {
        if (totalCount == 0) return

        if (shufflePlaylistFirst && originalQueueSize > 0 && originalQueueSize < totalCount) {

            val originalIndices = (0 until originalQueueSize).filter { it != currentIndex }.toMutableList()
            val addedIndices = (originalQueueSize until totalCount).filter { it != currentIndex }.toMutableList()

            originalIndices.shuffle()
            addedIndices.shuffle()

            val shuffledIndices = IntArray(totalCount)
            var pos = 0
            shuffledIndices[pos++] = currentIndex

            if (currentIndex < originalQueueSize) {
                originalIndices.forEach { shuffledIndices[pos++] = it }
                addedIndices.forEach { shuffledIndices[pos++] = it }
            } else {
                (0 until originalQueueSize).shuffled().forEach { shuffledIndices[pos++] = it }
                addedIndices.forEach { shuffledIndices[pos++] = it }
            }
            player.setShuffleOrder(DefaultShuffleOrder(shapeShuffleOrder(shuffledIndices, currentIndex, keepHistory), System.currentTimeMillis()))
        } else {
            val shuffledIndices = IntArray(totalCount) { it }
            shuffledIndices.shuffle()

            val currentItemIndexInShuffled = shuffledIndices.indexOf(currentIndex)
            if (currentItemIndexInShuffled != -1) {
                val temp = shuffledIndices[0]
                shuffledIndices[0] = shuffledIndices[currentItemIndexInShuffled]
                shuffledIndices[currentItemIndexInShuffled] = temp
            }
            player.setShuffleOrder(DefaultShuffleOrder(shapeShuffleOrder(shuffledIndices, currentIndex, keepHistory), System.currentTimeMillis()))
        }
    }

    /** Autoplay to the back; with [keepHistory], the songs before [currentIndex] to the front, in order. */
    private fun shapeShuffleOrder(order: IntArray, currentIndex: Int, keepHistory: Boolean): IntArray {
        val shaped = pinQueuedSongs(order, currentIndex)
        if (!keepHistory || currentIndex <= 0) return shaped
        val result = IntArray(shaped.size)
        var pos = 0
        for (i in 0 until currentIndex) result[pos++] = i
        for (i in shaped) if (i >= currentIndex) result[pos++] = i
        return result
    }

    /**
     * Shuffle mixes what came with the queue, not what the user lined up by hand and not Autoplay:
     * the songs queued by hand come first, in the order they were queued, and Autoplay stays after
     * everything else, in the order the radio gave them. The song playing keeps its place at the front.
     */
    private fun pinQueuedSongs(order: IntArray, currentIndex: Int): IntArray {
        if (order.isEmpty()) return order
        val first = order[0]
        val manual = ArrayList<Int>()
        val autoplay = ArrayList<Int>()
        for (i in 0 until player.mediaItemCount) {
            if (i == first) continue
            val item = player.getMediaItemAt(i)
            if (item.isAutoplay) autoplay += i else if (i > currentIndex && item.isManualQueued) manual += i
        }
        if (manual.isEmpty() && autoplay.isEmpty()) return order
        val pinned = HashSet<Int>(manual.size + autoplay.size).apply { addAll(manual); addAll(autoplay) }
        val result = IntArray(order.size)
        var pos = 0
        result[pos++] = first
        for (index in manual) result[pos++] = index
        for (index in order) if (index != first && index !in pinned) result[pos++] = index
        for (index in autoplay) result[pos++] = index
        return result
    }

    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
        super.onPlaybackParametersChanged(playbackParameters)
        // a faster song ends sooner: Discord's bar has to know
        publishPresence()
    }

    private fun getHttpResponseCode(error: PlaybackException): Int? {
        var cause: Throwable? = error.cause
        while (cause != null) {
            if (cause is HttpDataSource.InvalidResponseCodeException) {
                return cause.responseCode
            }
            cause = cause.cause
        }
        return null
    }

    private fun isExpiredUrlError(error: PlaybackException): Boolean {
        val responseCode = getHttpResponseCode(error)
        return responseCode == 403
    }

    private fun isRangeNotSatisfiableError(error: PlaybackException): Boolean {
        val responseCode = getHttpResponseCode(error)
        return responseCode == 416
    }

    private fun isPageReloadError(error: PlaybackException): Boolean {
        val errorMessage = error.message?.lowercase() ?: ""
        val causeMessage = error.cause?.message?.lowercase() ?: ""
        val innerCauseMessage = error.cause?.cause?.message?.lowercase() ?: ""

        val reloadKeywords = listOf(
            "page needs to be reloaded",
            "pagina deve essere ricaricata",
            "la pagina deve essere ricaricata",
            "page must be reloaded",
            "reload",
            "ricaricata"
        )

        return reloadKeywords.any { keyword ->
            errorMessage.contains(keyword) ||
            causeMessage.contains(keyword) ||
            innerCauseMessage.contains(keyword)
        }
    }

    private fun isNetworkRelatedError(error: PlaybackException): Boolean {

        if (isExpiredUrlError(error) || isRangeNotSatisfiableError(error) || isPageReloadError(error)) {
            return false
        }
        return generateSequence<Throwable>(error) { it.cause }.any { cause ->
            when (cause) {
                is java.net.ConnectException, is java.net.UnknownHostException, is java.net.SocketTimeoutException -> true
                is PlaybackException -> cause.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                    cause.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                else -> false
            }
        }
    }

    private fun isAudioRendererError(error: PlaybackException): Boolean {
        return error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                (error.cause as? PlaybackException)?.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED ||
                (error.cause as? PlaybackException)?.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED
    }

    override fun onPlayerError(error: PlaybackException) {
        super.onPlayerError(error)

        if (!playerInitialized.value) {
            Timber.tag(TAG).e(error, "Player error occurred but player not initialized")
            return
        }

        providerHandoff?.let { handoff ->
            if (providerHandoffHost.currentTarget() == handoff.target) {
                if (!isAudioRendererError(error)) discardFailedRendition(handoff.stream?.cacheKey)
                handoff.ready.complete(ProviderSwitch.HandoffResult.Failed(
                    getString(R.string.pc_force_player_error, error.errorCodeName)
                ))
                return
            }
        }

        // AudioTrack failures are local output failures, not a bad provider or corrupt stream.
        // Recover before provider fallback/cache eviction can discard a healthy song.
        if (isAudioRendererError(error)) {
            lastPlaybackError = error
            val failedId = player.currentMediaItem?.mediaId
            if (failedId == null || audioOutputRecoveryAttempts >= MAX_RETRY_PER_SONG) {
                audioOutputRecoveryAttempts = 0
                reportAudioOutputFailure()
            } else {
                handleAudioRendererError(failedId)
            }
            return
        }

        // Offline mode refused a song that isn't on the device before anything went out. Nothing
        // to retry or recover - and the recovery below clears the song's cache, which is what
        // offline playback plays from - so straight on to the next song that is on the device.
        if (com.mochyy.mochymusic.utils.OfflineMode.isOn &&
            generateSequence<Throwable>(error) { it.cause }.any { it is com.music.innertube.OfflineModeException }
        ) {
            if (!player.playWhenReady) return
            val next = nextOfflineIndex()
            if (next != C.INDEX_UNSET) {
                playOfflineSong(next)
            } else {
                player.pause()
                showBanner("Offline mode: nothing after this is on your device")
            }
            return
        }

        val onPhone = player.currentMediaItem?.let(::playsOffline) == true
        // no internet and this song needs it: waiting stopped the queue for good, so go on to the next song that's on the phone
        val connected = connectivityObserver.isCurrentlyConnected()
        if (player.playWhenReady && !onPhone && !connected) {
            val next = nextOfflineIndex()
            if (next != C.INDEX_UNSET) {
                Timber.tag(TAG).i("No internet for ${player.currentMediaItem?.mediaId}, moving on to the next song on the phone")
                playOfflineSong(next)
                showBanner(getString(R.string.no_internet_next_on_phone))
                return
            }
        }

        lastPlaybackError = error
        val lookupFailure = generateSequence<Throwable>(error) { it.cause }
            .filterIsInstance<NoProviderException>().firstOrNull()
        if (lookupFailure != null) {
            when {
                !connected && !onPhone -> waitOnNetworkError()
                lookupFailure.retryable && retryProviderLookup() -> Unit
                else -> {
                    val mediaId = player.currentMediaItem?.mediaId
                    if (mediaId != null && lookupFailure.providerId != null &&
                        resolvedSourceIds[mediaId] == lookupFailure.providerId &&
                        forceFallBack(mediaId, includeYouTube = true, announce = false)
                    ) return
                    if (player.playWhenReady) {
                        notifyPlaybackError(getString(R.string.error_stream_unavailable_title), lookupFailure.message.orEmpty())
                    }
                    failStream()
                }
            }
            return
        }
        val mediaId = player.currentMediaItem?.mediaId
        Timber.tag(TAG).w(error, "Player error occurred for $mediaId: errorCode=${error.errorCode}, message=${error.message}, causes=${generateSequence<Throwable>(error) { it.cause }.joinToString(" <- ") { it.javaClass.simpleName + ":" + it.message }}")
        reportException(error)

        // a decoder turning the format down: the next provider's toast says so
        if (mediaId != null && isDecoderError(error)) {
            val format = (error as? androidx.media3.exoplayer.ExoPlaybackException)?.rendererFormat
            noteMissingDecoder(
                mediaId,
                StreamFacts.codecOf(format?.sampleMimeType, format?.codecs) ?: streamFacts.value[mediaId]?.codec,
                format?.sampleRate,
            )
        }
        if (!onPhone && !connected) {
            Timber.tag(TAG).d("Network-related error detected, waiting for connection")
            waitOnNetworkError()
            return
        }

        val httpCode = getHttpResponseCode(error)
        val badContainer = isContainerParseError(error)
        val freshLink = httpCode == 401 || isExpiredUrlError(error) || isPageReloadError(error)
        val rangeRejected = isRangeNotSatisfiableError(error)
        val transientRead = !onPhone && isNetworkRelatedError(error)
        val retryCount = mediaId?.let(currentMediaIdRetryCount::get) ?: 0
        // A stale link, rejected range or dropped connection gets a fresh attempt on this source.
        if (mediaId != null && retryCount == 0 && (freshLink || rangeRejected || transientRead)) {
            retryStreamRead(mediaId, discardBytes = rangeRejected)
            return
        }
        if (mediaId != null && forceFallBack(mediaId, announce = !decoderNotices.containsKey(mediaId))) return

        if (mediaId != null && hasExceededRetryLimit(mediaId)) {
            markSongAsFailed(mediaId)
            handleFinalFailure()
            return
        }

        if (mediaId != null && (freshLink || rangeRejected || transientRead || badContainer ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE)
        ) {
            retryStreamRead(
                mediaId,
                discardBytes = badContainer || rangeRejected,
                restartFromBeginning = rangeRejected && retryCount > 0,
            )
            return
        }

        Timber.tag(TAG).d("Unrecoverable error, failing the stream")
        failStream()
    }

    private fun isContainerParseError(error: PlaybackException) =
        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED

    private fun discardFailedRendition(cacheKey: String?) {
        if (cacheKey == null || !cacheKey.startsWith(ModuleCacheKeyPrefix)) return
        scope.launch(Dispatchers.IO) {
            runCatching { playerCache.removeResource(cacheKey) }
                .onFailure { Timber.tag(TAG).w(it, "Couldn't clear the failed audio rendition") }
        }
    }

    private fun hasExceededRetryLimit(mediaId: String): Boolean {
        val currentRetries = currentMediaIdRetryCount[mediaId] ?: 0
        return currentRetries >= MAX_RETRY_PER_SONG
    }

    private fun incrementRetryCount(mediaId: String) {
        val currentRetries = currentMediaIdRetryCount[mediaId] ?: 0
        currentMediaIdRetryCount[mediaId] = currentRetries + 1
        Timber.tag(TAG).d("Retry count for $mediaId: ${currentRetries + 1}/$MAX_RETRY_PER_SONG")
    }

    private fun resetRetryCount(mediaId: String) {
        currentMediaIdRetryCount.remove(mediaId)
        recentlyFailedSongs.remove(mediaId)
    }

    private fun markSongAsFailed(mediaId: String) {
        recentlyFailedSongs.add(mediaId)
        currentMediaIdRetryCount.remove(mediaId)

        failedSongsClearJob?.cancel()
        failedSongsClearJob = scope.launch {
            delay(5 * 60 * 1000L)
            recentlyFailedSongs.clear()
            Timber.tag(TAG).d("Cleared recently failed songs list")
        }
    }

    private fun reportAudioOutputFailure() {
        failStream(allowAutoRecovery = false)
        showBanner(getString(R.string.audio_output_reconnect))
    }

    private fun handleAudioRendererError(mediaId: String) {
        audioOutputRecoveryAttempts++

        // whether it was playing, read before the pause below wipes it: the recovery used to go
        // by the audio-focus flag instead, so it re-prepared the song and left it paused
        val target = player
        val resume = player.playWhenReady || focusResume?.stillCurrent() == true
        val occurrence = providerOccurrence
        val pauseGeneration = transport.pauseGeneration
        retryJob?.cancel()
        retryJob = scope.launch {
            try {

                if (player !== target || providerOccurrence != occurrence ||
                    target.playbackState != Player.STATE_IDLE || transport.pauseGeneration != pauseGeneration ||
                    handoffFor(mediaId) != null || castConnectionHandler?.isCasting?.value == true
                ) return@launch
                target.pause()
                audioOutputs.releaseMixer()
                Timber.tag(TAG).d("Paused playback due to AudioTrack error")

                delay(RETRY_DELAY_MS * 3)

                if (!playerInitialized.value || player !== target || providerOccurrence != occurrence ||
                    target.playbackState != Player.STATE_IDLE || transport.pauseGeneration != pauseGeneration ||
                    handoffFor(mediaId) != null || castConnectionHandler?.isCasting?.value == true) {
                    Timber.tag(TAG).w("Player no longer initialized, aborting AudioTrack recovery")
                    return@launch
                }

                val currentIndex = player.currentMediaItemIndex
                if (currentIndex != C.INDEX_UNSET) {

                    val currentPosition = player.currentPosition
                    player.seekTo(currentIndex, currentPosition)
                    val shouldResume = mayResumeRecovery(mediaId, target.currentMediaItem?.mediaId,
                        resume || target.playWhenReady, castConnectionHandler?.isCasting?.value == true,
                        pauseGeneration, transport.pauseGeneration)
                    // Restore intent BEFORE prepare: READY cancels retryJob, so waiting after prepare
                    // could cancel the only code that would ever press play again.
                    target.playWhenReady = shouldResume && (hasAudioFocus || requestAudioFocus())
                    target.prepare()
                    Timber.tag(TAG).d("Retrying playback for $mediaId after AudioTrack error")
                } else {
                    Timber.tag(TAG).w("Invalid media item index during AudioTrack recovery")
                    reportAudioOutputFailure()
                }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Error during AudioTrack error recovery")
                if (player === target && providerOccurrence == occurrence &&
                    transport.pauseGeneration == pauseGeneration
                ) reportAudioOutputFailure()
            }
        }
    }

    private fun retryStreamRead(
        mediaId: String,
        discardBytes: Boolean,
        restartFromBeginning: Boolean = false,
    ) {
        val target = player
        if (!target.playWhenReady) return
        val occurrence = providerOccurrence
        val pauseGeneration = transport.pauseGeneration
        val fromDevice = resolvedSourceIds[mediaId] in setOf(PlayingFrom.Device, PlayingFrom.Downloads)
        val cacheKey = playingStreams[mediaId]?.cacheKey ?: mediaId
        incrementRetryCount(mediaId)
        retryJob?.cancel()
        fun stillCurrent() = player === target && providerOccurrence == occurrence &&
            target.playWhenReady && transport.pauseGeneration == pauseGeneration &&
            target.playbackState == Player.STATE_IDLE && target.currentMediaItemIndex != C.INDEX_UNSET &&
            handoffFor(mediaId) == null && castConnectionHandler?.isCasting?.value != true

        retryJob = scope.launch {
            delay(RETRY_DELAY_MS)
            if (!stillCurrent()) return@launch
            songUrlCache.remove(mediaId)
            if (discardBytes && !fromDevice) {
                withContext(Dispatchers.IO) {
                    runCatching { playerCache.removeResource(cacheKey) }
                        .onFailure { Timber.tag(TAG).w(it, "Couldn't clear the failed audio rendition") }
                }
            }
            if (!stillCurrent()) return@launch
            target.seekTo(target.currentMediaItemIndex, if (restartFromBeginning) 0L else target.contentPosition)
            target.prepare()
        }
    }

    private fun handleFinalFailure() {
        player.currentMediaItem?.mediaId?.let { if (forceFallBack(it, includeYouTube = true)) return }
        Timber.tag(TAG).d("All recovery attempts exhausted, failing the stream")
        failStream()
    }

    override fun onDeviceVolumeChanged(volume: Int, muted: Boolean) {
        super.onDeviceVolumeChanged(volume, muted)
        val pauseOnMute = dataStore.get(PauseOnMute, false)

        if (!pauseOnMute) {
            muteResume = null
        } else if (volume == 0 || muted) {
            pauseForInterruption()?.let { muteResume = it }
        } else {
            val pending = muteResume
            muteResume = null
            if (pending?.canResume() == true) transport.play()
        }
    }

    private fun createCacheDataSource(): CacheDataSource.Factory =
        CacheDataSource
            .Factory()
            .setCache(downloadCache)
            .setUpstreamDataSourceFactory(
                CacheDataSource
                    .Factory()
                    .setCache(playerCache)
                    .setUpstreamDataSourceFactory(
                        ResolvingDataSource.Factory(
                            DefaultDataSource.Factory(
                                this,
                                OkHttpDataSource.Factory(
                                    OkHttpClient
                                        .Builder()
                                        .dns(object : Dns {
                                            override fun lookup(hostname: String): List<InetAddress> {
                                                val addresses = Dns.SYSTEM.lookup(hostname)
                                                return when (this@MusicService.ipVersion) {
                                                    IpVersion.IPV4 -> addresses.filter { it is Inet4Address }.ifEmpty { addresses }
                                                    IpVersion.IPV6 -> addresses.filter { it is Inet6Address }.ifEmpty { addresses }
                                                    IpVersion.AUTO -> addresses
                                                }
                                            }
                                        })
                                        .followAppProxy()
                                        .build(),
                                ),
                            ),
                        ) { request ->
                            val scheme = request.uri.scheme
                            if (com.mochyy.mochymusic.utils.OfflineMode.isOn && (scheme == "http" || scheme == "https")) {
                                throw com.music.innertube.OfflineModeException()
                            }
                            request
                        },
                    ),
            ).setCacheWriteDataSinkFactory(null)
            .setFlags(FLAG_IGNORE_CACHE_ON_ERROR)

    private var isSilenceSkipping = false

    private fun handleLongSilenceDetected() {
        if (!instantSilenceSkipEnabled.value) return
        if (silenceSkipJob?.isActive == true) return

        silenceSkipJob = scope.launch {

            delay(200)
            performInstantSilenceSkip()
        }
    }

    private suspend fun performInstantSilenceSkip() {
        val duration = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: return
        if (duration <= INSTANT_SILENCE_SKIP_STEP_MS) return

        isSilenceSkipping = true
        try {
            var hops = 0
            val silenceProcessor = playerSilenceProcessors[player] ?: return
            while (coroutineContext.isActive && instantSilenceSkipEnabled.value && silenceProcessor.isCurrentlySilent()) {
                val current = player.currentPosition
                val target = (current + INSTANT_SILENCE_SKIP_STEP_MS).coerceAtMost(duration - 500)

                if (target <= current) break

                silenceProcessor.resetTracking()
                player.seekTo(target)
                hops++

                if (hops >= 80 || target >= duration - 500) break

                delay(INSTANT_SILENCE_SKIP_SETTLE_MS)
            }
            if (hops > 0) {
                Timber.tag(TAG).d("Silence skip: jumped $hops times")
            }
        } finally {
            isSilenceSkipping = false
        }
    }

    /** Tells the Discord status what's playing; it ignores this when Discord isn't signed in or is off. */
    private fun publishPresence() {
        val metadata = player.currentMetadata
        val state = player.playbackState
        if (metadata == null || state == Player.STATE_IDLE || state == Player.STATE_ENDED) {
            discordPresence.update(null)
            return
        }
        // the library's record lags a moment behind a song change; use it only once it's this song
        val song = currentSong.value?.takeIf { it.id == metadata.id }
        val facts = streamFacts.value[metadata.id]
        discordPresence.update(
            com.mochyy.mochymusic.discord.NowPlaying(
                mediaId = metadata.id,
                title = metadata.title,
                artist = metadata.artists.joinToString { it.name },
                album = metadata.album?.title ?: song?.song?.albumName,
                artworkUrl = metadata.thumbnailUrl,
                artistArtworkUrl = song?.artists?.firstNotNullOfOrNull { it.thumbnailUrl },
                durationMs = player.duration.takeIf { it > 0 } ?: (metadata.duration * 1000L),
                positionMs = player.currentPosition,
                readAtMs = System.currentTimeMillis(),
                speed = player.playbackParameters.speed,
                // buffering with play pressed still counts as playing, so the status doesn't flicker
                isPlaying = player.playWhenReady,
                quality = facts?.describe(
                    playingFrom.value[metadata.id]?.manualYouTubeFormat
                        ?: song?.format?.takeIf { !facts.fromModule },
                ),
                isYouTube = song?.song?.isLocal != true && metadata.localUri == null,
            ),
        )
    }

    /**
     * How many bytes of this track the player still needs from [dataSpec.position].
     *
     * Metrolist's approach: prefer the length the player asked for, else derive it from the
     * stored content length. Guessing a chunk when neither is known makes a partially cached
     * track look complete, which is how replay used to break.
     */
    /**
     * Whether [cache] has every byte [dataSpec] asks for. The cache's own record of the file's size
     * comes first. The format row is rewritten each time the song streams, so a finished download
     * checked against another stream's size looked incomplete, and the song went online for the
     * rest: "connection failed" offline, or the wrong stream glued on.
     */
    private fun holdsWhole(cache: SimpleCache, mediaId: String, dataSpec: DataSpec): Boolean {
        val length = when {
            dataSpec.length >= 0 -> dataSpec.length
            else -> runCatching {
                androidx.media3.datasource.cache.ContentMetadata.getContentLength(cache.getContentMetadata(mediaId))
            }.getOrNull()?.takeIf { it > 0L }?.let { (it - dataSpec.position).coerceAtLeast(1L) }
                ?: requiredCachedLength(mediaId, dataSpec)
        }
        return cache.isCached(mediaId, dataSpec.position, length)
    }

    /**
     * YouTube can hand back a different file for the same song from one lookup to the next: Opus
     * on Wi-Fi, AAC on mobile data, or whatever another client offers. Both are cached under the
     * song's id, so the start of one got glued onto the rest of the other and the player gave up
     * with "parsing container malformed". A different itag or length means a different file, so
     * the old bytes go.
     */
    private fun dropStaleCachedBytes(mediaId: String, itag: Int, contentLength: Long?) {
        if (playerCache.getCachedSpans(mediaId).isEmpty()) return
        val freshLength = contentLength ?: 0L
        val cachedLength = runCatching {
            androidx.media3.datasource.cache.ContentMetadata.getContentLength(playerCache.getContentMetadata(mediaId))
        }.getOrDefault(C.LENGTH_UNSET.toLong())
        val previous = runCatching { runBlocking(Dispatchers.IO) { database.format(mediaId).first() } }.getOrNull()
        val sameFile = when {
            previous != null && previous.itag != itag -> false
            cachedLength > 0 && freshLength > 0 -> cachedLength == freshLength
            previous != null -> previous.itag == itag &&
                (previous.contentLength <= 0 || freshLength <= 0 || previous.contentLength == freshLength)
            // nothing to compare against: a bad splice is still caught by the parse-error retry
            else -> true
        }
        if (sameFile) return
        Timber.tag(TAG).i("Cached bytes for $mediaId are from another stream (itag ${previous?.itag} -> $itag), dropping them")
        runCatching { playerCache.removeResource(mediaId) }
            .onFailure { Timber.tag(TAG).w(it, "Couldn't drop stale cached bytes for $mediaId") }
    }

    private fun requiredCachedLength(mediaId: String, dataSpec: DataSpec): Long {
        if (dataSpec.length >= 0) return dataSpec.length
        val contentLength = runCatching {
            runBlocking(Dispatchers.IO) { database.format(mediaId).first()?.contentLength }
        }.getOrNull()?.takeIf { it > 0L }
        return contentLength?.let { (it - dataSpec.position).coerceAtLeast(1L) } ?: CHUNK_LENGTH
    }

    /**
     * Post a visible, named playback error. The media notification channel is IMPORTANCE_LOW and
     * silent by design, so failures posted there go unnoticed - errors get their own channel.
     */
    // what the error says to the listener: plain words for the failures we understand, the resolver's own line for the rest
    private fun friendlyReason(throwable: Throwable): String = when (throwable) {
        is com.mochyy.mochymusic.utils.YouTubeBotCheckException -> getString(R.string.error_bot_check)
        is com.mochyy.mochymusic.utils.YouTubePremiumOnlyException ->
            getString(if (YouTube.cookie == null) R.string.error_premium_only_login else R.string.error_premium_only)
        is com.mochyy.mochymusic.utils.YouTubeRateLimitedException -> getString(R.string.error_rate_limited)
        else -> throwable.message ?: getString(R.string.error_unknown)
    }

    private fun notifyPlaybackError(title: String, message: String) {
        runCatching {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel(
                        ERROR_CHANNEL_ID,
                        getString(R.string.playback_error_channel_name),
                        NotificationManager.IMPORTANCE_DEFAULT,
                    ),
                )
            }
            val notification = NotificationCompat.Builder(this, ERROR_CHANNEL_ID)
                .setSmallIcon(R.drawable.mochy_notification)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .build()
            nm.notify(ERROR_NOTIFICATION_ID, notification)
        }.onFailure { Timber.tag(TAG).w(it, "Could not post playback error notification") }
    }

    // the song share's preview and video read the song through this, so they hit the same cache and get the same links playback does
    fun shareDataSourceFactory(): DataSource.Factory = createDataSourceFactory()

    private fun hasCachedStreamRange(key: String, request: DataSpec): Boolean {
        val length = request.length.takeIf { it > 0 } ?: runCatching {
            androidx.media3.datasource.cache.ContentMetadata.getContentLength(playerCache.getContentMetadata(key)) -
                request.position
        }.getOrDefault(0L)
        return length > 0 && playerCache.isCached(key, request.position, length)
    }

    private fun createDataSourceFactory(): DataSource.Factory {
        return ResolvingDataSource.Factory(createCacheDataSource()) { dataSpec ->
            // a stream a source module or backend resolved to a real URL (an HLS playlist, given
            // as a data: URI when the module rewrote it, and its segments) carries no media id:
            // it's fetched as it is
            val offline = com.mochyy.mochymusic.utils.OfflineMode.isOn
            if (dataSpec.uri.scheme == "data") return@Factory dataSpec
            val mediaId = dataSpec.key ?: when (dataSpec.uri.scheme) {
                "file", "content" -> return@Factory dataSpec
                "https", "http" -> {
                    if (!offline) return@Factory dataSpec
                    dataSpec.uri.toString() // Media3's default cache key for an unkeyed URL.
                }
                else -> throw java.io.IOException("No cache key for this audio request")
            }

            // A DASH stream's init and media segments (a source module's Tidal stream) are keyed by
            // their own URL, not the song's: Media3 drops the MediaItem's custom cache key for
            // segment requests. That key is an address already resolved, so it's fetched as it is,
            // keeping its per-segment key for the cache. Taking it for a song id sent the segment
            // URL to YouTube as a video id, and the song failed as "unavailable".
            if (isResolvedUrlCacheKey(mediaId)) {
                if (offline && !hasCachedStreamRange(mediaId, dataSpec)) throw com.music.innertube.OfflineModeException()
                return@Factory dataSpec
            }

            // A source module's stream (Monochrome's FLAC file) goes out as the module gave it. It
            // used to carry the bare media id, so everything below took it for a YouTube song and
            // swapped in YouTube's stream - a cached YouTube url, or a fresh one - whenever the FLAC
            // wasn't already in the cache: the song played as Opus with a FLAC badge until the
            // decoder said otherwise.
            if (mediaId.startsWith(ModuleCacheKeyPrefix)) {
                if (offline && !hasCachedStreamRange(mediaId, dataSpec)) throw com.music.innertube.OfflineModeException()
                return@Factory dataSpec.withRequestHeaders(
                    dataSpec.httpRequestHeaders + moduleStreamHeaders[mediaId].orEmpty()
                )
            }

            // a song streamed from the linked phone goes to the phone's address as it is
            if (mediaId.startsWith(com.mochyy.mochymusic.link.PhoneFiles.CacheKeyPrefix)) return@Factory dataSpec

            val shouldBypassCache = bypassCacheForQualityChange.contains(mediaId)

            val scheme = dataSpec.uri.scheme
            if (scheme == "content" || scheme == "file") {
                return@Factory dataSpec
            }

            if (!shouldBypassCache) {
                if (holdsWhole(downloadCache, mediaId, dataSpec) || holdsWhole(playerCache, mediaId, dataSpec)) {
                    scope.launch(Dispatchers.IO) { recoverSong(mediaId) }
                    return@Factory dataSpec
                }

                // Offline mode: what isn't on the device isn't fetched, not even from a url
                // already in hand. onPlayerError moves on to the next song that is.
                if (com.mochyy.mochymusic.utils.OfflineMode.isOn) throw com.music.innertube.OfflineModeException()

                songUrlCache[mediaId]?.takeIf { it.second > System.currentTimeMillis() }?.let { cached ->
                    scope.launch(Dispatchers.IO) { recoverSong(mediaId) }
                    return@Factory dataSpec
                        .withUri(cached.first.toUri())
                        .withRequestHeaders(dataSpec.httpRequestHeaders + songStreamHeaders[mediaId].orEmpty())
                }
            } else {
                Timber.tag("MusicService").i("BYPASSING CACHE for $mediaId due to quality change")
            }

            if (com.mochyy.mochymusic.utils.OfflineMode.isOn) throw com.music.innertube.OfflineModeException()

            Timber.tag("MusicService").i("FETCHING STREAM: $mediaId | quality=$audioQuality")
            val playbackData = runBlocking(Dispatchers.IO) {
                YTPlayerUtils.playerResponseForPlayback(
                    mediaId,
                    audioQuality = audioQuality,
                    connectivityManager = connectivityManager,
                    preferStudio = studioForVideos,
                )
            }.getOrElse { throwable ->
                if (throwable is PlaybackException && throwable.errorCode != PlaybackException.ERROR_CODE_REMOTE_ERROR) {
                    throw throwable
                }
                when (throwable) {
                    is CancellationException, is com.music.innertube.OfflineModeException -> throw throwable

                    is java.net.ConnectException, is java.net.UnknownHostException -> {
                        throw PlaybackException(
                            getString(R.string.error_no_internet),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                        )
                    }

                    is java.net.SocketTimeoutException -> {
                        throw PlaybackException(
                            getString(R.string.error_timeout),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                        )
                    }

                    else -> {
                        throw NoProviderException(
                            reason = friendlyReason(throwable),
                            retryable = throwable !is com.mochyy.mochymusic.utils.YouTubePremiumOnlyException &&
                                throwable !is com.mochyy.mochymusic.utils.YouTubeRateLimitedException &&
                                throwable !is com.mochyy.mochymusic.utils.YouTubeBotCheckException,
                            providerId = com.mochyy.mochymusic.modules.SourceModules.YouTubeId,
                            cause = throwable,
                        )
                    }
                }
            }

            val nonNullPlayback = requireNotNull(playbackData) {
                getString(R.string.error_unknown)
            }
            run {
                val format = nonNullPlayback.format
                // The database describes the bytes under the normal YouTube cache key.
                // Manual variants use their own cache key and expose their format at runtime.
                dropStaleCachedBytes(mediaId, format.itag, format.contentLength)
                database.query { upsert(youTubeFormat(mediaId, nonNullPlayback)) }
                if (bypassCacheForQualityChange.remove(mediaId)) {
                    Timber.tag("MusicService").d("Cleared bypass cache flag for $mediaId after fresh fetch")
                }

                val streamUrl = nonNullPlayback.streamUrl

                songUrlCache[mediaId] =
                    streamUrl to System.currentTimeMillis() + (nonNullPlayback.streamExpiresInSeconds * 1000L)
                songStreamHeaders[mediaId] = nonNullPlayback.streamHeaders
                noteYouTubePlayback(mediaId, nonNullPlayback)

                return@Factory dataSpec
                    .withUri(streamUrl.toUri())
                    .subrange(dataSpec.uriPositionOffset, CHUNK_LENGTH)
                    .withRequestHeaders(dataSpec.httpRequestHeaders + nonNullPlayback.streamHeaders)
            }
        }
    }

    private fun youTubeFormat(mediaId: String, playback: YTPlayerUtils.PlaybackData): FormatEntity {
        val format = playback.format
        return FormatEntity(
            id = mediaId,
            itag = format.itag,
            mimeType = format.mimeType.substringBefore(';'),
            codecs = format.mimeType.substringAfter("codecs=", "").trim('"'),
            bitrate = format.bitrate,
            sampleRate = format.audioSampleRate,
            contentLength = format.contentLength ?: 0L,
            loudnessDb = playback.audioConfig?.loudnessDb,
            perceptualLoudnessDb = playback.audioConfig?.perceptualLoudnessDb,
            playbackUrl = playback.playbackTracking?.videostatsPlaybackUrl?.baseUrl,
        )
    }

    private fun noteYouTubePlayback(mediaId: String, playback: YTPlayerUtils.PlaybackData) {
        playReporter.offerTracking(mediaId, playback.playbackTracking)
        scope.launch(Dispatchers.IO) { recoverSong(mediaId, playback) }

        if (playback.fromStudio) {
            Handler(Looper.getMainLooper()).post {
                if (player.currentMediaItem?.mediaId == mediaId) showBanner(getString(R.string.playing_studio_version))
            }
        }
        if (playback.fromMusicVideo) {
            musicVideoAudioSongs += mediaId
            // this runs ahead for the next song too, which hears about it when it starts
            scope.launch { if (player.currentMediaItem?.mediaId == mediaId) announceMusicVideoAudio(mediaId) }
        } else {
            musicVideoAudioSongs -= mediaId
        }
    }

    private fun announceMusicVideoAudio(mediaId: String) {
        // any other song in between means the next time this one starts it's said again
        if (mediaId !in musicVideoAudioSongs) {
            lastMusicVideoNoticeId = null
            return
        }
        if (lastMusicVideoNoticeId == mediaId) return
        lastMusicVideoNoticeId = mediaId
        showBanner(getString(R.string.playing_music_video_audio))
    }

    private fun announceStreamSource(mediaId: String) {

        if (!dataStore.get(ShowStreamSourceToastKey, false)) return
        if (lastAnnouncedSourceMediaId == mediaId) return
        // its decoder toast names the source too, once the stream's format is known
        if (decoderNotices.containsKey(mediaId)) return
        val source = resolvedStreamSources[mediaId] ?: return
        lastAnnouncedSourceMediaId = mediaId
        showBanner("Playing from $source")
    }

    /**
     * The app's top banner (the one "Added to playlist" uses), with the song's cover. Only while
     * Mochy is on screen: one raised in the background would greet the user later, for a song
     * that's long gone.
     */
    private fun showBanner(text: String) {
        val visible = androidx.lifecycle.ProcessLifecycleOwner.get().lifecycle.currentState
            .isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)
        if (!visible) return
        com.mochyy.mochymusic.ui.component.TopToaster.show(
            text = text,
            thumbnail = player.currentMediaItem?.mediaMetadata?.artworkUri?.toString(),
        )
    }

    /**
     * A song that failed from one provider starts again from another enabled source, where it
     * left off. A module's stream always gives way like this - a module this phone can't play (its
     * codec, its DRM, its server) used to leave the song retrying, then skipped, with YouTube never
     * asked. Force playback adds YouTube's own failures, which get YouTube's recoveries first (a
     * stale URL is refreshed, a cipher retried) and only come here once those are spent, via
     * [handleFinalFailure]. Without [announce] it says nothing: a decoder notice follows instead.
     */
    private fun forceFallBack(
        mediaId: String,
        includeYouTube: Boolean = false,
        announce: Boolean = true,
        stalledStream: CustomStreamResult? = null,
    ): Boolean {
        if (player.currentMediaItem?.mediaId != mediaId) return false
        val failed = resolvedSourceIds[mediaId] ?: return false
        if (failed == PlayingFrom.Device || failed == PlayingFrom.Downloads) return false
        if (failed == com.mochyy.mochymusic.modules.SourceModules.YouTubeId &&
            (!includeYouTube || !dataStore.get(ForcePlaybackKey, false))
        ) {
            return false
        }
        val recent = recentFailures(mediaId)
        val hasAlternate = sourceModules.order.value.any {
            it != failed && it !in recent && sourceModules.isUsable(it)
        }
        // Slowness alone shouldn't disqualify a stream when it is the only source left.
        if (stalledStream != null && (!hasAlternate || playingStreams[mediaId] !== stalledStream)) return false
        val skip = failedSources.getOrPut(mediaId) { java.util.concurrent.ConcurrentHashMap.newKeySet() }
        if (!skip.add(failed)) return false
        forcedRoutes[mediaId]?.takeIf { it.providerId == failed }?.let { forcedRoutes.remove(mediaId, it) }
        failedSourcesAt.putIfAbsent(mediaId, System.currentTimeMillis())
        if (!hasAlternate) return false
        Timber.tag(TAG).i("Playback: $mediaId stalled or failed from $failed, trying another provider")
        resolvedStreamSources.remove(mediaId)
        songUrlCache.remove(mediaId)
        val index = player.currentMediaItemIndex
        val position = player.currentPosition
        val wasPlaying = player.playWhenReady
        if (announce) showBanner(getString(R.string.pippo_provider_trying_another, sourceModules.nameOf(failed)))
        val previousStream = playingStreams[mediaId]
        if (stalledStream != null) {
            sourceModules.notePlaybackStall(failed)
            bufferingRecoveryJob = null
            playingStreams.remove(mediaId, stalledStream)
            resolvedSourceIds.remove(mediaId, failed)
        }
        player.stop()
        if (stalledStream == null) discardFailedRendition(previousStream?.cacheKey)
        player.seekTo(index, position)
        player.prepare()
        player.playWhenReady = wasPlaying
        return true
    }

    private val playbackLoadErrors = object : androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy() {
        override fun getRetryDelayMsFor(info: androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy.LoadErrorInfo): Long {
            // Playback owns the retry budget for lookup errors. Media3 still handles ordinary
            // HTTP reads and decoder input separately.
            if (generateSequence<Throwable>(info.exception) { it.cause }.any { it is NoProviderException }) {
                return C.TIME_UNSET
            }
            return super.getRetryDelayMsFor(info)
        }
    }

    private fun createMediaSourceFactory(): androidx.media3.exoplayer.source.MediaSource.Factory {
        val defaultFactory = DefaultMediaSourceFactory(
            createDataSourceFactory(),
            androidx.media3.extractor.DefaultExtractorsFactory(),
        )

        return object : androidx.media3.exoplayer.source.MediaSource.Factory by defaultFactory {
            override fun createMediaSource(mediaItem: androidx.media3.common.MediaItem): androidx.media3.exoplayer.source.MediaSource {
                return com.mochyy.mochymusic.playback.custom.DynamicResolvingMediaSource(
                    originalMediaItem = mediaItem,
                    mediaSourceFactoryProvider = { drmManager ->
                        val factory = DefaultMediaSourceFactory(
                            createDataSourceFactory(),
                            androidx.media3.extractor.DefaultExtractorsFactory(),
                        ).setLoadErrorHandlingPolicy(playbackLoadErrors)
                        if (drmManager != null) {
                            factory.setDrmSessionManagerProvider { drmManager }
                        }
                        factory
                    },
                    fetcherAction = { resolveQueueStream(mediaItem) },
                    onSourceResolved = { mediaId, source ->
                        if (handoffFor(mediaId) == null) {
                            resolvedStreamSources[mediaId] = source
                            Handler(Looper.getMainLooper()).post {
                                if (player.currentMediaItem?.mediaId == mediaId && handoffFor(mediaId) == null) {
                                    announceStreamSource(mediaId)
                                }
                            }
                        }
                    }
                )
            }
        }
    }

    private suspend fun resolveQueueStream(mediaItem: MediaItem): com.mochyy.mochymusic.playback.custom.CustomStreamResult? {
        val mediaId = mediaItem.mediaId
        while (true) {
            val handoff = handoffFor(mediaId)
            val saved = forcedRoutes[mediaId]
            val savedIsUsable = saved != null && sourceModules.isUsable(saved.providerId)
            if (saved != null && !savedIsUsable) forcedRoutes.remove(mediaId, saved)
            val forced = handoff != null || savedIsUsable
            val offline = com.mochyy.mochymusic.utils.OfflineMode.isOn
            val stream = (if (!forced || offline) deviceStream(mediaItem) else null) ?: routeStream(mediaItem)
            currentCoroutineContext().ensureActive()
            // A prepare may survive the change of queue occurrence. Resolve it again against
            // the current route instead of leaving its source without a timeline.
            if (handoffFor(mediaId) !== handoff) continue
            if (handoff != null) handoff.stream = stream
            else if (stream == null) playingStreams.remove(mediaId)
            else playingStreams[mediaId] = stream
            return stream
        }
    }

    private fun createRenderersFactory(
        eqProcessor: CustomEqualizerAudioProcessor,
        fxProcessors: Array<androidx.media3.common.audio.AudioProcessor>,
        silenceProcessor: SilenceDetectorAudioProcessor,
        hapticProcessor: HapticAudioProcessor,
        crossmixProcessor: CrossmixTransitionAudioProcessor,
        replayGain: com.mochyy.mochymusic.eq.audio.ReplayGainTags,
        spectrum: com.mochyy.mochymusic.playback.audio.AudioSpectrum,
        inspector: StreamInspector,
        platformOutput: PlatformOutputMonitor,
    ) =
        object : DefaultRenderersFactory(this) {
            // the renderer below tells it which file each song comes from, so it can tell a lossless song from a lossy one
            private var router: PassRouterSink? = null

            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ) = CrossmixClockSink(PassRouterSink(com.mochyy.mochymusic.playback.audio.PrecisionSink(DefaultAudioSink
                .Builder(this@MusicService)
                .setAudioTrackProvider { config, attributes, sessionId ->
                    // Configure the USB mixer for the track Media3 is actually opening, after
                    // the previous format has drained and its AudioTrack has been released.
                    if (androidx.media3.common.util.Util.isEncodingLinearPcm(config.encoding)) {
                        audioOutputs.prepareMixer(config.sampleRate, config.channelConfig, config.encoding)
                    }
                    DefaultAudioSink.AudioTrackProvider.DEFAULT.getAudioTrack(config, attributes, sessionId)
                        .also(platformOutput::attach)
                }
                // float is only ever let through by PrecisionSink, while nothing it would skip is on
                .setEnableFloatOutput(true)
                // speed and pitch go to the audio track: through sonic, every change drained and flushed every processor in front of it (equalizer, effects, crossmix), a cut in the sound each time and a crash when a slider was dragged
                .setEnableAudioTrackPlaybackParams(true)
                .setAudioProcessorChain(
                    DefaultAudioSink.DefaultAudioProcessorChain(

                        // Audio Lab first (equalizer, then spatial, reverb, loudness), so Crossmix
                        // blends the two songs as they're heard
                        arrayOf(
                            eqProcessor,
                            *fxProcessors,
                            silenceProcessor,
                            hapticProcessor,
                            crossmixProcessor,
                        ),
                        SilenceSkippingAudioProcessor(2_000_000, 20_000, 256),
                        SonicAudioProcessor(),
                    ),
                ).build(), audioOutputs, inspector), PassSink(audioPass), audioPass).also { router = it }, crossmixProcessor, audioFx, replayGain, spectrum)

            // media3's own audio renderer, built the same way, that hands the router each song's file format before its decoder starts
            override fun buildAudioRenderers(
                context: Context,
                extensionRendererMode: Int,
                mediaCodecSelector: MediaCodecSelector,
                enableDecoderFallback: Boolean,
                audioSink: AudioSink,
                eventHandler: Handler,
                eventListener: AudioRendererEventListener,
                out: ArrayList<Renderer>,
            ) {
                val songs = router
                out.add(object : MediaCodecAudioRenderer(
                    context, codecAdapterFactory, mediaCodecSelector, enableDecoderFallback, eventHandler, eventListener, audioSink,
                ) {
                    override fun onInputFormatChanged(formatHolder: FormatHolder): DecoderReuseEvaluation? {
                        songs?.sourceFormat = formatHolder.format
                        return super.onInputFormatChanged(formatHolder)
                    }

                    // the loop sleeps half the audio buffer, and speed on the audio track sizes that for 8x, so it slept a whole second and the position went that stale
                    override fun getDurationToProgressUs(positionUs: Long, elapsedRealtimeUs: Long, isOnBufferAvailableListenerRegistered: Boolean): Long =
                        minOf(super.getDurationToProgressUs(positionUs, elapsedRealtimeUs, isOnBufferAvailableListenerRegistered), PositionWakeUs)
                })
                // after the phone's own, so it only takes what the phone can't decode: alac on most phones, flac on old ones, 192 kHz masters
                out.add(object : FfmpegFallbackRenderer(eventHandler, eventListener, audioSink) {
                    override fun onSourceFormat(format: Format) {
                        songs?.sourceFormat = format
                    }

                    override fun getDurationToProgressUs(positionUs: Long, elapsedRealtimeUs: Long): Long =
                        minOf(super.getDurationToProgressUs(positionUs, elapsedRealtimeUs), PositionWakeUs)
                })
            }
        }.apply {
            // a phone's first-choice decoder failing to start (a vendor FLAC decoder on a 24-bit
            // file, say) moves on to its next one instead of failing the song
            setEnableDecoderFallback(true)
        }

    override fun onPlaybackStatsReady(
        eventTime: AnalyticsListener.EventTime,
        playbackStats: PlaybackStats,
    ) {
        val mediaItem = eventTime.timeline.getWindow(eventTime.windowIndex, Timeline.Window()).mediaItem
        val historyDurationMs = dataStore[HistoryDuration]?.times(1000f) ?: 30000f

        if (playbackStats.totalPlayTimeMs >= historyDurationMs &&
            !dataStore.get(PauseListenHistoryKey, false)
        ) {
            database.query {
                incrementTotalPlayTime(mediaItem.mediaId, playbackStats.totalPlayTimeMs)
                try {
                    insert(
                        Event(
                            songId = mediaItem.mediaId,
                            timestamp = LocalDateTime.now(),
                            playTime = playbackStats.totalPlayTimeMs,
                        ),
                    )
                } catch (_: SQLException) {
                }
            }
        }
    }

    private val queueSavePlaying = MutableStateFlow(false)
    private var queueEditSaveJob: Job? = null
    private var savedQueueKey: Int? = null
    private var savedQueueIndex = 0
    private var savedPosition = -1L

    override fun onTimelineChanged(timeline: Timeline, reason: Int) {
        if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) scheduleQueueEditSave()
    }

    private fun scheduleQueueEditSave() {
        if (destroying || !playerInitialized.value || !dataStore.get(PersistentQueueKey, true)) return
        queueEditSaveJob?.cancel()
        queueEditSaveJob = scope.launch {
            delay(250)
            if (dataStore.get(PersistentQueueKey, true)) saveQueueToDisk(onlyChanges = true)
        }
    }

    // a cheap fingerprint of everything in the queue and automix files: the songs, where in them we are, and how they play
    private fun queueKey(): Int {
        var key = java.util.Objects.hash(queueTitle, player.currentMediaItemIndex, player.shuffleModeEnabled, player.repeatMode, player.playWhenReady, playerVolume.value)
        for (i in 0 until player.mediaItemCount) {
            val item = player.getMediaItemAt(i)
            key = 31 * key + item.mediaId.hashCode()
            if (item.isManualQueued) key = 31 * key + 1
            if (item.isAutoplay) key = 31 * key + 2
        }
        automixItems.value.forEach { key = 31 * key + it.mediaId.hashCode() }
        return key
    }

    private fun saveQueueToDisk(onlyChanges: Boolean = false) {
        if (player.mediaItemCount == 0) {
            Timber.tag(TAG).d("Skipping queue save - no media items")
            return
        }
        val key = queueKey()
        val position = player.currentPosition
        val queueChanged = key != savedQueueKey
        if (onlyChanges && !queueChanged && kotlin.math.abs(position - savedPosition) < PositionSaveStepMs) return
        // a timed save with only the place moved writes the small player state, not the whole queue again
        val writeQueue = !onlyChanges || queueChanged
        savedQueueKey = key
        savedPosition = position

        try {
            // Refill unplayed Autoplay suggestions after restore using the current preference.
            // The saved format doesn't carry the Autoplay flag.
            val currentIndex = player.currentMediaItemIndex
            val savedItems = if (writeQueue) {
                var itemsBeforeCurrent = 0
                player.mediaItems.filterIndexed { index, item ->
                    val keep = (index <= currentIndex || !item.isAutoplay) && item.metadata != null
                    if (keep && index < currentIndex) itemsBeforeCurrent++
                    keep
                }.also { items ->
                    savedQueueIndex = itemsBeforeCurrent.coerceAtMost(items.lastIndex.coerceAtLeast(0))
                }
            } else null
            val resumePosition = if (player.currentMediaItem?.metadata == null) 0L else position
            val persistQueue = savedItems?.let { items ->
                currentQueue.toPersistQueue(
                    title = queueTitle,
                    items = items.mapNotNull { it.metadata },
                    mediaItemIndex = savedQueueIndex,
                    position = resumePosition,
                )
            }

            // which of those songs the user queued by hand: they keep their place ahead of the rest after a restart
            // (a separate file, so the saved queue's own format stays readable by older saves)
            val manualIndices = savedItems
                ?.mapIndexedNotNull { i, item -> if (item.isManualQueued) i else null }
                ?.toIntArray()

            val persistAutomix = if (writeQueue) {
                PersistQueue(
                    title = "automix",
                    items = automixItems.value.mapNotNull { it.metadata },
                    mediaItemIndex = 0,
                    position = 0,
                )
            } else null

            val persistPlayerState = PersistPlayerState(
                playWhenReady = player.playWhenReady,
                repeatMode = player.repeatMode,
                shuffleModeEnabled = player.shuffleModeEnabled,
                // the user's volume, not the player's live one: that's 0 while muted, a fifth while
                // ducked and anywhere at all mid-crossfade, and coming back to it next launch left
                // the app silent until the slider was touched
                volume = playerVolume.value,
                currentPosition = resumePosition,
                currentMediaItemIndex = savedQueueIndex,
                playbackState = player.playbackState
            )

            // Serialize snapshots in production order. Atomic writes preserve the last complete
            // file if Android kills the process mid-save, including during service destruction.
            queueFileWriter.execute {
                synchronized(queueFileLock) {
                    persistQueue?.let { writeQueueFile(PERSISTENT_QUEUE_FILE, it) }
                    manualIndices?.let { writeQueueFile(PERSISTENT_MANUAL_QUEUE_FILE, it) }
                    persistAutomix?.let { writeQueueFile(PERSISTENT_AUTOMIX_FILE, it) }
                    writeQueueFile(PERSISTENT_PLAYER_STATE_FILE, persistPlayerState)
                }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error during queue save operation")
            reportException(e)
        }
    }

    override fun onDestroy() {
        destroying = true
        isRunning = false
        providerHandoff = null
        providerSwitch.cancel()

        routeRefreshJob?.cancel()
        outputMonitorJob?.cancel()
        bufferingRecoveryJob?.cancel()
        moduleEndRecoveryJob?.cancel()
        retryJob?.cancel()
        clearStreamFailure()
        stopWidgetUpdates()
        widgetRenderJob?.cancel()
        audioManager.unregisterAudioDeviceCallback(audioDeviceCallback)
        audioOutputs.release()
        audioPass.release()
        castConnectionHandler?.release()
        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }
        discordPresence.update(null)
        // sends the last stretch of the song that was playing while the player can still say where it stopped
        playReporter.onSongStop()
        connectivityObserver.unregister()
        callWatcher.stop()
        abandonAudioFocus()
        releaseLoudnessEnhancer()
        transport.cancel()
        crossmixDirector.release()
        scope.cancel()
        // A plain crossfade can still own a second decoder when the service is stopped.
        listOfNotNull(secondaryPlayer, fadingPlayer).distinct().forEach { deck ->
            deck.removeListener(secondaryPlayerListener)
            unregisterEqualizer(deck)
            deck.release()
        }
        secondaryPlayer = null
        fadingPlayer = null
        fadingLoudnessEnhancer?.runCatching { release() }
        fadingLoudnessEnhancer = null
        carLyrics?.stop()
        carLyrics = null
        floatingLyrics?.stop()
        floatingLyrics = null
        mediaSession.release()
        player.removeListener(this)
        player.removeListener(sleepTimer)
        playerSilenceProcessors.remove(player)
        playerReplayGain.remove(player)
        unregisterEqualizer(player)

        player.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = super.onBind(intent) ?: binder

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (dataStore.get(StopPlaybackOnTaskRemovedKey, false)) {
            player.stop()
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    // every player the session is handed keeps the car's lyric wrapper, a crossfade's new player used to come without it and the lyrics left the car for good
    private fun sessionPlayer(base: ExoPlayer): CarLyricsPlayer =
        CarLyricsPlayer(TransportFadingPlayer(base, transport, audioPass)).also { carLyrics?.attach(it) }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            MusicWidgetReceiver.ACTION_PLAY_PAUSE -> {
                transport.togglePlayPause()
                updateWidgetUI()
            }
            MusicWidgetReceiver.ACTION_LIKE -> {
                toggleLike()
            }
            MusicWidgetReceiver.ACTION_NEXT -> {
                player.seekToNext()
                updateWidgetUI()
            }
            MusicWidgetReceiver.ACTION_PREVIOUS -> {
                player.seekToPrevious()
                updateWidgetUI()
            }
            MusicWidgetReceiver.ACTION_UPDATE_WIDGET -> {
                updateWidgetUI()
            }
        }

        return super.onStartCommand(intent, flags, startId)
    }

    private val powerManager by lazy { getSystemService(android.os.PowerManager::class.java) }

    private var widgetRenderJob: Job? = null

    private fun updateWidgetUI() {
        widgetRenderJob?.cancel()
        widgetRenderJob = scope.launch {
            renderWidgets(progressOnly = false)
            if (player.isPlaying) startWidgetUpdates()
        }
    }

    private suspend fun renderWidgets(progressOnly: Boolean) {
        try {
            val queued = player.currentMetadata
            val songData = currentSong.value?.takeIf { it.id == player.currentMediaItem?.mediaId }
            val song = songData?.song
            val songTitle = queued?.title ?: song?.title ?: getString(R.string.no_song_playing)
            val artistName = queued?.artists?.joinToString(", ") { it.name }
                ?: songData?.artists?.joinToString(", ") { it.name } ?: getString(R.string.tap_to_open)
            widgetManager.updateWidgets(
                title = songTitle,
                artist = artistName,
                artworkUri = queued?.thumbnailUrl ?: song?.thumbnailUrl,
                isPlaying = transport.playIntent.value ?:
                    (player.playWhenReady && player.playbackState != Player.STATE_ENDED),
                isLiked = song?.liked == true,
                duration = if (player.duration != C.TIME_UNSET) player.duration else 0,
                currentPosition = player.currentPosition,
                progressOnly = progressOnly,
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Widget update failed")
        }
    }

    private var widgetUpdateJob: Job? = null

    private fun startWidgetUpdates() {
        if (widgetUpdateJob?.isActive == true || !widgetManager.hasTickingWidgets) return
        widgetUpdateJob = scope.launch {
            while (isActive && widgetManager.hasTickingWidgets) {
                // nobody sees a widget with the screen off, and redrawing it every second there was all cost
                if (player.isPlaying && powerManager?.isInteractive != false && widgetRenderJob?.isActive != true) {
                    renderWidgets(progressOnly = true)
                }
                // the widget's progress bar moves in whole seconds anyway; more often only cost
                // frames in the app
                delay(WidgetProgressIntervalMs)
            }
            widgetUpdateJob = null
        }
    }

    private fun stopWidgetUpdates() {
        widgetUpdateJob?.cancel()
        widgetUpdateJob = null
    }

    private fun shareSong() {
        val songData = currentSong.value
        val songId = songData?.song?.id ?: return

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "https://music.youtube.com/watch?v=$songId")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(Intent.createChooser(shareIntent, null).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    suspend fun getStreamUrl(mediaId: String): String? {
        return withContext(Dispatchers.IO) {
            try {
                val playbackData = YTPlayerUtils.playerResponseForPlayback(
                    videoId = mediaId,
                    audioQuality = audioQuality,
                    connectivityManager = connectivityManager,
                ).getOrNull()
                playbackData?.streamUrl
            } catch (e: Exception) {
                timber.log.Timber.e(e, "Failed to get stream URL for Cast")
                null
            }
        }
    }

    /** a song's stream for a cast receiver: the link it fetches itself, and the kind of file behind it */
    data class CastStream(val url: String, val mimeType: String)

    // the receiver fetches the song itself, so it needs to be told what it is: an opus stream sent as mp4 won't play on most tvs
    suspend fun getCastStream(mediaId: String): CastStream? = withContext(Dispatchers.IO) {
        try {
            YTPlayerUtils.playerResponseForPlayback(
                videoId = mediaId,
                audioQuality = audioQuality,
                connectivityManager = connectivityManager,
            ).getOrNull()?.let { data ->
                CastStream(data.streamUrl, data.format.mimeType.substringBefore(';').trim().ifBlank { "audio/mp4" })
            }
        } catch (e: Exception) {
            timber.log.Timber.e(e, "Failed to get a stream for casting")
            null
        }
    }

    private fun initializeCast() {
        if (dataStore.get(com.mochyy.mochymusic.constants.EnableGoogleCastKey, true)) {
            try {
                castConnectionHandler = CastConnectionHandler(this, scope, this)
                castConnectionHandler?.initialize()
                timber.log.Timber.d("Google Cast initialized")
            } catch (e: Exception) {
                timber.log.Timber.e(e, "Failed to initialize Google Cast")
            }
        }
    }

    override fun onPositionDiscontinuity(
        oldPosition: Player.PositionInfo,
        newPosition: Player.PositionInfo,
        reason: Int
    ) {
        if (reason == Player.DISCONTINUITY_REASON_SEEK) {
            moduleEndWaiting = null
            crossmixDirector.onUserSeek()
            scheduleCrossfade()
        }
        // this comes before the song change itself, the last moment the old song's real end spot is known
        val sameSong = reason != Player.DISCONTINUITY_REASON_AUTO_TRANSITION &&
            oldPosition.mediaItemIndex == newPosition.mediaItemIndex
        playReporter.onJump(oldPosition.positionMs, newPosition.positionMs, sameSong)
    }

    private fun scheduleCrossfade() {
        // crossmix plans its own hand-overs, but not mid-blend: standing down then wiped the new song's effect, so it's asked again once the blend is over
        if (!isCrossfading) crossmixDirector.schedule()
        crossfadeTriggerJob?.cancel()
        crossfadeTriggerJob = null
        if (usesSingleExternalOutput || crossmixMode == CrossmixMode.CROSSMIX) return
        if (!crossfadeEnabled || player.duration == C.TIME_UNSET || player.duration <= crossfadeDuration) return
        if (crossfadeGapless && isNextItemGapless()) return
        // repeat one goes straight round on the same player; crossfaded into itself, the second time round played silent
        if (player.repeatMode == REPEAT_MODE_ONE || !player.hasNextMediaItem()) return

        val duration = player.duration
        val triggerTime = duration - crossfadeDuration.toLong()
        val delayMs = triggerTime - player.currentPosition
        if (delayMs <= 0) return

        val targetMediaId = player.currentMediaItem?.mediaId

        crossfadeTriggerJob = scope.launch {
            delay(delayMs)
            if (isActive && player.isPlaying && player.currentMediaItem?.mediaId == targetMediaId && !sleepTimer.pauseWhenSongEnd) {
                startCrossfade()
            }
        }
    }

    private fun isNextItemGapless(): Boolean {
        val current = player.currentMediaItem?.mediaMetadata ?: return false
        val nextIndex = player.nextMediaItemIndex
        if (nextIndex == C.INDEX_UNSET) return false
        val next = player.getMediaItemAt(nextIndex).mediaMetadata
        return current.albumTitle != null && current.albumTitle == next.albumTitle
    }

    /** the plain fixed-length crossfade (Auto and Manual): two equal-power volume ramps */
    private fun startCrossfade() {
        if (usesSingleExternalOutput || isCrossfading || crossmixDirector.isTransitioning) return
        val targetIndex = player.nextMediaItemIndex
        if (targetIndex == C.INDEX_UNSET) return
        crossfadeTo(targetIndex, crossfadeDuration.toLong())
    }

    // "blend skips" can cross over right now: it's on, a song is really playing, and nothing else is mixing or casting; crossmix still gets the song endings
    private fun canBlendSkip(): Boolean =
        skipBlend && !usesSingleExternalOutput && !isCrossfading && !crossmixDirector.isTransitioning &&
            castConnectionHandler?.isCasting?.value != true && player.isPlaying

    // the blend lasts as long as the fade's Length slider says, not a fixed second and a half
    private fun blendLengthMs(): Long = transport.lengthMs.toLong().coerceAtLeast(SkipBlendMinMs)

    // "blend skips": the song asked for starts on a second player and the two cross over on the press, through the layered effect when one is picked
    private fun blendSkip(previous: Boolean): Boolean {
        if (!canBlendSkip()) return false
        val target = when {
            // back a few seconds in starts the song over, which stays a plain jump
            previous && (player.currentPosition > BlendRestartAfterMs || !player.hasPreviousMediaItem()) -> return false
            previous -> player.previousMediaItemIndex
            !player.hasNextMediaItem() -> return false
            else -> player.nextMediaItemIndex
        }
        if (target == C.INDEX_UNSET) return false
        crossfadeTriggerJob?.cancel()
        crossfadeTo(target, blendLengthMs(), skipCurve = true)
        return true
    }

    // a song tapped in the queue or swiped back to blends in the same way; it may not be fetched ahead, so the old song plays on until it starts
    private fun blendJump(index: Int): Boolean {
        if (!canBlendSkip() || index == C.INDEX_UNSET || index >= player.mediaItemCount || index == player.currentMediaItemIndex) return false
        crossfadeTriggerJob?.cancel()
        crossfadeTo(index, blendLengthMs(), skipCurve = true)
        return true
    }

    // a song picked from a list: one the queue starts with crosses over at once, the rest of its queue loading in behind it
    private fun blendIntoQueue(queue: Queue): Boolean {
        if (!canBlendSkip()) return false
        crossfadeTriggerJob?.cancel()
        // read before the players swap, so the user's queue comes across in the order it was in
        val manual = upcomingManualItems()
        val first = queue.preloadItem
        if (first != null) {
            crossfadeInto(blendLengthMs(), skipCurve = true) { it.setMediaItems(listOf(first.toMediaItem()) + manual) }
        }
        startQueue(queue, playWhenReady = true, blend = true, manual = manual)
        return true
    }

    // with "blend skips" on, the songs either side get their first seconds fetched ahead, so a skip either way starts at once
    private fun prefetchNeighbours() {
        prefetchJob?.cancel()
        if (!skipBlend || player.mediaItemCount == 0 || !canFetchAhead()) return
        // data saver keeps it to the next one, the extra songs are only worth it on a connection that doesn't count
        val ahead = if (com.mochyy.mochymusic.utils.DataSaver.isActive(this)) 1 else blendAhead
        val upcoming = upcomingIndices(ahead)
        // the next one first, then back, then the rest coming up
        val ids = (upcoming.take(1) + player.previousMediaItemIndex + upcoming.drop(1))
            .filter { it != C.INDEX_UNSET && it < player.mediaItemCount }
            .map { player.getMediaItemAt(it).mediaId }
            .distinct()
        if (ids.isEmpty()) return
        prefetchJob = scope.launch(Dispatchers.IO) {
            // the playing song's own start gets the network first
            delay(PrefetchDelayMs)
            for (id in ids) {
                if (!isActive) break
                if (onThePhone(id)) continue
                runCatching { warmStart(id) }.onFailure { Timber.tag(TAG).d(it, "Couldn't fetch the start of $id ahead") }
            }
        }
    }

    // only songs youtube plays get their start fetched ahead: a source module's stream is found and cached its own way
    private fun canFetchAhead(): Boolean =
        !com.mochyy.mochymusic.utils.OfflineMode.isOn &&
            sourceModules.isUsable(com.mochyy.mochymusic.modules.SourceModules.YouTubeId) &&
            sourceModules.order.value.none { it != com.mochyy.mochymusic.modules.SourceModules.YouTubeId && sourceModules.isUsable(it) }

    // an imported file, a download or a song on the linked phone: it starts at once with nothing to fetch
    private fun onThePhone(mediaId: String): Boolean =
        mediaId.startsWith("LOCAL_") || isFullyDownloaded(mediaId) || com.mochyy.mochymusic.link.PhoneFiles.has(mediaId)

    // a picked song's stream found and its first seconds cached; the fetch runs on its own, so a pick that stops waiting still leaves it to the player
    private suspend fun warmPick(mediaId: String) {
        if (!canFetchAhead()) return
        scope.async(Dispatchers.IO) {
            if (!onThePhone(mediaId)) {
                runCatching { warmStart(mediaId) }.onFailure { Timber.tag(TAG).d(it, "Couldn't fetch the start of picked $mediaId") }
            }
        }.await()
    }

    // the next [count] songs in play order, shuffle included; repeat one counts as off here, the way the skip buttons see it
    private fun upcomingIndices(count: Int): List<Int> {
        val timeline = player.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val navigationRepeat = if (player.repeatMode == REPEAT_MODE_ONE) REPEAT_MODE_OFF else player.repeatMode
        val current = player.currentMediaItemIndex
        val found = ArrayList<Int>(count)
        var index = current
        while (found.size < count) {
            index = timeline.getNextWindowIndex(index, navigationRepeat, player.shuffleModeEnabled)
            if (index == C.INDEX_UNSET || index == current) break
            found += index
        }
        return found
    }

    // reads a song's first bytes through the player's own data source, which keeps them in the player's cache
    private fun warmStart(mediaId: String) {
        if (playerCache.isCached(mediaId, 0, PrefetchBytes)) return
        val source = createDataSourceFactory().createDataSource()
        try {
            source.open(
                androidx.media3.datasource.DataSpec.Builder()
                    .setUri(mediaId.toUri())
                    .setKey(mediaId)
                    .setLength(PrefetchBytes)
                    .build(),
            )
            val buffer = ByteArray(32 * 1024)
            var total = 0L
            while (total < PrefetchBytes) {
                val read = source.read(buffer, 0, buffer.size)
                if (read == C.RESULT_END_OF_INPUT) break
                total += read
            }
        } finally {
            source.close()
        }
    }

    // starts targetIndex on a second player and crosses the two over in durationMs; the end-of-song crossfade and blended skips both come through here
    private fun crossfadeTo(targetIndex: Int, durationMs: Long, skipCurve: Boolean = false) {
        val items = (0 until player.mediaItemCount).map { player.getMediaItemAt(it) }
        crossfadeInto(durationMs, skipCurve) { next ->
            next.setMediaItems(items)
            copyPlayOrder(from = player, to = next)
            next.seekTo(targetIndex, 0L)
        }
    }

    // starts a second player on whatever [load] gives it and crosses the two over in durationMs
    private fun crossfadeInto(durationMs: Long, skipCurve: Boolean, load: (ExoPlayer) -> Unit) {
        // a skip calls off what crossmix had lined up for the old song, its tempo ramp included, before the new one copies the speed
        if (skipCurve) crossmixDirector.onItemChanged()
        val savedRepeatMode = player.repeatMode
        val savedShuffleEnabled = player.shuffleModeEnabled

        secondaryPlayer = createExoPlayer(publish = false)
        val secPlayer = secondaryPlayer!!
        secPlayer.addListener(secondaryPlayerListener)

        load(secPlayer)
        secPlayer.playbackParameters = player.playbackParameters
        secPlayer.volume = 0f
        secPlayer.repeatMode = savedRepeatMode
        secPlayer.shuffleModeEnabled = savedShuffleEnabled
        // armed before it decodes a thing, so the new song's very first note already comes in through the effect
        val incomingFx = if (skipCurve) armBlend(secPlayer, CrossmixRole.Incoming, durationMs) else null
        secPlayer.prepare()
        secPlayer.playWhenReady = true

        performCrossfadeSwap(durationMs, skipCurve, incomingFx)
    }

    /**
     * Gives a player taking over the same shuffle order as the one handing over, so the queue the
     * user sees carries on as it was. Each crossfade used to reshuffle everything from the new
     * song, which brought songs that had already played back into the queue and changed what
     * "next song" showed after every song.
     */
    private fun copyPlayOrder(from: Player, to: ExoPlayer) {
        val timeline = from.currentTimeline
        if (timeline.isEmpty || timeline.windowCount != to.mediaItemCount) return
        val order = ArrayList<Int>(timeline.windowCount)
        var index = timeline.getFirstWindowIndex(true)
        while (index != C.INDEX_UNSET && order.size < timeline.windowCount) {
            order += index
            index = timeline.getNextWindowIndex(index, REPEAT_MODE_OFF, true)
        }
        if (order.size != timeline.windowCount) return
        to.setShuffleOrder(DefaultShuffleOrder(order.toIntArray(), System.currentTimeMillis()))
    }

    private fun performCrossfadeSwap(durationMs: Long, skipCurve: Boolean = false, incomingFx: CrossmixTransitionAudioProcessor? = null) {
        val nextPlayer = secondaryPlayer ?: return
        isCrossfading = true
        val currentPlayer = player

        fadingPlayer = currentPlayer
        player = nextPlayer
        _playerFlow.value = player
        queueSavePlaying.value = nextPlayer.isPlaying
        secondaryPlayer = null

        fadingPlayer?.removeListener(this)
        fadingPlayer?.removeListener(sleepTimer)
        // The old player has the whole queue too. If the new song took a moment to load, the fade
        // waited while the old one finished its song and rolled on into the next one - the same
        // song the new player was starting - so it played twice over itself.
        fadingPlayer?.pauseAtEndOfMediaItems = true

        nextPlayer.addListener(object : Player.Listener {
            // only the listener's own pause and play move both songs together: the new song stalling while it loads used to pause the old one too, a cut or a hitch right as the fade began
            private fun follow() {
                val out = fadingPlayer
                if (!isCrossfading || out == null) {
                    nextPlayer.removeListener(this)
                    return
                }
                if (!nextPlayer.playWhenReady) {
                    out.pause()
                    return
                }
                // an old song that has played out stays put
                val finished = out.playbackState == Player.STATE_ENDED ||
                    (out.duration > 0 && out.currentPosition >= out.duration - 250)
                if (!finished && !out.playWhenReady) out.play()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) = follow()

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = follow()
        })

        nextPlayer.removeListener(secondaryPlayerListener)
        nextPlayer.addListener(this)
        nextPlayer.addListener(sleepTimer)

        sleepTimer.player = player

        try {
            (mediaSession as MediaSession).player = sessionPlayer(player)
        } catch (e: Exception) {
            timber.log.Timber.e(e, "Failed to swap player in MediaSession")
        }

        crossfadeJob = scope.launch {
            // however it ends (finished, the new song never started, or called off) the old player goes and the flag comes down:
            // left up, Crossmix said "a plain crossfade is running" with nothing fading and never mixed again
            try {
                rampCrossfade(durationMs, skipCurve, incomingFx)
            } finally {
                // The effect must retire even when playback didn't start before the ramp timed out.
                incomingFx?.finish()
                if (!destroying) {
                    runCatching {
                        fadingPlayer?.volume = 0f
                        player.volume = targetVolume()
                    }
                    runCatching { cleanupCrossfade() }
                    isCrossfading = false
                    runCatching { scheduleCrossfade() }
                    watchPlatformOutput(player)
                }
            }
        }
    }

    // the two volume ramps of a crossfade, stepped every frame by the time the new song has really played; [incomingFx] is the new song's layered effect, armed before it started
    private suspend fun rampCrossfade(durationMs: Long, skipCurve: Boolean, incomingFx: CrossmixTransitionAudioProcessor?) {
        val startVolume = runCatching { fadingPlayer?.volume ?: 1f }.getOrDefault(1f)
        // the old song carries on as it was until the new one is really heard, so a slow start never leaves a gap;
        // a new song that never starts (a dead link, paused before its first sound) only gets so long
        val started = withTimeoutOrNull(CrossfadeStartWaitMs) {
            while (currentCoroutineContext().isActive && !player.isPlaying) delay(CrossfadeFrameMs)
            true
        }
        // still silent after the wait: the ramp below would sit at zero heard time forever, so the cleanup takes over now
        if (started == null) return
        // the new song in a format the renderer can't mix plays by untouched, so its volume brings it in instead
        val inFx = incomingFx?.takeIf { it.canRender && !it.idle }
        if (inFx == null) incomingFx?.clear()
        // the old song's effect starts the moment the new one is heard, so both sides move on one clock for the whole length
        val outFx = fadingPlayer?.takeIf { skipCurve }?.let { armBlend(it, CrossmixRole.Outgoing, durationMs) }
        // stepped every frame by the time actually played: twenty fixed steps were heard as the volume jumping.
        // Timed by the new song's own position, which is what's really coming out of the speaker: the wall
        // clock started as soon as isPlaying flipped, while the audio track was still filling, so the new
        // song came in further up the ramp than the timer said
        var heardMs = 0L
        var lastClock = android.os.SystemClock.elapsedRealtime()
        var lastPosition = player.currentPosition
        while (currentCoroutineContext().isActive && heardMs < durationMs) {
            delay(CrossfadeFrameMs)
            val now = android.os.SystemClock.elapsedRealtime()
            val position = player.currentPosition
            val wallMs = now - lastClock
            val movedMs = position - lastPosition
            val speed = player.playbackParameters.speed.takeIf { it > 0f } ?: 1f
            heardMs += when {
                // the ordinary case: as far as the song really got, at the speed it plays at
                movedMs in 0..(wallMs * 4 + 250) -> (movedMs / speed).toLong()
                // a seek or another song picked mid-fade: the clock carries it on; a pause holds both songs where they are
                player.isPlaying -> wallMs
                else -> 0L
            }
            lastClock = now
            lastPosition = position
            val progress = (heardMs.toFloat() / durationMs).coerceIn(0f, 1f)
            val angle = progress * Math.PI / 2.0
            // a skip's own effect does the fading on its side; without one a skip eases on equal-gain s-curves, the end-of-song crossfade on equal-power ramps
            val inGain = when {
                inFx != null -> 1.0
                skipCurve -> kotlin.math.sin(angle).let { it * it }
                else -> kotlin.math.sin(angle)
            }
            val outGain = when {
                // held so the effect is heard, then the volume takes its last echoes away
                outFx != null -> tailFade(progress).toDouble()
                skipCurve -> kotlin.math.cos(angle).let { it * it }
                else -> kotlin.math.cos(angle)
            }
            try {
                // the new song fades up to the volume it should be at now: started from the old
                // one's, a fade begun while muted or ducked ended at 0 or a fifth, and stayed
                player.volume = targetVolume() * inGain.toFloat()
                fadingPlayer?.volume = startVolume * outGain.toFloat()
            } catch (e: Exception) {
                break
            }
        }
    }

    // one side of a blended skip's layered effect; null with no effect picked or a renderer that can't mix this song
    private fun armBlend(player: ExoPlayer, role: CrossmixRole, durationMs: Long): CrossmixTransitionAudioProcessor? {
        val processor = playerCrossmixProcessors[player] ?: return null
        // the old song's renderer is set up already; the new one's only once it starts, so all it can say yet is a format it turned down
        val ready = if (role == CrossmixRole.Outgoing) processor.canRender else !processor.unsupported
        if (!ready) return null
        val calibrationNanos = if (player.isPlaying) System.nanoTime() else 0L
        val script = transport.blendScript(player, role, durationMs.toFloat(), calibrationNanos) ?: return null
        processor.arm(script)
        return processor
    }

    private fun cleanupCrossfade() {
        fadingPlayer?.stop()
        fadingPlayer?.clearMediaItems()
        fadingPlayer?.release()
        fadingPlayer?.let(playerCrossmixProcessors::remove)
        fadingPlayer?.let(playerSilenceProcessors::remove)
        fadingPlayer?.let(::unregisterEqualizer)
        fadingPlayer = null
        fadingLoudnessEnhancer?.runCatching { release() }
        fadingLoudnessEnhancer = null
        isCrossfading = false
        sleepTimer.notifySongTransition()
        prefetchNeighbours()
    }

    private fun unregisterEqualizer(player: Player) {
        playerEqProcessors.remove(player)?.let { equalizerService.removeAudioProcessor(it) }
    }

    /**
     * The decoder's format for [mediaId]. A module's own codec name stands (it knows its encode
     * better than the container says: HE-AAC reads as plain AAC there); otherwise the decoder's
     * format is the whole story, YouTube's record filling in what it leaves out.
     */
    private fun recordDecodedFormat(mediaId: String, format: androidx.media3.common.Format) {
        streamFacts.update { all ->
            val facts = playbackFacts(all[mediaId], format)
            if (facts == all[mediaId]) all else all + (mediaId to facts)
        }
    }

    private fun playbackFacts(old: StreamFacts?, format: androidx.media3.common.Format): StreamFacts {
        val codec = StreamFacts.codecOf(format.sampleMimeType, format.codecs)
        val sampleRate = format.sampleRate.takeIf { it > 0 }
        val merged = if (old?.fromModule == true) {
            old.copy(codec = old.codec ?: codec, sampleRate = sampleRate ?: old.sampleRate)
        } else StreamFacts(codec = codec, sampleRate = sampleRate)
        // HE-AAC's container can give its core's rate; the decoder plays it at twice that.
        return if (merged.codec == "HE-AAC" && (merged.sampleRate ?: 0) in 1..24_000) {
            merged.copy(sampleRate = merged.sampleRate!! * 2)
        } else merged
    }

    /** [mediaId] goes to YouTube: whatever a module said about it last time no longer holds */
    private fun forgetModuleFacts(mediaId: String) {
        streamFacts.update { all -> if (all[mediaId]?.fromModule == true) all - mediaId else all }
    }

    /**
     * The providers that failed on [mediaId] lately. They're forgotten after [FailedSourceMemoryMs]:
     * remembered for good, one slow answer from Monochrome sent the song to YouTube every time
     * after, until the app was closed.
     */
    private fun recentFailures(mediaId: String): Set<String> {
        val at = failedSourcesAt[mediaId]
        if (at != null && System.currentTimeMillis() - at > FailedSourceMemoryMs) {
            failedSources.remove(mediaId)
            failedSourcesAt.remove(mediaId)
        }
        return failedSources[mediaId].orEmpty()
    }

    /**
     * The song's own file, or its download, when it has one - so it never goes looking for a copy
     * online. Every song used to be routed through the source modules, which find songs by title
     * and artist: with a module ahead of YouTube in the order, an imported file or a downloaded
     * song played that module's online stream instead, and otherwise it was announced as playing
     * from YouTube Music.
     */
    private suspend fun deviceStream(mediaItem: androidx.media3.common.MediaItem): com.mochyy.mochymusic.playback.custom.CustomStreamResult? {
        val mediaId = mediaItem.mediaId
        val uri = mediaItem.localConfiguration?.uri
        val file = when {
            uri?.scheme == "content" || uri?.scheme == "file" -> uri.toString()
            // an imported file queued from somewhere that only had its id - a search result, a
            // pinned tile, a radio - would otherwise be looked up on YouTube by that id
            mediaId.startsWith("LOCAL_") -> database.song(mediaId).first()?.song?.localUri
            else -> null
        }
        if (file != null) {
            resolvedSourceIds[mediaId] = PlayingFrom.Device
            forgetModuleFacts(mediaId)
            notePlayingFrom(mediaId, PlayingFrom(PlayingFrom.Device, "This device"))
            // announced as "Playing from this device"
            return com.mochyy.mochymusic.playback.custom.CustomStreamResult(streamUrl = file, source = "this device")
        }
        if (isFullyDownloaded(mediaId)) {
            resolvedSourceIds[mediaId] = PlayingFrom.Downloads
            forgetModuleFacts(mediaId)
            notePlayingFrom(mediaId, PlayingFrom(PlayingFrom.Downloads, "Your downloads"))
            // the same item: the data source finds the download under its media id
            return com.mochyy.mochymusic.playback.custom.CustomStreamResult(
                streamUrl = uri?.toString() ?: mediaId,
                source = "your downloads",
            )
        }
        // on a tv, the linked phone's downloads and song files stream from the phone over the wi-fi
        com.mochyy.mochymusic.link.PhoneFiles.streamUrl(mediaId)?.let { url ->
            resolvedSourceIds[mediaId] = PlayingFrom.Device
            forgetModuleFacts(mediaId)
            notePlayingFrom(mediaId, PlayingFrom(PlayingFrom.Device, "Your phone"))
            return com.mochyy.mochymusic.playback.custom.CustomStreamResult(
                streamUrl = url,
                source = "your phone",
                cacheKey = com.mochyy.mochymusic.link.PhoneFiles.cacheKeyOf(mediaId),
            )
        }
        return null
    }

    private suspend fun routeStream(mediaItem: MediaItem): com.mochyy.mochymusic.playback.custom.CustomStreamResult? {
        val mediaId = mediaItem.mediaId
        // offline: no provider is asked; the song plays if it's cached, and is skipped if not.
        // An imported file is never looked for online, even one whose file has gone missing.
        if (com.mochyy.mochymusic.utils.OfflineMode.isOn || mediaId.startsWith("LOCAL_")) return null
        val youtubeId = com.mochyy.mochymusic.modules.SourceModules.YouTubeId
        var failedOverride: String? = null
        while (true) {
            val handoff = handoffFor(mediaId)
            val forced = handoff?.route ?: forcedRoutes[mediaId] ?: break
            val stream = if (forced.providerId == youtubeId) {
                forcedYouTubeStream(mediaId, forced)
            } else {
                forcedModuleStream(mediaItem, forced)
            }
            currentCoroutineContext().ensureActive()
            if (!isCurrentForcedRoute(mediaId, forced)) continue
            if (stream != null) return stream
            if (handoff != null) {
                throw java.io.IOException("The selected provider could not open this recording")
            }
            if (forcedRoutes.remove(mediaId, forced)) {
                // A failed YouTube quality override can fall back to normal YouTube.
                // Other modules would get the same lookup twice on this prepare.
                failedOverride = forced.providerId.takeUnless { it == youtubeId }
                break
            }
        }
        val skip = recentFailures(mediaId) + listOfNotNull(failedOverride)
        // a fresh lookup: a notice from one that never got to play no longer holds
        if (skip.isEmpty()) decoderNotices.remove(mediaId)
        // With no eligible modules there is nothing to look up by title and artist.
        val eligibleModules = sourceModules.order.value.any { it != youtubeId && it !in skip && sourceModules.isUsable(it) }
        if (!eligibleModules && youtubeId !in skip && sourceModules.isUsable(youtubeId)) return youTubeRoute(mediaId)
        val track = trackQueryOf(mediaId, mediaItem.metadata)
        val route = sourceModules.route(track, skip) { id, passed ->
            if (!decoderNotices.containsKey(mediaId)) noteMissingDecoder(mediaId, passed.codec?.uppercase(), passed.sampleRateHz, from = id)
        }
        if (com.mochyy.mochymusic.utils.OfflineMode.isOn) return null
        return when (route) {
            is com.mochyy.mochymusic.modules.SourceModules.Route.Module -> moduleStream(mediaId, route.module, route.stream, route.selectedQuality)
            com.mochyy.mochymusic.modules.SourceModules.Route.YouTube -> youTubeRoute(mediaId)
            is com.mochyy.mochymusic.modules.SourceModules.Route.Exhausted -> {
                if (youtubeId !in skip && sourceModules.isUsable(youtubeId)) return youTubeRoute(mediaId)
                val retryable = route.temporaryFailure || skip.any(sourceModules::isUsable)
                val reason = when {
                    route.temporaryFailure -> getString(R.string.pippo_provider_temporarily_unavailable)
                    !sourceModules.isEnabled(youtubeId) -> "none of your providers have it, and YouTube Music is off"
                    else -> "every provider failed on it"
                }
                throw NoProviderException(reason, retryable)
            }
        }
    }

    private fun isCurrentForcedRoute(mediaId: String, route: ForcedRoute): Boolean =
        (handoffFor(mediaId)?.route ?: forcedRoutes[mediaId]) === route

    /** null hands the song to YouTube, which is all YouTube needs */
    private fun youTubeRoute(mediaId: String): com.mochyy.mochymusic.playback.custom.CustomStreamResult? {
        val youTube = com.mochyy.mochymusic.modules.SourceModules.YouTubeId
        resolvedSourceIds[mediaId] = youTube
        forgetModuleFacts(mediaId)
        notePlayingFrom(mediaId, PlayingFrom(youTube, "YouTube Music"))
        return null
    }

    private fun moduleStream(
        mediaId: String,
        module: com.mochyy.mochymusic.module.SourceModule,
        stream: com.mochyy.mochymusic.module.SourceStream,
        selectedQuality: String?,
        forced: ForcedRoute? = null,
    ): com.mochyy.mochymusic.playback.custom.CustomStreamResult {
        val handoff = handoffFor(mediaId)
        val publish = handoff == null && forced?.isPreflight != true
        if (publish) {
            resolvedSourceIds[mediaId] = module.info.id
            // Save the catalog row so module plays can reach history.
            scope.launch(Dispatchers.IO) { recoverSong(mediaId) }
        }
        val cacheKey = rememberRendition(
            mediaId, module.info.id, stream.headers,
            stream.matched.id, stream.format.name, stream.codec, stream.sampleRateHz?.toString(),
            stream.qualityLabel, selectedQuality,
            stream.url.toUri().host,
        )
        val facts = StreamFacts(codec = stream.codec, sampleRate = stream.sampleRateHz, fromModule = true)
        if (publish) streamFacts.update { it + (mediaId to facts) }
        else if (handoff != null && handoff.route === forced) handoff.facts = facts
        notePlayingFrom(mediaId, PlayingFrom(module.info.id, module.info.name, stream.qualityLabel, stream.matched.id, selectedQuality), forced)
        Timber.tag("StreamFetch").i("$mediaId plays from ${module.info.name}: ${stream.matched.title} · ${stream.qualityLabel}")
        return com.mochyy.mochymusic.playback.custom.CustomStreamResult(
            streamUrl = stream.url,
            isHls = stream.format == com.mochyy.mochymusic.module.StreamFormat.Hls,
            isDash = stream.format == com.mochyy.mochymusic.module.StreamFormat.Dash,
            source = "${module.info.name} · ${stream.qualityLabel}",
            widevineLicense = (stream.drm as? com.mochyy.mochymusic.module.StreamDrm.Widevine)?.license,
            cacheKey = cacheKey,
        )
    }

    private fun rememberRendition(
        mediaId: String,
        providerId: String,
        headers: Map<String, String>,
        vararg rendition: String?,
    ): String {
        // URLs can expire and carry credentials. Key by recording and the available format
        // information instead, and keep the media id at the end for targeted eviction.
        val identity = (listOf(providerId) + rendition).joinToString("") {
            if (it == null) "-1:" else "${it.length}:$it"
        }
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(identity.encodeToByteArray())
        val key = "$ModuleCacheKeyPrefix${android.util.Base64.encodeToString(digest, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)}|$mediaId"
        moduleStreamHeaders[key] = headers
        return key
    }

    private fun notePlayingFrom(mediaId: String, from: PlayingFrom, route: ForcedRoute? = null) {
        val handoff = handoffFor(mediaId)
        if (handoff != null && handoff.route === route) {
            handoff.resolvedFrom = from
        } else if (handoff == null && route?.isPreflight != true) {
            publishPlayingFrom(mediaId, from)
        }
    }

    private fun publishPlayingFrom(mediaId: String, from: PlayingFrom) {
        _playingFrom.update { if (it[mediaId] == from) it else it + (mediaId to from) }
    }

    /** Use the queue entry the source actually opens, just as a module diagnostic uses its selected result. */
    private suspend fun trackQueryOf(
        mediaId: String,
        queued: com.mochyy.mochymusic.models.MediaMetadata?,
    ): com.mochyy.mochymusic.module.TrackQuery? {
        if (queued != null && queued.title.isNotBlank() && queued.artists.isNotEmpty()) {
            return com.mochyy.mochymusic.module.TrackQuery(
                title = queued.title,
                artists = queued.artists.map { it.name },
                album = queued.album?.title,
                durationMs = queued.duration.takeIf { it > 0 }?.times(1000L),
            )
        }
        val saved = database.song(mediaId).first()
        val title = queued?.title?.takeIf { it.isNotBlank() }
            ?: saved?.song?.title?.takeIf { it.isNotBlank() }
            ?: return null
        return com.mochyy.mochymusic.module.TrackQuery(
            title = title,
            artists = queued?.artists.orEmpty().map { it.name }.ifEmpty { saved?.artists.orEmpty().map { it.name } },
            album = queued?.album?.title ?: saved?.song?.albumName ?: saved?.album?.title,
            durationMs = (queued?.duration?.takeIf { it > 0 } ?: saved?.song?.duration?.takeIf { it > 0 })?.times(1000L),
        )
    }

    /** one ask of [module] for the song, passing over a stream this phone has no decoder for */
    private suspend fun resolveModuleRoute(
        module: com.mochyy.mochymusic.module.SourceModule,
        mediaItem: MediaItem,
        option: Pair<String, String>?,
    ): ProviderSwitch.Resolution {
        val track = trackQueryOf(mediaItem.mediaId, mediaItem.metadata) ?: return ProviderSwitch.Resolution.Rejected()
        return when (val result = sourceModules.lookupForPlayback(module, track, option)) {
            is PlaybackLookup.Found -> ProviderSwitch.Resolution.Found(
                ForcedRoute(
                    module.info.id, result.stream, option, expectedDurationMs = track.durationMs,
                    selectedModuleQuality = result.quality,
                )
            )
            PlaybackLookup.WrongRecording -> ProviderSwitch.Resolution.Rejected(getString(R.string.pc_force_wrong_recording))
            PlaybackLookup.UnsupportedAudio -> ProviderSwitch.Resolution.Rejected(getString(R.string.pc_force_unsupported_audio))
            is PlaybackLookup.NotFound -> ProviderSwitch.Resolution.Rejected(result.reason)
            is PlaybackLookup.Unavailable -> {
                if (sourceModules.isUsable(module.info.id)) ProviderSwitch.Resolution.Retry
                else ProviderSwitch.Resolution.Rejected(result.reason)
            }
        }
    }

    private suspend fun forcedModuleStream(mediaItem: MediaItem, forced: ForcedRoute): com.mochyy.mochymusic.playback.custom.CustomStreamResult? {
        val mediaId = mediaItem.mediaId
        val module = sourceModules.module(forced.providerId) ?: return null
        val resolved = if (forced.freshStream != null) forced else reopenModuleRoute(module, mediaItem, forced.option)
        currentCoroutineContext().ensureActive()
        if (!isCurrentForcedRoute(mediaId, forced)) return null
        if (resolved == null) return null
        val stream = resolved.freshStream ?: return null
        return moduleStream(mediaId, module, stream, resolved.selectedModuleQuality, forced)
    }

    private suspend fun reopenModuleRoute(
        module: com.mochyy.mochymusic.module.SourceModule,
        mediaItem: MediaItem,
        option: Pair<String, String>?,
    ): ForcedRoute? {
        // Wait separately so a provider that blocks after cancellation cannot stall the queue.
        val lookup = scope.async(Dispatchers.IO) {
            try {
                (resolveModuleRoute(module, mediaItem, option) as? ProviderSwitch.Resolution.Found)?.route
            } catch (e: Exception) {
                currentCoroutineContext().ensureActive()
                Timber.tag(TAG).w(e, "Previously selected provider could not reopen the stream")
                null
            }
        }
        return try {
            withTimeoutOrNull(12_000L) { lookup.await() }
        } catch (_: CancellationException) {
            currentCoroutineContext().ensureActive()
            null
        } finally {
            lookup.cancel()
        }
    }

    private suspend fun forcedYouTubeStream(mediaId: String, forced: ForcedRoute): com.mochyy.mochymusic.playback.custom.CustomStreamResult? {
        val playback = forced.freshYouTube
            ?: YTPlayerUtils.playerResponseForPlayback(
                mediaId, audioQuality = forced.youtubeQuality ?: audioQuality,
                connectivityManager = connectivityManager, preferStudio = studioForVideos,
            ).getOrNull()
        currentCoroutineContext().ensureActive()
        if (playback == null || !isCurrentForcedRoute(mediaId, forced)) return null
        val format = playback.format
        val cacheKey = rememberRendition(
            mediaId, forced.providerId, playback.streamHeaders,
            format.itag.toString(), format.mimeType, format.contentLength?.toString(),
            format.lastModified?.toString(), playback.videoDetails?.videoId,
        )
        val handoff = handoffFor(mediaId)
        if (handoff == null && !forced.isPreflight) {
            resolvedSourceIds[mediaId] = forced.providerId
            forgetModuleFacts(mediaId)
            noteYouTubePlayback(mediaId, playback)
        } else if (handoff != null && handoff.route === forced) {
            handoff.youtube = playback
        }
        notePlayingFrom(
            mediaId,
            PlayingFrom(
                providerId = forced.providerId,
                name = sourceModules.nameOf(forced.providerId),
                selectedOption = forced.option?.second,
                manualYouTubeFormat = youTubeFormat(mediaId, playback),
            ),
            forced,
        )
        return com.mochyy.mochymusic.playback.custom.CustomStreamResult(
            streamUrl = playback.streamUrl, cacheKey = cacheKey, source = sourceModules.nameOf(forced.providerId),
        )
    }

    private inner class ProviderSwitchHost : ProviderSwitch.Host {
        override fun currentTarget(): ProviderSwitch.Target? {
            if (!playerInitialized.value || castConnectionHandler?.isCasting?.value == true) return null
            val item = player.currentMediaItem ?: return null
            if (item.mediaId.startsWith("LOCAL_") || item.localConfiguration?.uri?.scheme == "content" ||
                item.localConfiguration?.uri?.scheme == "file") return null
            return ProviderSwitch.Target(item.mediaId, providerOccurrence)
        }

        override suspend fun resolve(
            target: ProviderSwitch.Target,
            providerId: String,
            option: Pair<String, String>?,
        ): ProviderSwitch.Resolution {
            if (com.mochyy.mochymusic.utils.OfflineMode.isOn || !sourceModules.isUsable(providerId)) {
                return ProviderSwitch.Resolution.Rejected()
            }
            if (providerId == com.mochyy.mochymusic.modules.SourceModules.YouTubeId) {
                val tier = option?.second?.let { wanted -> AudioQuality.entries.firstOrNull { it.name == wanted } }
                val playback = YTPlayerUtils.playerResponseForPlayback(
                    target.mediaId, audioQuality = tier ?: audioQuality,
                    connectivityManager = connectivityManager, preferStudio = studioForVideos,
                ).getOrElse { error ->
                    if (error is CancellationException) throw error
                    if (error is com.mochyy.mochymusic.utils.YouTubePremiumOnlyException) {
                        return ProviderSwitch.Resolution.Rejected(friendlyReason(error))
                    }
                    return ProviderSwitch.Resolution.Retry
                }
                return ProviderSwitch.Resolution.Found(ForcedRoute(providerId, option = option, youtubeQuality = tier, freshYouTube = playback))
            }
            val module = sourceModules.module(providerId) ?: return ProviderSwitch.Resolution.Rejected()
            val mediaItem = withContext(Dispatchers.Main) {
                player.currentMediaItem?.takeIf { currentTarget() == target }
            } ?: return ProviderSwitch.Resolution.Rejected()
            return resolveModuleRoute(module, mediaItem, option)
        }

        override suspend fun switchTo(target: ProviderSwitch.Target, route: ForcedRoute): ProviderSwitch.HandoffResult {
            val transitionFinished = withTimeoutOrNull(5_000L) {
                while (currentTarget() == target && (isCrossfading || crossmixDirector.isTransitioning)) delay(100L)
                true
            } == true
            if (!transitionFinished) return ProviderSwitch.HandoffResult.Failed(getString(R.string.pc_force_transition_busy))
            if (currentTarget() != target || com.mochyy.mochymusic.utils.OfflineMode.isOn ||
                !sourceModules.isUsable(route.providerId)
            ) return ProviderSwitch.HandoffResult.Failed()
            val mediaId = target.mediaId
            val position = player.currentPosition
            val handoff = ProviderHandoff(target, route)
            providerHandoff = handoff
            var success = false
            try {
                val latestSafePosition = route.freshStream?.matched?.durationMs?.takeIf { it > 1_000 }
                    ?.minus(1_000)?.let { position.coerceAtMost(it) } ?: position
                reload(target, latestSafePosition)
                val outcome = withTimeoutOrNull(20_000L) { handoff.ready.await() }
                    ?: ProviderSwitch.HandoffResult.Failed(getString(R.string.pc_force_open_timeout))
                success = outcome == ProviderSwitch.HandoffResult.Ready && currentTarget() == target &&
                    player.playerError == null && sourceModules.isUsable(route.providerId) &&
                    !com.mochyy.mochymusic.utils.OfflineMode.isOn
                if (success) {
                    forcedRoutes[mediaId] = route.copy(freshStream = null, freshYouTube = null)
                    resolvedSourceIds[mediaId] = route.providerId
                    handoff.stream?.let {
                        playingStreams[mediaId] = it
                        it.source?.let { source -> resolvedStreamSources[mediaId] = source }
                    }
                    val facts = handoff.facts
                    streamFacts.update { if (facts == null) it - mediaId else it + (mediaId to facts) }
                    handoff.resolvedFrom?.let { publishPlayingFrom(mediaId, it) }
                    val youtube = handoff.youtube
                    if (youtube == null) scope.launch(Dispatchers.IO) { recoverSong(mediaId) }
                    else noteYouTubePlayback(mediaId, youtube)
                    announceStreamSource(mediaId)
                    setupLoudnessEnhancer()
                    failedSources.remove(mediaId)
                    failedSourcesAt.remove(mediaId)
                }
                return if (success || outcome is ProviderSwitch.HandoffResult.Failed) outcome
                else ProviderSwitch.HandoffResult.Failed()
            } finally {
                if (providerHandoff === handoff) {
                    providerHandoff = null
                    if (!success && currentTarget() == target) {
                        runCatching { reload(target, position) }
                            .onFailure { Timber.tag(TAG).w(it, "Previous provider could not be restored") }
                    }
                }
            }
        }

        private fun reload(target: ProviderSwitch.Target, position: Long) {
            // Reopen the same queue entry. Leave playWhenReady alone so pause/play still responds
            // during the fetch and handoff.
            if (currentTarget() != target) return
            val activePlayer = player
            val index = activePlayer.currentMediaItemIndex
            if (index !in 0 until activePlayer.mediaItemCount) return
            activePlayer.stop()
            activePlayer.seekTo(index, position)
            activePlayer.prepare()
        }
    }

    /**
     * The next song in play order (shuffle and repeat-all included) that plays without a
     * connection, or [C.INDEX_UNSET] when none does.
     */
    private fun nextOfflineIndex(): Int {
        val timeline = player.currentTimeline
        if (timeline.isEmpty) return C.INDEX_UNSET
        // repeat-one would only ever give back the song that just failed
        val repeatMode = if (player.repeatMode == REPEAT_MODE_ONE) REPEAT_MODE_OFF else player.repeatMode
        var index = player.currentMediaItemIndex
        repeat(timeline.windowCount) {
            index = timeline.getNextWindowIndex(index, repeatMode, player.shuffleModeEnabled)
            if (index == C.INDEX_UNSET || index == player.currentMediaItemIndex) return C.INDEX_UNSET
            if (playsOffline(player.getMediaItemAt(index))) return index
        }
        return C.INDEX_UNSET
    }

    // starts the song at [index] from the top, and plays it unless a cast is doing the playing
    private fun playOfflineSong(index: Int) {
        player.seekTo(index, C.TIME_UNSET)
        player.prepare()
        if (castConnectionHandler?.isCasting?.value != true) player.play()
    }

    /** An imported file, a download, or a song the player has cached whole. */
    private fun playsOffline(item: androidx.media3.common.MediaItem): Boolean {
        val scheme = item.localConfiguration?.uri?.scheme
        return scheme == "content" || scheme == "file" || item.mediaId.startsWith("LOCAL_") ||
            isFullyDownloaded(item.mediaId) || isFullyCached(item.mediaId)
    }

    /** every byte of the song is in the player's own cache, from having played it */
    private fun isFullyCached(mediaId: String): Boolean = runCatching {
        val length = androidx.media3.datasource.cache.ContentMetadata.getContentLength(
            playerCache.getContentMetadata(mediaId)
        )
        length > 0 && playerCache.isCached(mediaId, 0, length)
    }.getOrDefault(false)

    /** every byte of the song is in the download cache */
    private fun isFullyDownloaded(mediaId: String): Boolean = runCatching {
        val length = androidx.media3.datasource.cache.ContentMetadata.getContentLength(
            downloadCache.getContentMetadata(mediaId)
        )
        length > 0 && downloadCache.isCached(mediaId, 0, length)
    }.getOrDefault(false)

    // what the pause, play and skip fades need from the service
    private inner class TransportHost : TransportTransitions.Host {
        override val player: ExoPlayer get() = this@MusicService.player

        override fun processorFor(player: ExoPlayer): CrossmixTransitionAudioProcessor? = playerCrossmixProcessors[player]

        override fun targetVolume(): Float = this@MusicService.targetVolume()

        // not while casting or mid-crossmix, which drive the volume themselves, nor into an untouched dac, where a pause played on at full volume through the fade (issue 191)
        override fun canFade(): Boolean =
            castConnectionHandler?.isCasting?.value != true && !crossmixDirector.isTransitioning && fadingPlayer == null &&
                audioPass.status.value !is AudioPass.Status.Playing

        override fun beatMsFor(mediaId: String?): Double? =
            mediaId?.let { crossmixAnalysisRepository.cached(it)?.bpm }?.takeIf { it in 40f..240f }?.let { 60_000.0 / it }

        override fun blendSkip(previous: Boolean): Boolean = this@MusicService.blendSkip(previous)

        override fun blendJump(index: Int): Boolean = this@MusicService.blendJump(index)

        override fun blendsSkips(): Boolean = canBlendSkip()

        override suspend fun getReady(mediaId: String) = warmPick(mediaId)
    }

    /** what the Crossmix director needs from the service: players, the session, the queue */
    private inner class CrossmixHost : CrossmixDirector.Host {
        override val currentPlayer: ExoPlayer get() = player

        override fun processorFor(player: Player): CrossmixTransitionAudioProcessor? = playerCrossmixProcessors[player]

        override fun createIncoming(index: Int, positionMs: Long, parameters: PlaybackParameters): ExoPlayer {
            val incoming = createExoPlayer(publish = false)
            val items = (0 until player.mediaItemCount).map { player.getMediaItemAt(it) }
            incoming.setMediaItems(items)
            copyPlayOrder(from = player, to = incoming)
            incoming.repeatMode = player.repeatMode
            incoming.shuffleModeEnabled = player.shuffleModeEnabled
            // the tempo is set before anything plays: changing it later drains and resets the
            // audio chain, which would cut into the transition
            incoming.playbackParameters = parameters
            incoming.volume = if (isMuted.value) 0f else playerVolume.value
            incoming.seekTo(index, positionMs)
            incoming.playWhenReady = false
            // not prepared here: the director arms its renderer first, so not even the audio it
            // buffers while paused gets through untouched
            return incoming
        }

        override fun promote(incoming: ExoPlayer, outgoing: ExoPlayer) {
            fadingPlayer = outgoing
            player = incoming
            _playerFlow.value = incoming
            queueSavePlaying.value = incoming.isPlaying
            // set when it was made, seconds ago: a mute, an unmute or a slider move since then
            // never reached it, and the song carried on at the old volume (0, if it was muted)
            incoming.volume = targetVolume()

            outgoing.removeListener(this@MusicService)
            outgoing.removeListener(sleepTimer)
            // the outgoing player must never roll on into the next song itself
            outgoing.pauseAtEndOfMediaItems = true

            incoming.addListener(this@MusicService)
            incoming.addListener(sleepTimer)
            sleepTimer.player = incoming
            incoming.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    val out = fadingPlayer
                    if (!crossmixDirector.isTransitioning || out == null) {
                        incoming.removeListener(this)
                        return
                    }
                    // pause and resume both sides together; an outgoing side that has played out stays put
                    if (isPlaying) {
                        val finished = out.playbackState == Player.STATE_ENDED ||
                            (out.duration > 0 && out.currentPosition >= out.duration - 250)
                        if (!finished) out.play()
                    } else {
                        out.pause()
                    }
                }
            })

            try {
                (mediaSession as MediaSession).player = sessionPlayer(incoming)
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Failed to swap player in MediaSession")
            }

            // the hooks a song change runs (loudness, scrobbling, queue top-up, saving the queue)
            // for the song now playing, which this player reached by a seek before it was ours
            currentMediaMetadata.value = incoming.currentMetadata
            promotingCrossmix = true
            try {
                onMediaItemTransition(incoming.currentMediaItem, Player.MEDIA_ITEM_TRANSITION_REASON_AUTO)
            } finally {
                promotingCrossmix = false
            }
            watchPlatformOutput(incoming)
        }

        override fun release(outgoing: ExoPlayer) {
            runCatching {
                outgoing.stop()
                outgoing.clearMediaItems()
                outgoing.release()
            }
            playerCrossmixProcessors.remove(outgoing)
            playerSilenceProcessors.remove(outgoing)
            playerReplayGain.remove(outgoing)
            unregisterEqualizer(outgoing)
            if (fadingPlayer === outgoing) fadingPlayer = null
            fadingLoudnessEnhancer?.runCatching { release() }
            fadingLoudnessEnhancer = null
            sleepTimer.notifySongTransition()
        }

        override fun discard(incoming: ExoPlayer) {
            runCatching {
                incoming.stop()
                incoming.release()
            }
            playerCrossmixProcessors.remove(incoming)
            playerSilenceProcessors.remove(incoming)
            playerReplayGain.remove(incoming)
            unregisterEqualizer(incoming)
        }

        override fun crossmixBlocker(): String? = when {
            !crossfadeEnabled -> "Crossfade is off"
            crossmixMode != CrossmixMode.CROSSMIX -> "Crossfade is set to ${crossmixMode.name.lowercase()}, not Crossmix"
            usesSingleExternalOutput -> "Bluetooth and USB use single-player transitions"
            isCrossfading -> "A plain crossfade is running"
            player.repeatMode == REPEAT_MODE_ONE -> "Repeat one plays the song straight round"
            castConnectionHandler?.isCasting?.value == true -> "Casting: Crossmix waits until you're back"
            sleepTimer.pauseWhenSongEnd -> "The sleep timer stops after this song"
            else -> null
        }

        // with gapless albums on, songs from one album are checked for running into each other;
        // the director only plays them straight through when their audio really does
        override fun albumOf(index: Int): String? {
            if (!crossfadeGapless || index !in 0 until player.mediaItemCount) return null
            return player.getMediaItemAt(index).mediaMetadata.albumTitle?.toString()?.takeIf { it.isNotBlank() }
        }

        override fun onStatus(status: String) {
            crossmixStatus.value = status
        }

        override fun nextIndex(): Int =
            if (player.repeatMode == REPEAT_MODE_ONE) player.currentMediaItemIndex else player.nextMediaItemIndex

        // the next song's lyrics usually aren't fetched yet: fetch them now (and keep them, as the
        // player would on opening it), since synced lines say exactly where its voice comes in
        override suspend fun lyrics(item: MediaItem): String? = withContext(Dispatchers.IO) {
            val stored = runCatching { database.lyrics(item.mediaId).first()?.lyrics }.getOrNull()
            if (stored != null) return@withContext stored.takeUnless { it == LyricsEntity.LYRICS_NOT_FOUND }
            val metadata = item.metadata ?: return@withContext null
            val found = kotlinx.coroutines.withTimeoutOrNull(10_000L) {
                runCatching { lyricsHelper.getLyrics(metadata) }.getOrNull()
            } ?: return@withContext null
            if (found.provider == com.mochyy.mochymusic.lyrics.LyricsHelper.NoConnectionProvider) return@withContext null
            runCatching {
                database.query { upsert(LyricsEntity(id = metadata.id, lyrics = found.lyrics, provider = found.provider)) }
            }
            found.lyrics.takeUnless { it == LyricsEntity.LYRICS_NOT_FOUND }
        }

        override fun baseParameters(): PlaybackParameters = player.playbackParameters

        override fun onMixingChanged(mixing: Boolean) {
            crossmixMixing.value = mixing
        }

        override fun settings(): CrossmixSettings = crossmixSettings

        override fun learnedStartLatencyMs(): Double? = dataStore[CrossmixStartLatencyKey]?.toDouble()

        override fun onStartLatencyLearned(ms: Double) {
            scope.launch { dataStore.edit { it[CrossmixStartLatencyKey] = ms.toFloat() } }
        }
    }

    companion object {
        private val queueFileWriter = Executors.newSingleThreadExecutor()
        private val queueFileLock = Any()

        const val ROOT = "root"
        const val SONG = "song"
        const val ARTIST = "artist"
        const val ALBUM = "album"
        const val PLAYLIST = "playlist"
        const val YOUTUBE_PLAYLIST = "youtube_playlist"
        const val SEARCH = "search"
        const val SHUFFLE_ACTION = "__shuffle__"

        const val CHANNEL_ID = "music_channel_01"
        const val ERROR_CHANNEL_ID = "playback_errors_01"
        const val ERROR_NOTIFICATION_ID = 889
        const val NOTIFICATION_ID = 888
        const val ERROR_CODE_NO_STREAM = 1000001
        const val CHUNK_LENGTH = 512 * 1024L

        /**
         * Starts a separately resolved rendition key: "module|<rendition identity>|<media id>".
         * Its own key keeps it apart from the song's YouTube stream, which is cached under the bare
         * media id - see the data source factory.
         */
        const val ModuleCacheKeyPrefix = "module|"

        // a blended skip crosses the two songs over in the fade's Length; never shorter than this, or it's a click
        const val SkipBlendMinMs = 300L
        // back after this far into a song starts it over, like the previous button always did
        const val BlendRestartAfterMs = 3_000L
        const val CrossfadeFrameMs = 16L
        // how long a crossfade waits for the new song to be heard before it lets go and the new song plays on its own
        const val CrossfadeStartWaitMs = 12_000L
        // about the first 20 to 30 seconds of a song, enough for a skip to start straight from the cache
        const val PrefetchBytes = 512L * 1024L
        const val PrefetchDelayMs = 4_000L

        /** how long a provider that failed on a song is passed over for it (Force playback) */
        const val FailedSourceMemoryMs = 10L * 60 * 1000
        private const val BufferProgressSampleMs = 1_000L
        private const val ModuleNoBufferProgressMs = 5_000L
        private const val ModuleBufferWaitMs = 12_000L
        const val PERSISTENT_QUEUE_FILE = "persistent_queue.data"
        const val PERSISTENT_AUTOMIX_FILE = "persistent_automix.data"
        const val PERSISTENT_MANUAL_QUEUE_FILE = "persistent_manual_queue.data"
        const val PERSISTENT_PLAYER_STATE_FILE = "persistent_player_state.data"
        const val MAX_CONSECUTIVE_ERR = 5
        // Keep at least this many songs queued after the current one.
        private const val QUEUE_RUNWAY_SIZE = 5
        private const val MAX_RUNWAY_ATTEMPTS = 3
        private const val AUTOPLAY_PREVIEW_RETRY_MS = 60_000L
        private const val MAX_RUNWAY_RETRIES = 5
        private const val RUNWAY_RETRY_BASE_MS = 5_000L
        const val MAX_RETRY_COUNT = 10
        private const val MaxProviderLookupRetries = 2
        private const val ModuleEndGraceMs = 2_000L
        private const val ModuleEndBufferToleranceMs = 1_000L

        private const val MAX_GAIN_MB = 300
        private const val MIN_GAIN_MB = -1500

        private const val TAG = "MusicService"

        @Volatile
        var isRunning = false
            private set
    }
}

/** How often a placed home screen widget's progress is redrawn while playing. */
private const val WidgetProgressIntervalMs = 1_000L

// a timed save skips a place in the song that moved less than this; coming back a second or two early doesn't matter
private const val PositionSaveStepMs = 2_000L

// the passthrough switch, its mode and whether anything shapes the sound, compared as one so audio pass hears each change once
private data class PassSettings(val enabled: Boolean, val mode: AudioPassMode, val blocked: Boolean, val fixedVolume: Boolean)

// reads a restore point from an older version even if fields were added since
private val passJson = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
