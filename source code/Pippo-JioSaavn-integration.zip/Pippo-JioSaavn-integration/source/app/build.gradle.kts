import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import com.android.build.api.dsl.ApplicationExtension
import com.android.build.api.variant.ApplicationAndroidComponentsExtension
import com.android.build.api.variant.ResValue
import java.util.Properties
import java.security.MessageDigest
import java.net.URL

val localProperties = Properties()
val localPropertiesFile = rootProject.file("local.properties")
if (localPropertiesFile.exists()) {
    localProperties.load(localPropertiesFile.inputStream())
}
plugins {
    id("com.android.application")
    alias(libs.plugins.hilt)
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.protobufPlugin)
}

extensions.configure<ApplicationExtension> {
    namespace = "com.mochyy.mochymusic"
    compileSdk = 37
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.bhavishyadalal.pippo"
        minSdk = 24
        targetSdk = 37
        // Stable 0.1.2; keep the code increasing so existing code-73 installs can upgrade.
        versionCode = 74
        versionName = "0.1.2"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true

        // LastFM API keys from local.properties locally, GitHub Secrets on CI. never commit them
        val lastFmKey = localProperties.getProperty("LASTFM_API_KEY") ?: System.getenv("LASTFM_API_KEY") ?: ""
        val lastFmSecret = localProperties.getProperty("LASTFM_SECRET") ?: System.getenv("LASTFM_SECRET") ?: ""

        buildConfigField("String", "LASTFM_API_KEY", "\"$lastFmKey\"")
        buildConfigField("String", "LASTFM_SECRET", "\"$lastFmSecret\"")

        // Libre.fm the same way. It takes any 32-character key and never checks the secret, so a
        // build without its own (a fork, a CI run with no secrets) gets one made from the app id
        // instead of losing Libre.fm
        fun libreFmStandIn(name: String) = MessageDigest.getInstance("MD5")
            .digest("$applicationId.librefm.$name".toByteArray()).joinToString("") { "%02x".format(it) }
        val libreFmKey = localProperties.getProperty("LIBREFM_API_KEY")
            ?: System.getenv("LIBREFM_API_KEY")?.takeIf { it.isNotEmpty() } ?: libreFmStandIn("key")
        val libreFmSecret = localProperties.getProperty("LIBREFM_SECRET")
            ?: System.getenv("LIBREFM_SECRET")?.takeIf { it.isNotEmpty() } ?: libreFmStandIn("secret")
        buildConfigField("String", "LIBREFM_API_KEY", "\"$libreFmKey\"")
        buildConfigField("String", "LIBREFM_SECRET", "\"$libreFmSecret\"")

        // The Discord app Mochy signs in through (Developer Portal → your app → Application ID).
        // Discord sends the login back to discord-<id>:/authorize/callback, so the manifest needs it too.
        // Without one, the Discord page says so instead of opening a login that can't come back.
        val discordClientId = localProperties.getProperty("DISCORD_CLIENT_ID")
            ?: System.getenv("DISCORD_CLIENT_ID") ?: ""
        buildConfigField("String", "DISCORD_CLIENT_ID", "\"$discordClientId\"")
        manifestPlaceholders["discordRedirectScheme"] =
            if (discordClientId.isNotBlank()) "discord-$discordClientId" else "mochy-discord-unset"

//add nightly build label support
        val isNightly = project.hasProperty("nightly") && project.property("nightly") == "true"
        buildConfigField("Boolean", "IS_NIGHTLY", isNightly.toString())

        // When this build's code was made (its commit, not the wall clock, so it only changes with the
        // code). The Developer space counts issues, commits and releases since then.
        val buildTimeMillis = runCatching {
            providers.exec {
                commandLine("git", "log", "-1", "--format=%ct")
                isIgnoreExitValue = true
            }.standardOutput.asText.get().trim().toLong() * 1000L
        }.getOrDefault(0L)
        buildConfigField("long", "BUILD_TIME_MILLIS", "${buildTimeMillis}L")
    }
    

    flavorDimensions += listOf("abi", "variant")
    productFlavors {
        // FOSS variant (default) - self-updating, no Google Play Services
        create("foss") {
            dimension = "variant"
            isDefault = true
            buildConfigField("Boolean", "CAST_AVAILABLE", "false")
        }

        // F-Droid variant - F-Droid policy compliant (strips package install permissions)
        create("fdroid") {
            dimension = "variant"
            buildConfigField("Boolean", "CAST_AVAILABLE", "false")
        }

        // GMS variant - with Google Cast support (requires Google Play Services)
        create("gms") {
            dimension = "variant"
            buildConfigField("Boolean", "CAST_AVAILABLE", "true")
        }
        
        create("universal") {
            dimension = "abi"
            buildConfigField("String", "ARCHITECTURE", "\"universal\"")
            ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86", "x86_64") }
        }
        create("arm64") {
            dimension = "abi"
            buildConfigField("String", "ARCHITECTURE", "\"arm64\"")
            ndk { abiFilters += "arm64-v8a" }
        }
        create("armeabi") {
            dimension = "abi"
            buildConfigField("String", "ARCHITECTURE", "\"armeabi\"")
            ndk { abiFilters += "armeabi-v7a" }
        }
        create("x86") {
            dimension = "abi"
            buildConfigField("String", "ARCHITECTURE", "\"x86\"")
            ndk { abiFilters += "x86" }
        }
        create("x86_64") {
            dimension = "abi"
            buildConfigField("String", "ARCHITECTURE", "\"x86_64\"")
            ndk { abiFilters += "x86_64" }
        }
    }

    sourceSets {
        getByName("fdroid") {
            java.directories.add("src/foss/kotlin")
            res.directories.add("src/foss/res")
        }
    }

    // Release signing only works when the CI secrets are present. Locally they are not, which
    // used to make `assembleRelease` unbuildable and left debug as the only variant anyone ever
    // ran — and a debug Compose build is several times slower per frame than release, so all
    // local performance impressions were being formed against the wrong binary.
    val hasReleaseSigning = System.getenv("STORE_PASSWORD") != null &&
        System.getenv("KEY_ALIAS") != null &&
        System.getenv("KEY_PASSWORD") != null &&
        file("keystore/release.keystore").exists()

    signingConfigs {
        create("persistentDebug") {
            storeFile = file("persistent-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file("keystore/release.keystore")
                storePassword = System.getenv("STORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
        getByName("debug") {
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            storePassword = "android"
            storeFile = file("${System.getProperty("user.home")}/.android/debug.keystore")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isCrunchPngs = false
            isDebuggable = false
            isProfileable = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Fall back to the debug keystore locally so a release-quality build is always
            // runnable on a dev machine. CI still signs with the real key when secrets exist.
            signingConfig = if (hasReleaseSigning) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
            signingConfig = signingConfigs.getByName("debug")
        }

        // Release-identical performance with the profiler still attachable.
        //
        // `isDebuggable = false` is what makes release fast (ART will not JIT-deopt, R8 output
        // runs as shipped), but it also locks out Studio's profiler and Perfetto's app-level
        // tracks. `isProfileable` re-opens exactly those without turning debuggability back on,
        // so frame timings measured here are the ones users actually get.
        //
        // Installs alongside debug and release under its own applicationId, so all three can sit
        // on the device at once.
        create("profileable") {
            initWith(getByName("release"))
            applicationIdSuffix = ".profileable"
            isProfileable = true
            signingConfig = signingConfigs.getByName("debug")
            // The provider modules only publish debug/release variants; without this, resolving
            // a "profileable" variant of :providers:* fails.
            matchingFallbacks += listOf("release")
            proguardFiles("proguard-profileable.pro")
        }

        // not debuggable so ART uses the baseline profile, but no r8, so it builds about as fast as debug
        create("fast") {
            initWith(getByName("debug"))
            applicationIdSuffix = ".fast"
            isDebuggable = false
            isProfileable = true
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
            // the provider modules only publish debug and release variants
            matchingFallbacks += listOf("debug")
        }
    }

    // audio pass's direct usb driver and aaudio exclusive output (app/src/main/cpp)
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlin {
        jvmToolchain(21)
        compilerOptions {
            freeCompilerArgs.add("-Xannotation-default-target=param-property")
            jvmTarget.set(JvmTarget.JVM_21)
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
        resValues = true
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    lint {
        lintConfig = file("lint.xml")
        warningsAsErrors = false
        abortOnError = false
        checkDependencies = false
    }

    androidResources {
        generateLocaleConfig = true
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
            keepDebugSymbols += listOf(
                "**/libandroidx.graphics.path.so",
                "**/libdatastore_shared_counter.so"
            )
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/NOTICE.md"
            excludes += "META-INF/CONTRIBUTORS.md"
            excludes += "META-INF/LICENSE.md"
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/io.netty.versions.properties"
        }
    }
}

extensions.configure<ApplicationAndroidComponentsExtension> {
    val buildAbi = providers.gradleProperty("pippoBuildAbi").orNull
    if (buildAbi != null) {
        require(buildAbi in setOf("universal", "arm64", "armeabi", "x86", "x86_64")) {
            "Unknown Pippo ABI flavor: $buildAbi"
        }
        beforeVariants { variant ->
            if (("abi" to buildAbi) !in variant.productFlavors) variant.enable = false
        }
    }
    onVariants { variant ->
        variant.resValues.put(
            variant.makeResValueKey("string", "shortcut_target_package"),
            variant.applicationId.map { ResValue(it) },
        )
    }
}

protobuf {
    protoc {
        artifact = "com.google.protobuf:protoc:${libs.versions.protobuf.get()}"
    }
    generateProtoTasks {
        all().forEach { task ->
            task.builtins {
                create("java") {
                    option("lite")
                }
                create("kotlin") {
                    option("lite")
                }
            }
        }
    }
}

// Compose compiler tuning.
//
// includeSourceInformation is what makes every composable group emit source-position metadata
// and sourceInformationMarkerStart/End calls. That is required for the layout inspector and is
// on by default, but in a shipping build it is pure per-composition overhead. Keeping it on for
// debug preserves tooling; turning it off for release removes the cost where it matters.
//
// The metrics/reports destinations are opt-in via -PcomposeMetrics so normal builds are
// unaffected. Run with:
//   ./gradlew assembleUniversalFossRelease -PcomposeMetrics
// then read build/compose-reports/*-composables.txt to see which composables are non-skippable
// and which parameters are inferred unstable.
composeCompiler {
    // Computed eagerly at configuration time rather than in a provider: reading
    // gradle.startParameter during task execution is a configuration-cache violation, and this
    // project enables the configuration cache. The cache entry is keyed by task names anyway, so
    // an eager read re-evaluates correctly when the requested tasks change.
    //
    // Both release and profileable must strip source info — profileable exists precisely to
    // measure release performance, so it has to be compiled identically.
    val buildingReleaseLike = gradle.startParameter.taskNames.any { name ->
        name.contains("Release", ignoreCase = true) ||
            name.contains("Profileable", ignoreCase = true) ||
            name.contains("Fast", ignoreCase = true)
    }
    includeSourceInformation.set(!buildingReleaseLike)

    if (project.hasProperty("composeMetrics")) {
        metricsDestination.set(layout.buildDirectory.dir("compose-metrics"))
        reportsDestination.set(layout.buildDirectory.dir("compose-reports"))
    }

    // Treat these as @Immutable/@Stable without annotating them at every declaration site.
    // Compose otherwise infers List/ImmutableCollection-typed parameters as unstable, which
    // under strong skipping downgrades those composables to instance-equality comparison and
    // makes them re-run whenever a caller rebuilds the list.
    stabilityConfigurationFiles.add(
        rootProject.layout.projectDirectory.file("compose_compiler_config.conf")
    )
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    compilerOptions {
        freeCompilerArgs.addAll(
            "-opt-in=kotlin.RequiresOptIn"
        )
        suppressWarnings.set(false)
    }
}

dependencies {
    implementation(libs.guava)
    implementation(libs.coroutines.guava)
    implementation(libs.concurrent.futures)

    implementation(libs.activity)
    implementation(libs.hilt.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.datastore)

    implementation(libs.compose.runtime)
    // the profiling build names every composable in system traces, so a slow frame says what it was
    "profileableImplementation"("androidx.compose.runtime:runtime-tracing:1.10.2")
    "profileableImplementation"("androidx.tracing:tracing-perfetto-binary:1.0.1")
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.util)
    // Tooling must not ship in release: it pulls in ui-tooling-data and the inspector, which
    // keep composition inspection tables reachable. Nothing in main/ imports it and there are
    // no @Preview functions, so debug-only costs us nothing.
    debugImplementation(libs.compose.ui.tooling)
    implementation(libs.compose.animation)
    implementation(libs.compose.reorderable)

    implementation(libs.viewmodel)
    implementation(libs.viewmodel.compose)
    implementation(libs.lifecycle.process)

    implementation(libs.material3)
    implementation(libs.androidx.adaptive)
    implementation(libs.androidx.adaptive.layout)
    implementation(libs.androidx.adaptive.navigation)
    implementation(libs.palette)
    implementation(libs.materialKolor)

    implementation(libs.appcompat)

    implementation(libs.coil)
    implementation(libs.coil.svg)
    implementation(libs.coil.network.okhttp)

    implementation(libs.ucrop)

    implementation(libs.shimmer)

    implementation(libs.media3)
    implementation(libs.media3.session)
    implementation(libs.car.app)
    implementation(libs.car.app.projected)
    implementation(libs.androidx.media)
    implementation(libs.media3.hls)
    implementation(libs.media3.dash)
    implementation(libs.media3.ui)
    implementation(libs.media3.okhttp)
    // ffmpeg decodes alac (and flac, opus...) on phones that have no decoder of their own for it
    implementation(libs.media3.ffmpeg)
    // song share videos: decode the background, mix in the song, encode the mp4
    implementation(libs.media3.transformer)
    implementation(libs.media3.effect)

    // Google Cast - only included in GMS flavor (not available in F-Droid/FOSS builds)
    "gmsImplementation"(libs.media3.cast)
    "gmsImplementation"(libs.mediarouter)
    "gmsImplementation"(libs.cast.framework)

    implementation(libs.room.runtime)
    implementation(libs.kuromoji.ipadic)
    implementation(libs.tinypinyin)
    ksp(libs.room.compiler)
    implementation(libs.room.ktx)

    implementation(libs.apache.lang3)

    implementation(libs.hilt)
    implementation(libs.jsoup)
    ksp(libs.hilt.compiler)

    implementation(project(":providers:innertube"))
    implementation(project(":providers:kugou"))
    implementation(project(":providers:lrclib"))
    implementation(project(":providers:lastfm"))
    implementation(project(":providers:betterlyrics"))
    implementation(project(":providers:simpmusic"))
    implementation(project(":providers:youlyplus"))
    implementation(project(":providers:canvas"))
    implementation(project(":providers:shazamkit"))
    implementation(project(":providers:artistvideo"))
    implementation(project(":providers:applecanvas"))
    implementation(project(":providers:paxsenixlyrics"))
    implementation(project(":providers:directlyrics"))
    implementation(project(":providers:musixmatch"))
    implementation(project(":providers:genius"))
    implementation(project(":providers:wikipedia"))
    implementation(project(":modules:api"))
    implementation(project(":modules:applemusic"))
    implementation(project(":modules:monochrome"))
    implementation(project(":modules:jiosaavn"))
    implementation(project(":modules:bridge"))


    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.ktor.client.content.negotiation)
    implementation(libs.ktor.serialization.json)
    // finds song streams first, with mochy's own client walk as the backup (YTPlayerUtils)
    implementation(libs.innertubex)

    // Protobuf for message serialization (lite version for Android)
    implementation(libs.protobuf.javalite)
    implementation(libs.protobuf.kotlin.lite)

    coreLibraryDesugaring(libs.desugaring)
    implementation(libs.timber)
    implementation(libs.smoothCorner)
    implementation(libs.lottie.compose)
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation(libs.work.runtime.ktx)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.webkit)

    testImplementation(libs.junit)
    androidTestImplementation(libs.junit)
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
