# Pippo’s JioSaavn integration

This is the complete JioSaavn resolver from Pippo 0.1.2 stable, with its shared API, recording matcher, offline test fixture, and the Pippo source that connects it to the player. It is a source reference for building another music player. Android app files under `source/` are excerpts from the project tree and depend on the full Pippo checkout.

1. [Follow the HTTP, matching, and stream selection flow](FETCH-FLOW.md).
2. [See how Pippo wires playback, settings, diagnostics, and downloads](PIPPO-WIRING.md).
3. [Port the resolver and check it with the included fixtures](PORTING.md).
4. [See every copied source path](SOURCE-FILES.txt).

The [provider module](source/modules/jiosaavn/) and [module API](source/modules/api/) are included in full and retain their original paths under `source/`. All 33 Markdown files tracked by the stable snapshot are also preserved there, including the [Pippo README](source/README.md), [module documentation](source/modules/README.md), and [license notices](source/NOTICE.md). The [GPL v3 text](source/LICENSE) is included. Links in the copied documentation may reference assets outside this extraction.

The archive contains source and an existing JSON test fixture. Playback at runtime depends on JioSaavn’s live catalog and CDN.

Source snapshot [`9a68abbc686d8d54b957a0118c937add5c625955`](https://github.com/Bhavishyadalal/Pippo/tree/9a68abbc686d8d54b957a0118c937add5c625955) from `stable-0.1.2`.
