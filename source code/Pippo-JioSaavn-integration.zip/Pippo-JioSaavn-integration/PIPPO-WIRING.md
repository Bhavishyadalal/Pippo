# How Pippo connects JioSaavn to playback and downloads

App Kotlin paths below are relative to `source/app/src/main/kotlin/com/mochyy/mochymusic/`. The archive retains the original files so the call sites are searchable.

| Stage | Files and entry points |
| --- | --- |
| Registration | `modules/ModuleRegistry.kt`: `load`, `hostFor`, `isEnabled`, `setEnabled`, `picks`. |
| Selection | `modules/SourceModules.kt`: `withBundledSources`, `route`, `lookupForPlayback`, `playbackPicks`, `downloadRoute`. `modules/DeviceDecoders.kt` checks audio support. |
| Play | `playback/MusicService.kt`: `createMediaSourceFactory`, `resolveQueueStream`, `routeStream`, `trackQueryOf`, `moduleStream`, `rememberRendition`, `createDataSourceFactory`, `forceFallBack`. `playback/custom/DynamicResolvingMediaSource.kt` builds the Media3 child source. |
| Manually switch | `ui/player/info/PlayerProviderMark.kt`, `ForceProviderSheet.kt`, `playback/ProviderSwitch.kt`, and `MusicService.ProviderSwitchHost`. |
| Diagnose | `viewmodels/OnboardingModulesViewModel.kt`, `viewmodels/ModulesViewModel.kt`, `ui/screens/settings/modules/ModuleTest.kt`, and `ui/screens/setup/onboarding/OnboardingPages.kt`. |
| Download | `playback/DownloadUtil.kt`, `playback/ExoDownloadService.kt`, `playback/DownloadFolderWorker.kt`, and `playback/DownloadExporter.kt`. |
| Settings | `ui/screens/settings/modules/ModuleScreen.kt`, `ui/screens/audiolab/AudioQualityScreen.kt`, `ui/screens/settings/storage/DownloadSettingsScreen.kt`, and `constants/PreferenceKeys.kt`. |

## Registration, settings, and host

- The app links the `:modules:jiosaavn` project in Gradle. The registry creates an instance alongside the other built-in modules and supplies its `ModuleHost`. A generic “Copy module link” action deliberately returns no link for this provider.
- The `source_modules` preferences store `enabled_jiosaavn`, `pick_jiosaavn_quality`, `provider_order`, and `download_order`. JioSaavn starts enabled unless the user changes it. Missing bundled sources are inserted before YouTube Music while existing placements are retained.
- The host has a private `module_jiosaavn` preference namespace for health fields. Its blocking OkHttp client sets a 12-second connect timeout and a 20-second read timeout, copies each request’s headers, closes the response, and returns status, body bytes and lowercase response header names. The player’s streaming HTTP client is a separate path with its own proxy and IP settings.
- Data Saver can lower JioSaavn’s playback pick from 320 to 160. It leaves 160 and 96 alone. It uses the same quality pick calculation for the direct provider lookup.

## Automatic and manual playback

1. The main resolver uses a local file, completed download, or linked phone file when appropriate. Online routing builds a `TrackQuery` from the current queue item and falls back to database metadata for missing fields. Offline mode prevents an online provider lookup.
2. Eligible modules are queried concurrently. The automatic route validates the matched recording, tests decoder support, and uses a 12-second lookup ceiling. It can wait up to 1.75 seconds for alternatives after a lossy or recently stalled response, or 200 ms for a short tie. When Data Saver is inactive, lossless candidates rank ahead of AAC. Among equal-quality options it prefers providers that haven’t stalled recently, then uses the configured order. YouTube Music is the fallback when available and enabled.
3. The manual **Play from** panel can explicitly request JioSaavn and one of its quality options. The request is scoped to the current queue occurrence. A new selection or Cancel invalidates the previous lookup. Retryable failures have a bounded retry budget of up to 20 attempts, with a 60-second overall deadline and a nine-second per-attempt limit. Rejected matches end the lookup early. The handoff preserves the current track while resolving and publishes the new provider after successful startup.
4. The resolved URI becomes a progressive Media3 media source with the provider’s headers. Its cache key is separate from the bare song ID used by the normal YouTube path. The module key includes recording and rendition data such as provider ID, catalog ID, format, codec, sample rate, quality, and URL host. The service exposes provider and track format to the player UI. Playback recovery can move to another provider when a chosen stream cannot sustain playback.
5. The experimental read-ahead option shares the progressive playback cache with the player. It can prepare the current supported stream and the next three starts, with guards for active playback, offline mode, Data Saver, and cache budget. It does not use the permanent Downloads cache as a destination.

## Diagnostics

- The module settings diagnostic uses the same playback picks, reports each module step, and then tries to decode approximately two seconds in a temporary muted player. The diagnostic capture is independent of the player’s normal running stream.
- The welcome and shared module fetch panels use `SourceModules.lookupForPlayback`. They distinguish results such as compatible stream found, no match, unsupported audio, timeout, and unavailable. A found result there is a lookup result. The welcome flow’s automatic enabling exception applies to Monochrome; JioSaavn follows its own toggle.

## Downloads

- **Settings → Downloads** stores a provider choice, a quality and an optional Android document folder. **Automatic** uses the separate download order. Choosing JioSaavn directly limits the download to JioSaavn.
- High, Medium, and Low map to JioSaavn’s 320, 160, and 96 options. A returned stream may use the original rendition after the CDN probe. Lossless requires a progressive FLAC or ALAC stream, so JioSaavn AAC is ineligible.
- `DownloadUtil` reads song metadata from the library, snapshots the selected provider and quality in memory for the active transfer, forwards the audio request headers, and uses the permanent Media3 download cache. Its stream identity guard fails a resume when the old partial bytes cannot safely belong to the new stream. Failed provider results remain associated with the selected provider and quality. A selected module failure does not switch to another provider.
- Completed downloads are available in Pippo. When a user has selected a document folder, a WorkManager job copies the complete audio there, with format detection handling raw AAC and common containers. The folder copy is independent of provider resolution and requires the Android document-tree grant.
