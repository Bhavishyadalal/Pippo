# JioSaavn fetch flow

The primary implementation is `source/modules/jiosaavn/src/main/kotlin/com/mochyy/mochymusic/module/jiosaavn/JioSaavnModule.kt`. The shared API is `source/modules/api/src/main/kotlin/com/mochyy/mochymusic/module/MochyModule.kt`.

## Inputs and request

- The provider ID is `jiosaavn`. It implements `SourceModule` and advertises audio playback with no account sign-in. This is a built-in Kotlin module, with no manifest URL to install.
- The caller supplies a `TrackQuery` with a title, credited artists, optional album, duration in milliseconds, and optional ISRC. The resolver’s search text is the normalized title from `TrackMatcher.core` followed by the first artist. Album and duration are absent from the network query. The supplied duration contributes to recording matching.
- The exact search request is a GET to `https://www.jiosaavn.com/api.php?__call=search.getResults&_format=json&_marker=0&api_version=4&ctx=android&p=1&n=10&q=...`. The query is UTF-8 form-encoded with spaces changed from `+` to `%20`. Playback searches one page.
- Search uses `Accept: application/json`, the desktop Chrome user agent defined in the module, and `Cookie: explicit_content=1`, a static content preference. The actual audio request uses the module’s user agent. Copy these as distinct header sets.
- Health checking uses the same endpoint with query `test` and `n=1`. Any 2xx response clears the unreachable flag. Network errors set the reason and timestamp in module-private storage. The health indicator expires after ten minutes and is advisory for this account-free provider.

## Response and recording match

| Search response field | How Pippo uses it |
| --- | --- |
| `results[]` | Iterates the candidates. A missing array or invalid JSON makes the response unreadable. |
| `id`, `title` | Required catalog ID and title for a usable row. |
| `more_info.artistMap.primary_artists[].name` | Decodes and joins credited artist names. Missing credits leave an empty artist string. |
| `more_info.album` | Optional album title in the match result. |
| `more_info.duration` | Optional integer seconds, converted to milliseconds. |
| `more_info.encrypted_media_url` | Required nonblank media URL envelope. |
| `more_info.320kbps` | A string or primitive equivalent to true marks 320 as available. |

The parser decodes the common HTML entities defined in `unescape`. `TrackMatcher` normalizes Unicode and removes common title decoration while keeping remix, live, acoustic, instrumental, karaoke, sped-up, and similar version markers meaningful. It rejects incompatible versions and clear previews. It uses title token overlap, artist token overlap, and duration, with weights 50%, 30%, and 20%. Candidates must clear individual title and artist checks and a combined score of 0.70. The shared matcher has an exact-ISRC path when both catalogs supply one. This JioSaavn parser does not populate ISRC.

The resolver tries ranked rows until the first media link decodes, caches that match, and returns its metadata and confidence. That first pass checks link readability. A later playback error goes through the player’s normal recovery path.

## Media link and quality

1. The module decodes the response’s media URL envelope with the MIME Base64 decoder and `DES/ECB/PKCS5Padding`, using the fixed protocol constant in the copied source. It trims the result and keeps URLs beginning with `http`. This step yields a media URL. The progressive audio returned by the module has no DRM configuration.
2. The `quality` choice has option IDs `320`, `160`, and `96`. The default is 320 for a row marked as offering it, otherwise 160. An explicit 160 or 96 requests that tier.
3. If the original URL matches a known `_<bitrate>.<extension>` suffix, the module can replace the bitrate and retain the query string or fragment. Recognized bitrates are 12, 48, 96, 160, and 320, with `mp4`, `m4a`, `aac`, or `mp3` suffixes. A GET with `Range: bytes=0-1` probes an alternate URL. The module accepts a 2xx response. If the probe fails, it keeps the original URL and reports its recognized bitrate. An unfamiliar suffix keeps the original URL with unknown bitrate.
4. The result is `ResolveResult.Found(SourceStream(...))` with a progressive URI, stream headers, the JioSaavn source label, codec label AAC, declared 44,100 Hz, matched recording fields, and a quality label such as `AAC 320`. The sample rate and codec label are declared by the resolver. The actual decoder format can be inspected at playback.

## Cache and outcome semantics

- The in-memory positive cache holds the accepted row and decoded URL for two minutes per full `TrackQuery`. The quality option is applied after that lookup, so a quality change can reuse the same catalog result.
- A valid search with no acceptable recording creates a 30-minute negative cache entry. Network failure, non-2xx response, unreadable JSON, and unreadable media links yield `Unavailable` rather than adding a negative match.
- `signOut` clears the in-memory match and miss maps. There is no interactive login for this provider.
- The module’s diagnostic emits a search and stream result. The app’s separate playback diagnostic runs a muted decoder before reporting that playback works. See [Pippo wiring](PIPPO-WIRING.md).
