# Reusing the resolver in a Kotlin music player

## Start with the smallest source set

Copy the complete `source/modules/jiosaavn/` and `source/modules/api/` source sets. The minimum production Kotlin files are `JioSaavnModule.kt`, `MochyModule.kt`, and `TrackMatcher.kt`. Keep their package names or update the imports together. The module has no Android dependency. The shared API version in this snapshot is 3.

Pippo builds these modules with JVM toolchain 21 and Kotlin 2.3.10. The resolver uses `kotlinx-serialization-json:1.6.3`. The existing module tests use JUnit 4.13.2 and `kotlinx-coroutines-core:1.10.2`. The Gradle configuration and version catalog in this archive show the reference setup. The extracted host code uses Android and Media3 and depends on the rest of the Pippo project.

## Integrate the host and player

1. Construct a single `JioSaavnModule` instance, attach a `ModuleHost`, and keep the instance alive across requests for its match cache. Implement a private `ModuleStorage`, an app-private folder, logging, and a bounded HTTP client. See `ModuleRegistry.hostFor` for Pippo’s reference implementation.
2. Build a `TrackQuery` with accurate title, primary artist and duration where available. Call `resolve(query, mapOf("quality" to "320"))` or supply the saved option. Run the blocking HTTP work off the UI thread. A coroutine wait deadline by itself may not interrupt a blocking network call. Keep client timeouts and cancel the HTTP call where possible.
3. On `Found`, open the returned progressive URL with the returned headers. Use your player’s detected audio format for the actual format display. Keep the cache identity distinct across provider, recording and rendition. Keep the provider’s original bitrate fallback policy visible to the user.
4. On `NotFound`, check the query metadata or continue to your other providers. On `Unavailable`, consider a bounded retry or offer the user another source. Associate a request with the selected track and discard late results after skip, cancel, or provider switch.
5. When adding offline saves, preserve the stream’s format and verify that the file is complete before exposing it. Avoid appending bytes from a changed URI or rendition to a partial file. JioSaavn’s connector only offers AAC and should not be presented as lossless.

## Offline test reference

The original `JioSaavnModuleTest.kt` and `search_tum_hi_ho.json` fixture are included. Its fake host returns a search payload plus a simulated CDN response. The tests cover parsed artists and titles, media-link decoding, selecting the 320 tier, fallback when the CDN rendition is missing, and retaining URL parameters.

From a full checkout at the documented commit, the existing module-only task is:

```sh
./gradlew :modules:jiosaavn:test
```

When wiring a new player, also check rapid track changes, missing metadata, provider disable during lookup, wrong recordings, range requests with both 206 and failure responses, and a real decoder opening the returned file. Local fixtures verify source logic independently of current catalog availability.

## Porting limits to keep in mind

- This is a web catalog integration. The endpoint, fields and URL formats can change. The availability of tracks varies by catalog and region.
- The existing resolver only looks through one page and stores both match and miss entries in memory, with age checked on lookup. A new long-running service can enforce a maximum cache size and periodically remove expired entries.
- The existing host reads the full response body. A production port can cap JSON response sizes and avoid reading more than a small probe needs if the CDN ignores the range header. Use a proper parsed HTTPS URI and validate acceptable hosts before requesting untrusted URLs.
- Use the entire copied matcher when you want exact Pippo behavior. A title-only search will return similar songs, alternative versions, and previews more often.
- Review the copied [license](source/LICENSE) and [notices](source/NOTICE.md) when reusing or distributing the implementation.
