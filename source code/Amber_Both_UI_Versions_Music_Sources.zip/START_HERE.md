# Amber Classic and Studio · Music sources update

Extract either of the included ZIPs. Open its `01_Amber_Desktop_App` directory and follow the README. On Windows, run `build_exe.bat` in that directory to rebuild your installer. Keep the Classic and Studio installation folders separate.

Open **Setup → Music sources** to choose **YouTube Music**, **JioSaavn**, or **both**, and select **Prefer lossless**, **High**, **Medium**, or **Low**. The bundled audio modules have their own switches. Add compatible audio modules by pasting their HTTPS manifest or base URL. Once audio starts, click the source and quality text under the song title to return to these settings.

Home combines recent listening, favorites, and related music. Queue suggestions use your current song and avoid tracks already queued or recently played. The previous setup documentation, website projects and installer identities are included in each package.

See **MUSIC_SOURCES_UPDATE.md** inside either ZIP for provider support, cache behavior, and verification details.
